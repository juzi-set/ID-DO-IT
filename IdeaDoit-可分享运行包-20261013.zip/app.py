# -*- coding: utf-8 -*-
"""
Idea: Do it  — 规划系统后端
可部署于飞牛 NAS (FnOS) 的 Docker 容器。
技术栈: Flask + Flask-SQLAlchemy + SQLite (文件持久化)
"""
import os
import json
import uuid
import colorsys
from datetime import datetime, timedelta, timezone, date as _date

from flask import (
    Flask, request, jsonify, session, redirect, url_for,
    render_template, send_from_directory,
)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix

# ---------------------------------------------------------------------------
# 基础路径 / 配置
# ---------------------------------------------------------------------------
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATA_DIR = os.environ.get("DATA_DIR", os.path.join(BASE_DIR, "data"))
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.path.join(DATA_DIR, "app.db")

app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "dev-secret-change-me")
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{DB_PATH}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SESSION_COOKIE_NAME"] = "idea_do_it"
db = SQLAlchemy(app)

# 版块二流程图节点图片上传：存到 static/uploads 下，随静态路由对外提供
UPLOAD_DIR = os.path.join(app.static_folder, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
ALLOWED_IMG_EXT = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}
MAX_IMG_BYTES = 8 * 1024 * 1024  # 单张图片最大 8MB

# ---------------------------------------------------------------------------
# 反向代理 / 子路径支持 (飞牛 NAS 等常把应用挂在子路径下)
# 1) 若前置代理设置了 X-Forwarded-Prefix / X-Script-Name，自动据此修正；
# 2) 也可手动设置环境变量 PROXY_PREFIX（如 /idea）适配无头代理的子路径。
# 前端会从自身脚本 URL 自动识别前缀，无需额外配置。
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)

_PROXY_PREFIX = (os.environ.get("PROXY_PREFIX", "") or "").strip().rstrip("/")
if _PROXY_PREFIX:
    class _ScriptNameMiddleware:
        def __init__(self, app, prefix):
            self.app = app
            self.prefix = prefix

        def __call__(self, environ, start_response):
            environ["SCRIPT_NAME"] = self.prefix
            return self.app(environ, start_response)
    app.wsgi_app = _ScriptNameMiddleware(app.wsgi_app, _PROXY_PREFIX)

# 星期映射 (1=周一 ... 7=周日)
DAY_NAMES = {1: "周一", 2: "周二", 3: "周三", 4: "周四", 5: "周五", 6: "周六", 7: "周日"}
DEFAULT_CATEGORIES = ["工作", "学习", "生活", "运动", "娱乐", "其他"]
DEFAULT_CAT_COLORS = {"工作": "#3b82f6", "学习": "#10b981", "生活": "#f59e0b",
                      "运动": "#ef4444", "娱乐": "#8b5cf6", "其他": "#94a3b8"}
# 新增自定义分类时循环使用的色板
CAT_PALETTE = ["#3b82f6", "#ef4444", "#10b981", "#f59e0b", "#8b5cf6", "#ec4899",
               "#06b6d4", "#84cc16", "#f97316", "#14b8a6", "#6366f1", "#d946ef",
               "#0ea5e9", "#22c55e", "#eab308", "#a855f7", "#64748b", "#0d9488"]


# ---------------------------------------------------------------------------
# 数据模型
# ---------------------------------------------------------------------------
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def check_password(self, pwd):
        return check_password_hash(self.password_hash, pwd)


class Category(db.Model):
    """版块一：用户自定义分类（名称 + 配色 + 顺序），可增删改。"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    color = db.Column(db.String(20), default="#3b82f6")
    order = db.Column(db.Integer, default=0)
    __table_args__ = (db.UniqueConstraint("user_id", "name", name="uq_user_category"),)

    def to_dict(self):
        return {"name": self.name, "color": self.color}


class Project(db.Model):
    """版块一：新建项目 + 版块二细化字段"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    name = db.Column(db.String(200), nullable=False)
    category = db.Column(db.String(100), default="其他")
    description = db.Column(db.Text, default="")
    # 版块二细化
    expected_hours = db.Column(db.Float, default=1.0)   # 预期时间(小时)
    location = db.Column(db.String(200), default="")    # 地点
    people = db.Column(db.String(200), default="")      # 人物
    funds = db.Column(db.Float, default=0.0)            # 资金
    steps = db.Column(db.Text, default="[]")            # 步骤链(开始-下一步-结束) JSON
    flow = db.Column(db.Text, default="")               # 流程图(细化板块) JSON {nodes,edges}
    status = db.Column(db.String(20), default="idea")   # idea / planned / done
    color = db.Column(db.String(20), default="#3b82f6")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def get_steps(self):
        try:
            return json.loads(self.steps or "[]")
        except Exception:
            return []

    def get_flow(self):
        try:
            return json.loads(self.flow or "")
        except Exception:
            return None

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "name": self.name,
            "category": self.category,
            "description": self.description,
            "expected_hours": self.expected_hours,
            "location": self.location,
            "people": self.people,
            "funds": self.funds,
            "steps": self.get_steps(),
            "flow": self.get_flow(),
            "status": self.status,
            "color": self.color,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class FixedSchedule(db.Model):
    """版块三：固定安排 (每周循环，如睡觉/上班)"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    title = db.Column(db.String(200), nullable=False)
    day_of_week = db.Column(db.Integer, nullable=False)  # 1..7
    start_hour = db.Column(db.Float, nullable=False)     # 0..24
    end_hour = db.Column(db.Float, nullable=False)
    color = db.Column(db.String(20), default="#94a3b8")

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "day_of_week": self.day_of_week,
            "start_hour": self.start_hour,
            "end_hour": self.end_hour,
            "color": self.color,
        }


class WeeklyArchive(db.Model):
    """版块三：每周规划归档
    每周一（首次访问新周时）自动把上一周的可自由规划内容归档到对应周，
    并从可规划区清空（固定安排不受影响）。也支持手动「立即重置本周」。
    - week_start: 该归档所属周的周一日期 "YYYY-MM-DD"
    - data: JSON 快照 {items: [...], stats: {...}, archived_at: ...}
    """
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    week_start = db.Column(db.String(10), nullable=False, index=True)  # 周一日期
    year = db.Column(db.Integer, default=0)
    week = db.Column(db.Integer, default=0)                            # ISO 周数
    data = db.Column(db.Text, default="{}")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)

    def get_data(self):
        try:
            d = json.loads(self.data or "{}")
            return d if isinstance(d, dict) else {}
        except Exception:
            return {}


class PlanItem(db.Model):
    """版块三：可规划部分 (把项目或项目的某个步骤放入时间格)
    - duration: 本次放置的预期用时(小时)，可在放入时单独调节，与项目「总预估」相互独立
    - step_id: 对应版块二步骤树中的节点 id（空 = 整个项目）
    - actual_start/actual_end: 实际执行起止时间(用于第四板块统计)
    - done: 是否按时完成
    """
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    project_id = db.Column(db.Integer, db.ForeignKey("project.id"), nullable=False)
    step_id = db.Column(db.String(50), default="")         # 步骤树节点 id
    day_of_week = db.Column(db.Integer, nullable=False)
    start_hour = db.Column(db.Float, nullable=False)
    duration = db.Column(db.Float, default=1.0)            # 单次预期用时(可调节)
    note = db.Column(db.String(200), default="")
    actual_start = db.Column(db.DateTime, nullable=True)   # 实际开始
    actual_end = db.Column(db.DateTime, nullable=True)     # 实际结束
    done = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self, project=None):
        proj = project
        dur = self.duration if self.duration else (proj.expected_hours if proj else 1.0)
        step_name = ""
        if self.step_id and proj:
            node = find_step(proj.get_steps(), self.step_id)
            if node:
                step_name = node.get("name", "")
        actual_duration = None
        if self.actual_start and self.actual_end:
            actual_duration = round(
                (self.actual_end - self.actual_start).total_seconds() / 3600.0, 2)
        return {
            "id": self.id,
            "project_id": self.project_id,
            "project_name": proj.name if proj else "",
            "step_id": self.step_id or "",
            "step_name": step_name,
            # 步骤分支使用与项目主色可区分的衍生色；整个项目保持主色
            "color": (step_color(proj.color, self.step_id)
                      if (proj and self.step_id) else (proj.color if proj else "#3b82f6")),
            "category": proj.category if proj else "",
            "day_of_week": self.day_of_week,
            "start_hour": self.start_hour,
            "duration": dur,
            "end_hour": round(self.start_hour + dur, 2),
            "note": self.note,
            "actual_start": self.actual_start.isoformat() if self.actual_start else None,
            "actual_end": self.actual_end.isoformat() if self.actual_end else None,
            "actual_duration": actual_duration,
            "done": self.done,
        }


# ---------------------------------------------------------------------------
# 工具函数
# ---------------------------------------------------------------------------
def current_user():
    uid = session.get("user_id")
    if not uid:
        return None
    return db.session.get(User, uid)


def login_required(f):
    from functools import wraps

    @wraps(f)
    def wrapper(*a, **k):
        if not current_user():
            return jsonify({"error": "未登录"}), 401
        return f(*a, **k)
    return wrapper


def seed_categories(u):
    """若用户还没有分类，按默认顺序写入；幂等。"""
    if Category.query.filter_by(user_id=u.id).first():
        return
    for i, name in enumerate(DEFAULT_CATEGORIES):
        db.session.add(Category(user_id=u.id, name=name,
                                color=DEFAULT_CAT_COLORS.get(name, "#94a3b8"), order=i))
    db.session.commit()


def user_categories(u):
    """返回当前用户的分类列表 [{name,color}]（按 order 排序），缺失时自动种子。"""
    seed_categories(u)
    return [c.to_dict() for c in Category.query.filter_by(user_id=u.id).order_by(Category.order).all()]


def fixed_intervals(f):
    """返回固定安排占用的区间列表（支持跨午夜，如 23:00-07:00）"""
    if f.end_hour > f.start_hour:
        return [(f.start_hour, f.end_hour)]
    return [(f.start_hour, 24.0), (0.0, f.end_hour)]


def overlap(a_start, a_end, b_start, b_end):
    return a_start < b_end and b_start < a_end


def interval_overlap(start, end, intervals):
    for (s, e) in intervals:
        if overlap(start, end, s, e):
            return True
    return False


def parse_dt(s):
    """把 ISO 字符串解析为 datetime，失败返回 None"""
    if not s:
        return None
    try:
        return datetime.fromisoformat(s)
    except Exception:
        return None


def find_step(steps, sid):
    """在步骤树中按 id 查找节点，找不到返回 None"""
    for n in steps:
        if not isinstance(n, dict):
            continue
        if n.get("id") == sid:
            return n
        found = find_step(n.get("children") or [], sid)
        if found:
            return found
    return None


# ---------------------------------------------------------------------------
# 颜色工具：步骤分支颜色 / 固定安排自动配色
# ---------------------------------------------------------------------------
def _hex_to_hls(h):
    h = (h or "#3b82f6").lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    try:
        r, g, b = (int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
    except ValueError:
        r, g, b = 0.23, 0.51, 0.96
    return colorsys.rgb_to_hls(r, g, b)


def _hls_to_hex(hu, li, sa):
    r, g, b = colorsys.hls_to_rgb(hu % 1.0, min(0.72, max(0.28, li)), min(0.9, max(0.35, sa)))
    return "#{:02x}{:02x}{:02x}".format(int(r * 255), int(g * 255), int(b * 255))


def step_color(base, sid):
    """同一项目下不同步骤生成可区分的颜色：按步骤 id 做确定性色相/亮度偏移，
    保证同一项目每个分支颜色不同、且与项目主色同属一个观感体系。"""
    hu, li, sa = _hex_to_hls(base)
    key = str(sid or "")
    shift = (sum(ord(c) for c in key) * 47) % 100 / 100.0  # 0 ~ 0.99 确定性伪随机
    hu2 = hu + (shift - 0.5) * 0.26          # 色相偏移 ±13%
    li2 = li + (shift * 0.16 - 0.08)         # 亮度微调拉开层次
    return _hls_to_hex(hu2, li2, sa + 0.05)


FIXED_COLORS = ["#64748b", "#7c3aed", "#0d9488", "#b45309", "#be185d",
                "#4338ca", "#0e7490", "#4d7c0f", "#9333ea", "#b91c1c"]


def fixed_auto_color(title):
    """固定安排按名称自动分配一个固定且醒目的颜色（同名同色）。"""
    return FIXED_COLORS[sum(ord(c) for c in (title or "?")) % len(FIXED_COLORS)]


def check_plan_conflict(user_id, day, start, end, exclude_id=None):
    """返回冲突信息或 None"""
    fixed = FixedSchedule.query.filter_by(user_id=user_id, day_of_week=day).all()
    for f in fixed:
        if interval_overlap(start, end, fixed_intervals(f)):
            return f"与固定安排「{f.title}」冲突"
    plans = PlanItem.query.filter_by(user_id=user_id, day_of_week=day).all()
    for p in plans:
        if exclude_id and p.id == exclude_id:
            continue
        dur = p.duration if p.duration else 1.0
        if overlap(start, end, p.start_hour, p.start_hour + dur):
            proj = db.session.get(Project, p.project_id)
            return f"与已规划项目「{proj.name if proj else ''}」冲突"
    return None


# ---------------------------------------------------------------------------
# 周归档 / 周一重置
# ---------------------------------------------------------------------------
def week_monday(d=None):
    """返回给定日期（默认今天，本地时区）所在周的周一 date"""
    if d is None:
        d = datetime.now().date()
    if isinstance(d, datetime):
        d = d.date()
    return d - timedelta(days=d.weekday())


def week_key(d=None):
    """周一日期的 'YYYY-MM-DD' 字符串"""
    return week_monday(d).strftime("%Y-%m-%d")


def iso_week_num(d=None):
    """ISO 周数与年份"""
    d = d or datetime.now().date()
    if isinstance(d, datetime):
        d = d.date()
    iy, iw, _ = d.isocalendar()
    return iy, iw


def _utc_to_local(dt):
    """created_at 存的是 UTC naive datetime，转本地时区"""
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone()


def item_week_key(item):
    """推断某条规划所属的周（按创建时间）。无创建时间则按当前周。"""
    dt = _utc_to_local(item.created_at) or datetime.now()
    return week_key(dt)


def archive_week_snapshot(user_id, wk, items, merge=True):
    """把若干 PlanItem 序列化后写入/合并到某周归档，并重算该周统计。
    items 需在调用方持有 project 引用前完成序列化（本函数自行查项目）。"""
    archive = WeeklyArchive.query.filter_by(user_id=user_id, week_start=wk).first()
    data = archive.get_data() if (archive and merge) else {}
    old_items = data.get("items") or []
    # 序列化新条目（快照项目名/类别/颜色，避免项目日后删除导致历史不可读）
    projects = {p.id: p for p in Project.query.filter_by(user_id=user_id).all()}
    new_items = []
    for p in items:
        proj = projects.get(p.project_id)
        step_name = ""
        if p.step_id and proj:
            node = find_step(proj.get_steps(), p.step_id)
            if node:
                step_name = node.get("name", "")
        actual = None
        if p.actual_start and p.actual_end:
            actual = round((p.actual_end - p.actual_start).total_seconds() / 3600.0, 2)
        new_items.append({
            "id": p.id,
            "project_id": p.project_id,
            "project_name": proj.name if proj else "（已删除项目）",
            "step_id": p.step_id or "",
            "step_name": step_name,
            "category": proj.category if proj else "其他",
            "color": proj.color if proj else "#3b82f6",
            "day_of_week": p.day_of_week,
            "start_hour": p.start_hour,
            "duration": p.duration if p.duration else 1.0,
            "done": bool(p.done),
            "actual_hours": actual,
        })
    all_items = old_items + new_items
    iy, iw = iso_week_num(datetime.strptime(wk, "%Y-%m-%d"))
    data["items"] = all_items
    data["stats"] = _week_stats(all_items)
    data["archived_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    if archive:
        archive.data = json.dumps(data, ensure_ascii=False)
        archive.year, archive.week = iy, iw
        archive.updated_at = datetime.utcnow()
    else:
        archive = WeeklyArchive(
            user_id=user_id, week_start=wk, year=iy, week=iw,
            data=json.dumps(data, ensure_ascii=False))
        db.session.add(archive)
    return len(new_items)


def _week_stats(items):
    """对一周的条目列表计算完成情况统计（雷达图/看板共用）"""
    planned = round(sum((it.get("duration") or 0) for it in items), 2)
    done = round(sum((it.get("duration") or 0) for it in items if it.get("done")), 2)
    actual = round(sum((it.get("actual_hours") or 0) for it in items), 2)
    cat_map = {}
    for it in items:
        c = it.get("category") or "其他"
        cm = cat_map.setdefault(c, {"category": c, "planned": 0.0, "done": 0.0, "count": 0})
        cm["planned"] += (it.get("duration") or 0)
        cm["count"] += 1
        if it.get("done"):
            cm["done"] += (it.get("duration") or 0)
    by_category = []
    for c in cat_map.values():
        c["planned"] = round(c["planned"], 2)
        c["done"] = round(c["done"], 2)
        c["rate"] = round(c["done"] / c["planned"] * 100, 1) if c["planned"] > 0 else 0.0
        by_category.append(c)
    by_category.sort(key=lambda x: -x["planned"])
    day_map = {}
    for d in range(1, 8):
        day_map[d] = {"day": d, "planned": 0.0, "done": 0.0}
    for it in items:
        d = it.get("day_of_week")
        if d in day_map:
            day_map[d]["planned"] += (it.get("duration") or 0)
            if it.get("done"):
                day_map[d]["done"] += (it.get("duration") or 0)
    unfinished = [{
        "name": (it.get("step_name") and (it["project_name"] + " · " + it["step_name"])) or it.get("project_name", ""),
        "category": it.get("category", ""),
        "color": it.get("color", "#3b82f6"),
        "day": it.get("day_of_week"),
        "hours": it.get("duration", 0),
    } for it in items if not it.get("done")]
    return {
        "planned_hours": planned,
        "done_hours": done,
        "actual_hours": actual,
        "rate": round(done / planned * 100, 1) if planned > 0 else 0.0,
        "items_count": len(items),
        "done_count": sum(1 for it in items if it.get("done")),
        "by_category": by_category,
        "by_day": [day_map[d] for d in range(1, 8)],
        "unfinished": unfinished,
    }


def ensure_week(user):
    """跨周自动归档：把所有「创建于本周之前」的可规划条目按其所属周归档并删除。
    返回归档条数（0 = 无需重置）。固定安排不受影响。"""
    cur = week_key()
    items = PlanItem.query.filter_by(user_id=user.id).all()
    stale = [p for p in items if item_week_key(p) < cur]
    if not stale:
        return 0
    groups = {}
    for p in stale:
        groups.setdefault(item_week_key(p), []).append(p)
    n = 0
    for wk, plist in sorted(groups.items()):
        n += archive_week_snapshot(user.id, wk, plist, merge=True)
    for p in stale:
        db.session.delete(p)
    db.session.commit()
    print(f"[week] 已归档并重置 {n} 条历史周规划（当前周 {cur}）")
    return n



# ---------------------------------------------------------------------------
# 页面路由
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    if current_user():
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET"])
def login():
    return render_template("login.html", app_name="Idea: Do it")


@app.route("/dashboard")
@login_required
def dashboard():
    u = current_user()
    cats = user_categories(u)
    return render_template("dashboard.html", app_name="Idea: Do it",
                           day_names=DAY_NAMES,
                           categories=[c["name"] for c in cats],
                           cat_colors={c["name"]: c["color"] for c in cats})


@app.route("/static/<path:path>")
def static_files(path):
    return send_from_directory(app.static_folder, path)


@app.errorhandler(404)
def not_found(e):
    # 接口类 404 返回 JSON，便于前端提示具体是哪个路径找不到
    if request.path.startswith("/api/"):
        return jsonify({"error": "接口不存在: " + request.path}), 404
    return e


# ---------------------------------------------------------------------------
# 认证 API
# ---------------------------------------------------------------------------
@app.route("/api/upload", methods=["POST"])
@login_required
def api_upload():
    """版块二流程图节点插图：校验格式/大小后保存，返回可访问的静态 URL"""
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"error": "未选择文件"}), 400
    ext = os.path.splitext(f.filename)[1].lower()
    if ext not in ALLOWED_IMG_EXT:
        return jsonify({"error": "仅支持图片文件（png/jpg/jpeg/gif/webp/bmp）"}), 400
    f.seek(0, os.SEEK_END)
    size = f.tell()
    f.seek(0)
    if size > MAX_IMG_BYTES:
        return jsonify({"error": "图片不能超过 8MB"}), 400
    name = f"u{session['user_id']}_{uuid.uuid4().hex}{ext}"
    f.save(os.path.join(UPLOAD_DIR, name))
    return jsonify({"ok": True, "url": url_for("static_files", path="uploads/" + name)})


@app.route("/api/login", methods=["POST"])
def api_login():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""
    user = User.query.filter_by(username=username).first()
    if user and user.check_password(password):
        session["user_id"] = user.id
        return jsonify({"ok": True, "user": {"id": user.id, "username": user.username}})
    return jsonify({"ok": False, "error": "账号或密码错误"}), 401


@app.route("/api/register", methods=["POST"])
def api_register():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""
    if not username or not password:
        return jsonify({"error": "账号和密码不能为空"}), 400
    if User.query.filter_by(username=username).first():
        return jsonify({"error": "该账号已存在"}), 400
    user = User(username=username, password_hash=generate_password_hash(password))
    db.session.add(user)
    db.session.commit()
    session["user_id"] = user.id
    seed_categories(user)
    return jsonify({"ok": True, "user": {"id": user.id, "username": user.username}})


@app.route("/api/logout", methods=["POST"])
def api_logout():
    session.clear()
    return jsonify({"ok": True})


@app.route("/api/me")
@login_required
def api_me():
    u = current_user()
    return jsonify({"user": {"id": u.id, "username": u.username}})


@app.route("/api/account/username", methods=["POST"])
@login_required
def api_account_username():
    """修改账户名：需验证当前密码，新名称不得与他人重复。"""
    u = current_user()
    data = request.get_json(silent=True) or {}
    cur = data.get("current_password") or ""
    new = (data.get("new_username") or "").strip()
    if not u.check_password(cur):
        return jsonify({"error": "当前密码不正确"}), 403
    if len(new) < 2:
        return jsonify({"error": "新账户名至少 2 个字符"}), 400
    if User.query.filter(User.username == new, User.id != u.id).first():
        return jsonify({"error": "该账户名已被使用"}), 400
    u.username = new
    db.session.commit()
    return jsonify({"ok": True, "user": {"id": u.id, "username": u.username}})


@app.route("/api/account/password", methods=["POST"])
@login_required
def api_account_password():
    """修改密码：需验证当前密码，新密码至少 6 位。"""
    u = current_user()
    data = request.get_json(silent=True) or {}
    cur = data.get("current_password") or ""
    new = data.get("new_password") or ""
    if not u.check_password(cur):
        return jsonify({"error": "当前密码不正确"}), 403
    if len(new) < 6:
        return jsonify({"error": "新密码至少 6 位"}), 400
    u.password_hash = generate_password_hash(new)
    db.session.commit()
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# 版块一 / 二：项目 API
# ---------------------------------------------------------------------------
@app.route("/api/projects", methods=["GET"])
@login_required
def api_projects_list():
    u = current_user()
    cat = request.args.get("category")
    q = request.args.get("q")
    query = Project.query.filter_by(user_id=u.id)
    if cat:
        query = query.filter_by(category=cat)
    if q:
        like = f"%{q}%"
        query = query.filter(Project.name.ilike(like) | Project.description.ilike(like))
    projects = query.order_by(Project.created_at.desc()).all()
    return jsonify([p.to_dict() for p in projects])


@app.route("/api/projects", methods=["POST"])
@login_required
def api_project_create():
    u = current_user()
    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"error": "项目名称不能为空"}), 400
    # 扩充色板：未指定颜色时按顺序自动分配（16 色，多项目也不易撞色）
    colors = ["#3b82f6", "#ef4444", "#10b981", "#f59e0b", "#8b5cf6", "#ec4899",
              "#06b6d4", "#84cc16", "#f97316", "#14b8a6", "#6366f1", "#d946ef",
              "#0ea5e9", "#22c55e", "#eab308", "#a855f7"]
    # 自定义标签颜色：未指定则按顺序自动分配
    color = (data.get("color") or "").strip()
    if not color:
        color = colors[Project.query.filter_by(user_id=u.id).count() % len(colors)]
    proj = Project(
        user_id=u.id,
        name=name,
        category=(data.get("category") or "其他").strip() or "其他",
        description=(data.get("description") or "").strip(),
        color=color,
    )
    db.session.add(proj)
    db.session.commit()
    return jsonify(proj.to_dict()), 201


@app.route("/api/projects/<int:pid>", methods=["GET", "PUT", "DELETE"])
@login_required
def api_project_detail(pid):
    u = current_user()
    proj = Project.query.filter_by(id=pid, user_id=u.id).first()
    if not proj:
        return jsonify({"error": "项目不存在"}), 404

    if request.method == "GET":
        return jsonify(proj.to_dict())

    if request.method == "DELETE":
        # 同时删除相关规划
        PlanItem.query.filter_by(user_id=u.id, project_id=pid).delete()
        db.session.delete(proj)
        db.session.commit()
        return jsonify({"ok": True})

    # PUT: 更新(用于版块二细化)
    data = request.get_json(silent=True) or {}
    for field in ("name", "category", "description", "location", "people"):
        if field in data:
            setattr(proj, field, data[field])
    if "expected_hours" in data:
        try:
            proj.expected_hours = max(0.5, float(data["expected_hours"]))
        except (TypeError, ValueError):
            pass
    if "funds" in data:
        try:
            proj.funds = float(data["funds"])
        except (TypeError, ValueError):
            pass
    if "steps" in data and isinstance(data["steps"], list):
        proj.steps = json.dumps(data["steps"], ensure_ascii=False)
    if "flow" in data and isinstance(data["flow"], dict):
        proj.flow = json.dumps(data["flow"], ensure_ascii=False)
    if "status" in data:
        proj.status = data["status"]
    if "color" in data:
        proj.color = data["color"]
    db.session.commit()
    return jsonify(proj.to_dict())


# ---------------------------------------------------------------------------
# 版块一：自定义分类 API（增 / 删 / 改 / 查询）
# ---------------------------------------------------------------------------
def _sanitize_cat_name(name):
    name = (name or "").strip()
    if not name:
        return None
    if len(name) > 20:
        name = name[:20]
    return name


@app.route("/api/categories", methods=["GET"])
@login_required
def api_categories_list():
    u = current_user()
    return jsonify(user_categories(u))


@app.route("/api/categories", methods=["POST"])
@login_required
def api_category_create():
    u = current_user()
    data = request.get_json(silent=True) or {}
    name = _sanitize_cat_name(data.get("name"))
    if not name:
        return jsonify({"error": "分类名称不能为空"}), 400
    if Category.query.filter_by(user_id=u.id, name=name).first():
        return jsonify({"error": "该分类已存在"}), 400
    color = (data.get("color") or "").strip() or CAT_PALETTE[
        Category.query.filter_by(user_id=u.id).count() % len(CAT_PALETTE)]
    max_order = db.session.query(db.func.max(Category.order)).filter_by(user_id=u.id).scalar() or 0
    db.session.add(Category(user_id=u.id, name=name, color=color, order=max_order + 1))
    db.session.commit()
    return jsonify(user_categories(u))


@app.route("/api/categories", methods=["PUT"])
@login_required
def api_category_update():
    u = current_user()
    data = request.get_json(silent=True) or {}
    old_name = _sanitize_cat_name(data.get("old_name"))
    new_name = _sanitize_cat_name(data.get("new_name"))
    color = (data.get("color") or "").strip()
    cat = Category.query.filter_by(user_id=u.id, name=old_name).first()
    if not cat:
        return jsonify({"error": "分类不存在"}), 404
    if new_name and new_name != old_name:
        if Category.query.filter_by(user_id=u.id, name=new_name).first():
            return jsonify({"error": "新名称已存在"}), 400
        # 同步更名：该项目下所有项目的 category 字段
        Project.query.filter_by(user_id=u.id, category=old_name).update({"category": new_name})
        cat.name = new_name
    if color:
        cat.color = color
    db.session.commit()
    return jsonify(user_categories(u))


@app.route("/api/categories/<path:name>", methods=["DELETE"])
@login_required
def api_category_delete(name):
    u = current_user()
    name = _sanitize_cat_name(name)
    if not name:
        return jsonify({"error": "分类名称无效"}), 400
    total = Category.query.filter_by(user_id=u.id).count()
    if total <= 1:
        return jsonify({"error": "至少保留一个分类"}), 400
    cat = Category.query.filter_by(user_id=u.id, name=name).first()
    if not cat:
        return jsonify({"error": "分类不存在"}), 404
    # 该分类下的项目回退到「其他」
    Project.query.filter_by(user_id=u.id, category=name).update({"category": "其他"})
    db.session.delete(cat)
    db.session.commit()
    return jsonify(user_categories(u))


# ---------------------------------------------------------------------------
# 版块三：固定安排 API
# ---------------------------------------------------------------------------
@app.route("/api/fixed", methods=["GET", "POST"])
@login_required
def api_fixed():
    u = current_user()
    if request.method == "GET":
        items = FixedSchedule.query.filter_by(user_id=u.id).all()
        return jsonify([f.to_dict() for f in items])

    data = request.get_json(silent=True) or {}
    title = (data.get("title") or "").strip()
    start = float(data.get("start_hour", 0))
    end = float(data.get("end_hour", 0))
    # 多选日期：days=[1,3,5]；兼容旧的单天 day_of_week
    days = data.get("days")
    if not isinstance(days, list) or not days:
        days = [data.get("day_of_week", 0)]
    try:
        days = sorted({int(d) for d in days})
    except (TypeError, ValueError):
        return jsonify({"error": "星期参数无效"}), 400
    if (not title or not days or days[0] < 1 or days[-1] > 7 or start < 0
            or start >= 24 or end <= 0 or end > 24 or start == end):
        return jsonify({"error": "固定安排参数无效"}), 400
    items = []
    # 颜色：优先用户指定；否则按名称自动分配醒目颜色（同名同色，不同名称不同色）
    f_color = (data.get("color") or "").strip() or fixed_auto_color(title)
    for d in days:
        it = FixedSchedule(
            user_id=u.id, title=title, day_of_week=d,
            start_hour=start, end_hour=end,
            color=f_color,
        )
        db.session.add(it)
        items.append(it)
    db.session.commit()
    return jsonify([i.to_dict() for i in items]), 201


@app.route("/api/fixed/<int:fid>", methods=["DELETE"])
@login_required
def api_fixed_delete(fid):
    u = current_user()
    item = FixedSchedule.query.filter_by(id=fid, user_id=u.id).first()
    if not item:
        return jsonify({"error": "不存在"}), 404
    db.session.delete(item)
    db.session.commit()
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# 版块三：可规划部分 API
# ---------------------------------------------------------------------------
@app.route("/api/plan", methods=["GET", "POST"])
@login_required
def api_plan():
    u = current_user()
    if request.method == "GET":
        plans = PlanItem.query.filter_by(user_id=u.id).all()
        result = []
        for p in plans:
            proj = Project.query.get(p.project_id)
            result.append(p.to_dict(proj))
        return jsonify(result)

    data = request.get_json(silent=True) or {}
    pid = int(data.get("project_id", 0))
    day = int(data.get("day_of_week", 0))
    start = float(data.get("start_hour", 0))
    proj = Project.query.filter_by(id=pid, user_id=u.id).first()
    if not proj:
        return jsonify({"error": "项目不存在"}), 404
    # 单次预期用时：可单独调节，默认取项目总预估；若放置的是步骤，默认取步骤时长
    step_id = (data.get("step_id") or "").strip()
    default_dur = proj.expected_hours
    if step_id:
        node = find_step(proj.get_steps(), step_id)
        if not node:
            return jsonify({"error": "步骤不存在"}), 404
        if node.get("hours"):
            default_dur = float(node["hours"])
    try:
        duration = float(data.get("duration") or 0) or default_dur
    except (TypeError, ValueError):
        duration = default_dur
    if duration <= 0 or duration > 24:
        return jsonify({"error": "单次用时无效"}), 400
    end = start + duration
    if day < 1 or day > 7 or start < 0 or end > 24:
        return jsonify({"error": "时间超出范围"}), 400
    conflict = check_plan_conflict(u.id, day, start, end)
    if conflict:
        return jsonify({"error": conflict}), 409
    item = PlanItem(
        user_id=u.id, project_id=pid, step_id=step_id, day_of_week=day,
        start_hour=start, duration=duration,
        note=(data.get("note") or "").strip(),
    )
    db.session.add(item)
    db.session.commit()
    # 更新项目状态
    proj.status = "planned"
    db.session.commit()
    return jsonify(item.to_dict(proj)), 201


@app.route("/api/plan/<int:plid>", methods=["PUT", "DELETE"])
@login_required
def api_plan_detail(plid):
    u = current_user()
    item = PlanItem.query.filter_by(id=plid, user_id=u.id).first()
    if not item:
        return jsonify({"error": "不存在"}), 404

    if request.method == "DELETE":
        db.session.delete(item)
        db.session.commit()
        # 若该项目的所有规划都被删除, 回到 idea 状态
        remain = PlanItem.query.filter_by(user_id=u.id, project_id=item.project_id).count()
        if remain == 0:
            proj = db.session.get(Project, item.project_id)
            if proj:
                proj.status = "idea"
                db.session.commit()
        return jsonify({"ok": True})

    # PUT: 修改计划时间/单次用时，或记录实际开始结束、标记完成
    data = request.get_json(silent=True) or {}
    # 支持替换为其他项目（编辑弹窗中的「替换为其他项目/步骤」）
    if "project_id" in data:
        try:
            new_pid = int(data["project_id"])
        except (TypeError, ValueError):
            return jsonify({"error": "项目参数无效"}), 400
        if new_pid != item.project_id:
            new_proj = Project.query.filter_by(id=new_pid, user_id=u.id).first()
            if not new_proj:
                return jsonify({"error": "项目不存在"}), 404
            item.project_id = new_pid
    if "step_id" in data:
        sid = (data.get("step_id") or "").strip()
        if sid:
            proj_chk = db.session.get(Project, item.project_id)
            if not find_step((proj_chk.get_steps() if proj_chk else []), sid):
                return jsonify({"error": "步骤不存在"}), 404
        item.step_id = sid
    if "start_hour" in data or "duration" in data:
        sh = float(data["start_hour"]) if "start_hour" in data else item.start_hour
        dur = float(data["duration"]) if "duration" in data else (item.duration or 1.0)
        if dur <= 0 or dur > 24:
            return jsonify({"error": "单次用时无效"}), 400
        end = sh + dur
        if sh < 0 or end > 24:
            return jsonify({"error": "时间超出范围"}), 400
        conflict = check_plan_conflict(u.id, item.day_of_week, sh, end, exclude_id=item.id)
        if conflict:
            return jsonify({"error": conflict}), 409
        item.start_hour = sh
        item.duration = dur
    if "note" in data:
        item.note = (data.get("note") or "").strip()
    if "actual_start" in data:
        item.actual_start = parse_dt(data["actual_start"])
    if "actual_end" in data:
        item.actual_end = parse_dt(data["actual_end"])
    if "done" in data:
        item.done = bool(data["done"])
        # 完成后若填了实际时间则同步项目状态
        if item.done:
            proj = db.session.get(Project, item.project_id)
            if proj and proj.status != "done":
                proj.status = "done"
    db.session.commit()
    proj = db.session.get(Project, item.project_id)
    return jsonify(item.to_dict(proj))


# ---------------------------------------------------------------------------
# 版块三：网格汇总 (固定 + 规划 + 剩余可规划)
# ---------------------------------------------------------------------------
@app.route("/api/grid", methods=["GET"])
@login_required
def api_grid():
    u = current_user()
    reset_count = ensure_week(u)
    fixed = FixedSchedule.query.filter_by(user_id=u.id).all()
    plans = PlanItem.query.filter_by(user_id=u.id).all()
    projects = {p.id: p for p in Project.query.filter_by(user_id=u.id).all()}

    fixed_out = [f.to_dict() for f in fixed]
    plan_out = [p.to_dict(projects.get(p.project_id)) for p in plans]

    # 按天统计剩余可规划小时
    remaining = {}
    for day in range(1, 8):
        occupied = 0.0
        for f in fixed:
            if f.day_of_week == day:
                for (s, e) in fixed_intervals(f):
                    occupied += max(0.0, e - s)
        for p in plans:
            if p.day_of_week == day:
                occupied += p.duration if p.duration else 1.0
        remaining[day] = round(max(0.0, 24.0 - occupied), 1)

    return jsonify({
        "days": DAY_NAMES,
        "week": week_key(),
        "week_num": iso_week_num()[1],
        "reset_count": reset_count,
        "fixed": fixed_out,
        "plan": plan_out,
        "remaining": remaining,
        "total_remaining": round(sum(remaining.values()), 1),
    })


# ---------------------------------------------------------------------------
# 版块三/四：每周规划归档 API
# ---------------------------------------------------------------------------
def _week_entry(week_start, year, week, stats, current=False):
    e = {"week_start": week_start, "year": year, "week": week, "current": current}
    e.update(stats)
    e.pop("by_day", None)       # 列表接口不携带按天明细（未完成清单保留，看板要用）
    return e


@app.route("/api/weekly", methods=["GET"])
@login_required
def api_weekly():
    """周完成情况总览：当前周（实时）+ 所有归档周，按周开始日期倒序"""
    u = current_user()
    ensure_week(u)
    weeks = []
    # 当前周：实时计算
    cur = week_key()
    items = PlanItem.query.filter_by(user_id=u.id).all()
    projects = {p.id: p for p in Project.query.filter_by(user_id=u.id).all()}
    live = []
    for p in items:
        proj = projects.get(p.project_id)
        step_name = ""
        if p.step_id and proj:
            node = find_step(proj.get_steps(), p.step_id)
            step_name = node.get("name", "") if node else ""
        live.append({
            "project_name": proj.name if proj else "",
            "step_name": step_name,
            "category": proj.category if proj else "其他",
            "day_of_week": p.day_of_week,
            "duration": p.duration if p.duration else 1.0,
            "done": bool(p.done),
        })
    iy, iw = iso_week_num()
    weeks.append(_week_entry(cur, iy, iw, _week_stats(live), current=True))
    # 归档周
    archives = (WeeklyArchive.query.filter_by(user_id=u.id)
                .order_by(WeeklyArchive.week_start.desc()).all())
    for a in archives:
        weeks.append(_week_entry(a.week_start, a.year, a.week, a.get_data().get("stats", {})))
    return jsonify({"current_week": cur, "weeks": weeks})


@app.route("/api/weeks/<week_start>", methods=["GET"])
@login_required
def api_week_detail(week_start):
    """某一周的完整归档明细（items + stats）。当前周实时返回。"""
    u = current_user()
    try:
        datetime.strptime(week_start, "%Y-%m-%d")
    except ValueError:
        return jsonify({"error": "周日期格式无效"}), 400
    cur = week_key()
    if week_start == cur:
        items = PlanItem.query.filter_by(user_id=u.id).all()
        projects = {p.id: p for p in Project.query.filter_by(user_id=u.id).all()}
        live = []
        for p in items:
            proj = projects.get(p.project_id)
            step_name = ""
            if p.step_id and proj:
                node = find_step(proj.get_steps(), p.step_id)
                step_name = node.get("name", "") if node else ""
            actual = None
            if p.actual_start and p.actual_end:
                actual = round((p.actual_end - p.actual_start).total_seconds() / 3600.0, 2)
            live.append({
                "project_id": p.project_id,
                "project_name": proj.name if proj else "",
                "step_name": step_name,
                "category": proj.category if proj else "其他",
                "color": proj.color if proj else "#3b82f6",
                "day_of_week": p.day_of_week,
                "start_hour": p.start_hour,
                "duration": p.duration if p.duration else 1.0,
                "done": bool(p.done),
                "actual_hours": actual,
            })
        iy, iw = iso_week_num()
        return jsonify({"week_start": week_start, "year": iy, "week": iw,
                        "current": True, "items": live, "stats": _week_stats(live)})
    a = WeeklyArchive.query.filter_by(user_id=u.id, week_start=week_start).first()
    if not a:
        return jsonify({"error": "该周无归档"}), 404
    d = a.get_data()
    return jsonify({"week_start": week_start, "year": a.year, "week": a.week,
                    "current": False, "items": d.get("items", []),
                    "stats": d.get("stats", {}), "archived_at": d.get("archived_at")})


@app.route("/api/week/reset", methods=["POST"])
@login_required
def api_week_reset():
    """手动「立即重置本周」：把当前可规划区全部归档到本周并清空（固定安排不动）"""
    u = current_user()
    items = PlanItem.query.filter_by(user_id=u.id).all()
    if not items:
        return jsonify({"ok": True, "archived": 0})
    n = archive_week_snapshot(u.id, week_key(), items, merge=True)
    for p in items:
        db.session.delete(p)
    db.session.commit()
    return jsonify({"ok": True, "archived": n, "week": week_key()})


# ---------------------------------------------------------------------------
# 第四板块：数据统计 (预期/实际/起止/类别)
# ---------------------------------------------------------------------------
@app.route("/api/stats", methods=["GET"])
@login_required
def api_stats():
    u = current_user()
    plans = PlanItem.query.filter_by(user_id=u.id).all()
    projects = {p.id: p for p in Project.query.filter_by(user_id=u.id).all()}

    proj_stats = []
    for pid, proj in projects.items():
        ps = [p for p in plans if p.project_id == pid]
        planned = round(sum((p.duration or 0) for p in ps), 2)
        done_hours = round(sum((p.duration or 0) for p in ps if p.done), 2)
        actual = round(sum(
            (p.actual_end - p.actual_start).total_seconds() / 3600.0
            for p in ps if p.actual_start and p.actual_end), 2)
        proj_stats.append({
            "id": proj.id,
            "name": proj.name,
            "category": proj.category,
            "color": proj.color,
            "planned_hours": planned,
            "done_hours": done_hours,
            "undone_hours": round(max(0.0, planned - done_hours), 2),
            "actual_hours": actual,
            "placements": len(ps),
            "done": sum(1 for p in ps if p.done),
            "total_expected": proj.expected_hours,  # 版块二「总预估」
        })
    proj_stats.sort(key=lambda x: -(x["planned_hours"] + x["actual_hours"]))

    # 按类别聚合
    cat_map = {}
    for s in proj_stats:
        c = s["category"]
        if c not in cat_map:
            cat_map[c] = {"category": c, "planned_hours": 0.0,
                          "actual_hours": 0.0, "count": 0}
        cat_map[c]["planned_hours"] += s["planned_hours"]
        cat_map[c]["actual_hours"] += s["actual_hours"]
        cat_map[c]["count"] += 1
    categories = sorted(cat_map.values(), key=lambda x: -(x["planned_hours"] + x["actual_hours"]))

    summary = {
        "project_count": len(projects),
        "placement_count": len(plans),
        "planned_total": round(sum(p["planned_hours"] for p in proj_stats), 2),
        "actual_total": round(sum(p["actual_hours"] for p in proj_stats), 2),
        "done_total": sum(p["done"] for p in proj_stats),
    }
    return jsonify({"projects": proj_stats, "categories": categories, "summary": summary})


# ---------------------------------------------------------------------------
# 启动
# ---------------------------------------------------------------------------
def init_db():
    with app.app_context():
        db.create_all()
        migrate_plan_item()
        migrate_fixed_colors()
        migrate_project_flow()
        if User.query.count() == 0:
            admin = User(username="admin",
                         password_hash=generate_password_hash("admin123"))
            db.session.add(admin)
            db.session.commit()
            print("[init] 已创建默认管理员 admin / admin123")


def migrate_plan_item():
    """为已存在的 plan_item 表补齐新列（SQLite 下 create_all 不会自动加列）。"""
    from sqlalchemy import inspect as sa_inspect, text
    insp = sa_inspect(db.engine)
    if not insp.has_table("plan_item"):
        return
    cols = [c["name"] for c in insp.get_columns("plan_item")]
    adds = []
    if "duration" not in cols:
        adds.append("ALTER TABLE plan_item ADD COLUMN duration FLOAT DEFAULT 1.0")
    if "step_id" not in cols:
        adds.append("ALTER TABLE plan_item ADD COLUMN step_id VARCHAR(50) DEFAULT ''")
    if "actual_start" not in cols:
        adds.append("ALTER TABLE plan_item ADD COLUMN actual_start DATETIME")
    if "actual_end" not in cols:
        adds.append("ALTER TABLE plan_item ADD COLUMN actual_end DATETIME")
    if "done" not in cols:
        adds.append("ALTER TABLE plan_item ADD COLUMN done BOOLEAN DEFAULT 0")
    for sql in adds:
        try:
            with db.engine.begin() as conn:
                conn.execute(text(sql))
            print("[migrate] " + sql)
        except Exception as e:
            print("[migrate] 跳过: " + str(e))


def migrate_fixed_colors():
    """固定安排颜色升级：补 color 列；旧的浅灰色块按名称自动分配醒目颜色。"""
    from sqlalchemy import inspect as sa_inspect, text
    insp = sa_inspect(db.engine)
    if not insp.has_table("fixed_schedule"):
        return
    cols = [c["name"] for c in insp.get_columns("fixed_schedule")]
    if "color" not in cols:
        try:
            with db.engine.begin() as conn:
                conn.execute(text(
                    "ALTER TABLE fixed_schedule ADD COLUMN color VARCHAR(20) DEFAULT '#94a3b8'"))
            print("[migrate] fixed_schedule 增加 color 列")
        except Exception as e:
            print("[migrate] 跳过: " + str(e))


def migrate_project_flow():
    """为已存在的 project 表补齐 flow 列（流程图数据）。"""
    from sqlalchemy import inspect as sa_inspect, text
    insp = sa_inspect(db.engine)
    if not insp.has_table("project"):
        return
    cols = [c["name"] for c in insp.get_columns("project")]
    if "flow" not in cols:
        try:
            with db.engine.begin() as conn:
                conn.execute(text("ALTER TABLE project ADD COLUMN flow TEXT DEFAULT ''"))
            print("[migrate] project 增加 flow 列")
        except Exception as e:
            print("[migrate] 跳过: " + str(e))
            return
    olds = FixedSchedule.query.filter(
        (FixedSchedule.color.is_(None)) | (FixedSchedule.color == "") |
        (FixedSchedule.color == "#94a3b8")).all()
    if olds:
        for f in olds:
            f.color = fixed_auto_color(f.title)
        db.session.commit()
        print(f"[migrate] 已为 {len(olds)} 条旧固定安排重新配色")


def _graceful_shutdown(signum, frame):
    """收到 SIGTERM/SIGINT（如 docker stop / 飞牛关闭容器）时优雅退出，
    避免超时被 SIGKILL（退出码 137）"""
    import signal as _signal
    print(f"[shutdown] 收到信号 {_signal.Signals(signum).name}，正在优雅退出…", flush=True)
    try:
        db.session.remove()
    except Exception:
        pass
    sys.exit(0)


if __name__ == "__main__":
    import signal
    import sys
    signal.signal(signal.SIGTERM, _graceful_shutdown)
    signal.signal(signal.SIGINT, _graceful_shutdown)
    init_db()
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
