/* Idea: Do it — 前端逻辑 */
(function () {
  "use strict";
  const HOUR_H = 38; // 与 CSS .hour-cell 高度一致
  const CAT_COLORS = { "工作": "#3b82f6", "学习": "#10b981", "生活": "#f59e0b", "运动": "#ef4444", "娱乐": "#8b5cf6", "其他": "#94a3b8" };
  // 分类配色：优先取后端下发的自定义颜色，回退到内置默认
  function catColor(name) {
    return (window.APP && window.APP.catColors && window.APP.catColors[name]) || CAT_COLORS[name] || "#94a3b8";
  }
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

  // 自动识别部署前缀（子路径反代场景）：
  // 从本脚本自身的 URL 推导，如 /idea/static/app.js -> 前缀 /idea
  function detectBase() {
    try {
      const src = (document.currentScript && document.currentScript.src) || "";
      if (!src) return "";
      const u = new URL(src, window.location.href);
      const m = u.pathname.replace(/\/static\/app\.js$/, "");
      return m || "";
    } catch (e) { return ""; }
  }
  const BASE = detectBase();

  async function api(method, url, body) {
    const full = BASE + url; // 统一带上部署前缀
    const opt = { method, headers: {} };
    if (body !== undefined) {
      opt.headers["Content-Type"] = "application/json";
      opt.body = JSON.stringify(body);
    }
    const res = await fetch(full, opt);
    let data = null;
    try { data = await res.json(); } catch (e) {}
    if (!res.ok) {
      const msg = (data && (data.error || data.err)) || ("请求失败 " + res.status);
      throw new Error(msg);
    }
    return data;
  }

  // kind: "ok" 普通 / "err" 错误(红) / "done" 完成(绿，明显提示)
  function toast(msg, kind = "ok") {
    if (kind === false) kind = "err";
    if (kind === true) kind = "ok";
    let t = $(".toast");
    if (!t) { t = document.createElement("div"); t.className = "toast"; document.body.appendChild(t); }
    t.textContent = msg;
    t.style.background = kind === "err" ? "#b91c1c" : (kind === "done" ? "#059669" : "#0f172a");
    t.style.fontWeight = kind === "done" ? "700" : "500";
    t.classList.add("show");
    clearTimeout(t._t);
    t._t = setTimeout(() => t.classList.remove("show"), kind === "done" ? 3200 : 2200);
  }

  function openModal(html, extraCls) {
    const box = $("#modalBox");
    box.className = "modal" + (extraCls ? " " + extraCls : "");
    box.innerHTML = html;
    $("#modalMask").classList.remove("hidden");
  }
  function closeModal() { $("#modalMask").classList.add("hidden"); }

  /* ============ 公共工具：步骤树 / 日期 ============ */
  function uid() { return "n" + Math.random().toString(36).slice(2, 9); }

  // 把旧格式（字符串数组）或任意来源的步骤数据规整为节点树 [{id,name,hours,children:[]}]
  // kind: "decision"=判断 / "end"=结束（由流程图同步生成），普通步骤无 kind
  function normSteps(list) {
    return (Array.isArray(list) ? list : []).map((s) => {
      if (typeof s === "string") return { id: uid(), name: s, hours: "", children: [] };
      return {
        id: s.id || uid(),
        name: s.name || "未命名步骤",
        hours: s.hours ? Number(s.hours) : "",
        children: normSteps(s.children),
        ...(s.kind ? { kind: s.kind } : {}),
      };
    });
  }

  function findStepNode(nodes, sid) {
    for (const n of nodes) {
      if (n.id === sid) return n;
      const f = findStepNode(n.children || [], sid);
      if (f) return f;
    }
    return null;
  }

  // ISO 周数
  function isoWeek(d) {
    const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    const dayNum = date.getUTCDay() || 7;
    date.setUTCDate(date.getUTCDate() + 4 - dayNum);
    const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
    return Math.ceil((((date - yearStart) / 86400000) + 1) / 7);
  }

  function updateDateInfo() {
    const el = $("#dateInfo");
    if (!el) return;
    const now = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    const dows = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"];
    el.textContent = `📅 今天：${now.getFullYear()}年${now.getMonth() + 1}月${now.getDate()}日 · 第 ${isoWeek(now)} 周 · ${dows[now.getDay()]}`;
  }
  // 今日星期（1=周一 … 7=周日），用于高亮当天列
  function todayDow() { const d = new Date().getDay(); return d === 0 ? 7 : d; }

  /* ============ 登录 / 注册页 ============ */
  // 灯泡动效：lit = 灯亮一下（成功）；fail = 闪红灯（失败）
  function bulbFlash(kind) {
    const wrap = $("#bulbWrap");
    if (!wrap) return;
    wrap.classList.remove("lit", "fail");
    void wrap.offsetWidth; // 重置动画状态
    wrap.classList.add(kind);
    setTimeout(() => wrap.classList.remove(kind), kind === "fail" ? 700 : 660);
  }

  function initAuth() {
    const loginForm = $("#loginForm");
    if (!loginForm) return;
    const msg = $("#authMsg");
    const afterAuth = async (p) => {
      // 登录/注册成功：灯亮一下，再跳转
      msg.textContent = "登录成功，灯亮了 ✦";
      msg.classList.add("ok");
      bulbFlash("lit");
      setTimeout(() => { location.href = "/dashboard"; }, 680);
    };
    const onFail = (err) => {
      msg.textContent = err.message || "操作失败";
      msg.classList.remove("ok");
      bulbFlash("fail");
    };
    $$(".auth-tab").forEach((b) => {
      b.onclick = () => {
        $$(".auth-tab").forEach((x) => x.classList.remove("active"));
        b.classList.add("active");
        const tab = b.dataset.tab;
        $("#loginForm").classList.toggle("hidden", tab !== "login");
        $("#registerForm").classList.toggle("hidden", tab !== "register");
        msg.textContent = "";
      };
    });
    loginForm.onsubmit = async (e) => {
      e.preventDefault();
      msg.textContent = ""; msg.classList.remove("ok");
      try {
        await api("POST", "/api/login", { username: $("#loginUser").value, password: $("#loginPass").value });
        afterAuth();
      } catch (err) { onFail(err); }
    };
    $("#registerForm").onsubmit = async (e) => {
      e.preventDefault();
      msg.textContent = ""; msg.classList.remove("ok");
      try {
        await api("POST", "/api/register", { username: $("#regUser").value, password: $("#regPass").value });
        afterAuth();
      } catch (err) { onFail(err); }
    };
  }

  /* ============ 账户设置：修改账户名 / 密码 ============ */
  function openAccountModal() {
    openModal(`
      <h3>账户设置</h3>
      <div class="acct-sec">
        <h4>修改账户名</h4>
        <p class="muted small">修改后，下次登录需使用新账户名。</p>
        <form id="acctNameForm" class="acct-form">
          <label>当前密码（验证身份）</label>
          <input type="password" id="acctNameCur" placeholder="请输入当前密码" autocomplete="current-password">
          <label>新账户名</label>
          <input type="text" id="acctNameNew" placeholder="请输入新的登录账号" autocomplete="off">
          <button type="submit" class="btn-primary">保存账户名</button>
        </form>
      </div>
      <div class="acct-sec">
        <h4>修改密码</h4>
        <p class="muted small">修改后，下次登录需使用新密码。</p>
        <form id="acctPwForm" class="acct-form">
          <label>当前密码（验证身份）</label>
          <input type="password" id="acctPwCur" placeholder="请输入当前密码" autocomplete="current-password">
          <label>新密码（至少 6 位）</label>
          <input type="password" id="acctPwNew" placeholder="请输入新密码" autocomplete="new-password">
          <label>确认新密码</label>
          <input type="password" id="acctPwNew2" placeholder="请再次输入新密码" autocomplete="new-password">
          <button type="submit" class="btn-primary">保存密码</button>
        </form>
      </div>
      <div class="modal-actions">
        <span></span>
        <button class="btn-ghost" id="acctCloseBtn">关闭</button>
      </div>
    `);
    $("#acctCloseBtn").onclick = closeModal;
    $("#acctNameForm").onsubmit = async (e) => {
      e.preventDefault();
      const cur = $("#acctNameCur").value, nw = $("#acctNameNew").value.trim();
      if (!cur || !nw) { toast("请填写当前密码和新账户名", false); return; }
      try {
        const r = await api("POST", "/api/account/username", { current_password: cur, new_username: nw });
        window.__me = r.user.username;
        $("#who").textContent = "当前用户：" + r.user.username;
        toast("账户名已修改为 " + r.user.username, "done");
        closeModal();
      } catch (err) { toast(err.message, false); }
    };
    $("#acctPwForm").onsubmit = async (e) => {
      e.preventDefault();
      const cur = $("#acctPwCur").value, nw = $("#acctPwNew").value, nw2 = $("#acctPwNew2").value;
      if (!cur || !nw) { toast("请填写当前密码和新密码", false); return; }
      if (nw !== nw2) { toast("两次输入的新密码不一致", false); return; }
      try {
        await api("POST", "/api/account/password", { current_password: cur, new_password: nw });
        toast("密码已修改，下次登录请使用新密码", "done");
        closeModal();
      } catch (err) { toast(err.message, false); }
    };
  }

  /* ============ 仪表盘 ============ */
  let PROJECTS = [];
  let p1Cat = "全部";

  function initDashboard() {
    $("#who").textContent = "当前用户：" + (window.__me || "");
    $$(".nav-item").forEach((b) => {
      b.onclick = () => {
        $$(".nav-item").forEach((x) => x.classList.remove("active"));
        b.classList.add("active");
        $$(".view").forEach((v) => v.classList.remove("active"));
        $("#view-" + b.dataset.view).classList.add("active");
        if (b.dataset.view === "p1") renderP1Chart(true);
        if (b.dataset.view === "p3") renderGrid();
        if (b.dataset.view === "p4") renderStats();
      };
    });
    $("#logoutBtn").onclick = async () => {
      await api("POST", "/api/logout"); location.href = "/login";
    };
    $("#accountBtn").onclick = openAccountModal;
    $("#modalMask").onclick = (e) => { if (e.target.id === "modalMask") closeModal(); };

    // 版块一
    buildChips();
    $("#p1Search").oninput = () => renderProjGrid();
    $("#newProjBtn").onclick = () => showNewProjectModal(); // 注意：不能直接传函数引用，否则 event 会被误当成项目对象
    bindPolar(); // 极坐标堆叠图：悬停提示 + 点击过渡到列表

    // 版块二
    $("#refineGrid"); // populated in loadProjects
    document.querySelectorAll(".fc-add").forEach((b) => { b.onclick = () => flowAddNode(b.dataset.type); });
    $("#fcBack").onclick = () => { flowSave(); FLOW.proj = null; $("#refineBoard").classList.add("hidden"); renderRefineGrid(); };
    $("#fcProps").onclick = () => { if (FLOW.proj) openWizard(FLOW.proj); };
    $("#fcRebuild").onclick = () => {
      if (!FLOW.proj) return;
      if (!confirm("按「详细信息」的层级重建全部连线：开始→各顶层步骤、父步骤→子步骤。现有连线（含手动画的）会被替换，确定？")) return;
      const byStep = new Map();
      FLOW.nodes.forEach((n) => { if (isContentNode(n) && n.stepId) byStep.set(n.stepId, n); });
      const start = FLOW.nodes.find((n) => n.type === "start");
      if (!start) { toast("请先添加「开始」节点", false); return; }
      rebuildTreeEdges(byStep, start.id);
      FLOW.sel = null;
      flowTouch(); flowRender();
      toast("已按详细信息层级重排连线");
    };
    $("#fcHintClose").onclick = () => { $("#fcHint").classList.add("hidden"); };
    $$("#fcAlignBar button").forEach((b) => { b.onclick = () => flowAlign(b.dataset.al); });
    $("#fcCanvas").addEventListener("click", (ev) => {
      if (ev.target === $("#fcCanvas") || ev.target === $("#fcSvg")) {
        if (FLOW.__skipClick) { FLOW.__skipClick = false; return; } // 框选结束后的 click 不清空选择
        FLOW.multi.clear(); FLOW.sel = null; flowRender();
      }
    });
    // 空白处按下拖动 → 框选多个节点（Ctrl/Shift 按住则在原选择基础上追加）
    $("#fcCanvas").addEventListener("mousedown", (ev) => {
      if (!FLOW.proj || ev.button !== 0) return;
      if (ev.target !== $("#fcCanvas") && ev.target !== $("#fcSvg")) return;
      const canvas = $("#fcCanvas");
      const pt = (cv) => {
        const r = canvas.getBoundingClientRect();
        return [cv.clientX - r.left + canvas.scrollLeft, cv.clientY - r.top + canvas.scrollTop];
      };
      const [sx, sy] = pt(ev);
      const keep = (ev.ctrlKey || ev.metaKey || ev.shiftKey) ? new Set(FLOW.multi) : null;
      let box = null, moved = false;
      const move = (mv) => {
        const [cx, cy] = pt(mv);
        if (!moved && Math.abs(cx - sx) + Math.abs(cy - sy) < 4) return;
        moved = true;
        const x1 = Math.min(sx, cx), y1 = Math.min(sy, cy);
        const x2 = Math.max(sx, cx), y2 = Math.max(sy, cy);
        if (!box) { box = document.createElement("div"); box.className = "fc-marquee"; canvas.appendChild(box); }
        box.style.left = x1 + "px"; box.style.top = y1 + "px";
        box.style.width = (x2 - x1) + "px"; box.style.height = (y2 - y1) + "px";
        if (keep) FLOW.multi = new Set(keep); else FLOW.multi.clear();
        FLOW.nodes.forEach((n) => {
          const [w, h] = nodeWH(n);
          if (n.x < x2 && n.x + w > x1 && n.y < y2 && n.y + h > y1) FLOW.multi.add(n.id);
        });
        FLOW.sel = null;
        flowRender();
      };
      const up = () => {
        document.removeEventListener("mousemove", move);
        document.removeEventListener("mouseup", up);
        if (box) box.remove();
        if (moved) FLOW.__skipClick = true;
      };
      document.addEventListener("mousemove", move);
      document.addEventListener("mouseup", up);
    });
    $("#fcCanvas").addEventListener("click", (ev) => {
      if (ev.target === $("#fcCanvas") || ev.target === $("#fcSvg")) { FLOW.sel = null; flowRender(); }
    });
    window.addEventListener("beforeunload", flowSave);

    // 版块三
    $("#manageFixedBtn").onclick = showFixedManager;
    $("#weekArchiveBtn").onclick = showWeekArchive;
    $("#resetWeekBtn").onclick = resetWeekConfirm;
    $("#modeIso").onclick = () => setGridMode("iso");
    $("#modeFlat").onclick = () => setGridMode("flat");
    $("#planProjSel").onchange = () => { /* 仅记录选择，点击格子时使用 */ };
    $("#refreshStatsBtn").onclick = () => renderStats();

    loadCategories().then(loadProjects);
  }

  async function loadProjects() {
    PROJECTS = await api("GET", "/api/projects");
    buildChips();
    renderProjGrid();
    renderP1Chart(true);
    renderRefineGrid();
    renderPlanSel();
  }

  function buildChips() {
    const cats = ["全部", ...window.APP.categories];
    const box = $("#p1Cats");
    box.innerHTML = "";
    cats.forEach((c) => {
      const el = document.createElement("button");
      el.className = "chip" + (c === p1Cat ? " active" : "");
      el.textContent = c;
      el.onclick = () => selectCategory(c);
      box.appendChild(el);
    });
    const mg = document.createElement("button");
    mg.className = "chip chip-manage";
    mg.textContent = "⚙ 管理";
    mg.title = "自定义分类（新增 / 改名 / 改色 / 删除）";
    mg.onclick = openCategoryManager;
    box.appendChild(mg);
  }

  // 选择分类：全部→总览极坐标图；具体分类→该分类的扇形图
  function selectCategory(c) {
    p1Cat = c;
    buildChips();
    setP1View("chart"); // setP1View 在显示图表面板后会自动重播入场动画（总览或扇形图）
  }

  async function loadCategories() {
    try {
      const cs = await api("GET", "/api/categories");
      window.APP.categories = cs.map((c) => c.name);
      window.APP.catColors = {};
      cs.forEach((c) => { window.APP.catColors[c.name] = c.color; });
    } catch (e) { /* 保留服务端注入的初始值 */ }
  }

  // 分类变更后：重新拉取分类并刷新所有依赖（分类条 / 网格 / 图表 / 项目数据）
  async function refreshAfterCategoryChange() {
    await loadCategories();
    // 若当前选中的分类被删，回退到「全部」
    if (p1Cat !== "全部" && !window.APP.categories.includes(p1Cat)) p1Cat = "全部";
    buildChips();
    renderProjGrid();
    renderP1Chart(false);
  }

  function openCategoryManager() {
    const rows = (window.APP.categories || []).map((c) => `
      <div class="catmgr-row" data-name="${esc(c)}">
        <input type="color" class="cm-color" value="${esc(window.APP.catColors[c] || "#3b82f6")}">
        <input type="text" class="cm-name" value="${esc(c)}" maxlength="20">
        <button class="btn-ghost cm-del" title="删除该分类（其项目将归入「其他」）">删除</button>
      </div>`).join("");
    const html = `
      <div class="catmgr">
        <h3>管理分类</h3>
        <p class="muted small">自定义版块一的分类：可改名、改颜色、删除；也可新增（如「旅行」）。</p>
        <div id="catMgrList">${rows}</div>
        <div class="catmgr-add">
          <input type="color" id="catNewColor" value="#3b82f6">
          <input type="text" id="catNewName" placeholder="新分类名称（如 旅行）" maxlength="20">
          <button class="btn-primary" id="catAddBtn">+ 新增</button>
        </div>
        <div class="catmgr-foot"><button class="btn-ghost" id="catMgrDone">完成</button></div>
      </div>`;
    openModal(html, "catmgr-modal");

    const list = $("#catMgrList");
    // 改色 / 改名（失焦或回车时保存）
    list.querySelectorAll(".catmgr-row").forEach((row) => {
      const old = row.dataset.name;
      const colorI = row.querySelector(".cm-color");
      const nameI = row.querySelector(".cm-name");
      const save = async () => {
        const newName = nameI.value.trim();
        if (!newName) { nameI.value = old; return; }
        try {
          await api("PUT", "/api/categories", { old_name: old, new_name: newName, color: colorI.value });
          toast("已保存", true);
          await refreshAfterCategoryChange();
          openCategoryManager(); // 重建弹窗以同步数据
        } catch (e) { toast(e.message, false); nameI.value = old; }
      };
      colorI.onchange = save;
      nameI.onblur = save;
      nameI.onkeydown = (e) => { if (e.key === "Enter") nameI.blur(); };
      row.querySelector(".cm-del").onclick = async () => {
        if (!confirm("删除分类「" + old + "」？其下项目将归入「其他」。")) return;
        try {
          await api("DELETE", "/api/categories/" + encodeURIComponent(old));
          toast("已删除", true);
          await refreshAfterCategoryChange();
          openCategoryManager();
        } catch (e) { toast(e.message, false); }
      };
    });
    $("#catAddBtn").onclick = async () => {
      const name = $("#catNewName").value.trim();
      if (!name) { toast("请输入分类名称", false); return; }
      try {
        await api("POST", "/api/categories", { name, color: $("#catNewColor").value });
        toast("已新增", true);
        await refreshAfterCategoryChange();
        openCategoryManager();
      } catch (e) { toast(e.message, false); }
    };
    $("#catMgrDone").onclick = closeModal;
  }

  let collapsedCats = new Set(); // 折叠的类别

  function projCard(p) {
    const stTxt = { idea: "想法", planned: "已规划", done: "已完成" }[p.status] || p.status;
    const card = document.createElement("div");
    card.className = "pcard";
    card.style.borderLeftColor = p.color;
    card.innerHTML = `
      <div class="pc-top">
        <h3>${esc(p.name)}</h3>
        <span class="tag" style="background:${p.color}1a;color:${p.color}">${esc(p.category)}</span>
      </div>
      <div class="desc">${esc(p.description || "（暂无描述）")}</div>
      <div class="meta">
        <span><span class="status-dot st-${p.status}"></span>${stTxt}</span>
        <span>⏱ <b>${p.expected_hours}h</b></span>
        ${p.location ? `<span>📍 ${esc(p.location)}</span>` : ""}
        ${p.people ? `<span>👤 ${esc(p.people)}</span>` : ""}
        ${p.funds ? `<span>💰 ${p.funds}</span>` : ""}
      </div>
      <div class="pc-actions">
        <button class="btn-ghost" data-act="refine">细化</button>
        <button class="btn-ghost" data-act="edit">编辑</button>
        <button class="btn-ghost" data-act="del">删除</button>
      </div>`;
    card.querySelector('[data-act="refine"]').onclick = () => openWizard(p);
    card.querySelector('[data-act="edit"]').onclick = () => showNewProjectModal(p);
    card.querySelector('[data-act="del"]').onclick = async () => {
      if (!confirm("确定删除项目「" + p.name + "」？相关规划也会移除。")) return;
      try { await api("DELETE", "/api/projects/" + p.id); toast("已删除"); loadProjects(); }
      catch (e) { toast(e.message, false); }
    };
    return card;
  }

  // 竖排色块卡（参考图：分类下仅显示关键项目名称）；点击展开操作条
  function spineCard(p, group) {
    const card = document.createElement("button");
    card.className = "spine-card";
    card.style.background = p.color;
    card.title = p.name;
    card.textContent = p.name;
    card.onclick = () => {
      const bar = group.querySelector(".spine-actions");
      const wasSel = card.classList.contains("sel") && !bar.classList.contains("hidden");
      group.querySelectorAll(".spine-card").forEach((c) => c.classList.remove("sel"));
      if (wasSel) { bar.classList.add("hidden"); return; }
      card.classList.add("sel");
      bar.classList.remove("hidden");
      bar.innerHTML = `<b style="color:${p.color}">${esc(p.name)}</b>
        <span class="muted small">${esc(p.category)} · ⏱ ${p.expected_hours || 0}h</span>
        <button class="btn-ghost" data-act="refine">细化</button>
        <button class="btn-ghost" data-act="edit">编辑</button>
        <button class="btn-ghost" data-act="del">删除</button>`;
      bar.querySelector('[data-act="refine"]').onclick = () => openWizard(p);
      bar.querySelector('[data-act="edit"]').onclick = () => showNewProjectModal(p);
      bar.querySelector('[data-act="del"]').onclick = async () => {
        if (!confirm("确定删除项目「" + p.name + "」？相关规划也会移除。")) return;
        try { await api("DELETE", "/api/projects/" + p.id); toast("已删除"); loadProjects(); }
        catch (e) { toast(e.message, false); }
      };
    };
    return card;
  }

  function renderProjGrid() {
    const q = ($("#p1Search").value || "").trim().toLowerCase();
    const grid = $("#projGrid");
    let list = PROJECTS.filter((p) => p1Cat === "全部" || p.category === p1Cat);
    if (q) list = list.filter((p) => (p.name + p.description).toLowerCase().includes(q));
    if (!list.length) { grid.innerHTML = '<div class="empty">暂无项目，点击右上角「新建项目」开始吧。</div>'; return; }
    grid.innerHTML = "";
    // 按类别分组（同类别同一组，可折叠；组内为竖排色块卡）
    const order = window.APP.categories || [];
    const groups = {};
    list.forEach((p) => { (groups[p.category] = groups[p.category] || []).push(p); });
    const cats = Object.keys(groups).sort((a, b) => {
      const ia = order.indexOf(a), ib = order.indexOf(b);
      return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
    });
    cats.forEach((c) => {
      const items = groups[c];
      const collapsed = collapsedCats.has(c);
      const sec = document.createElement("div");
      sec.className = "cat-group";
      const head = document.createElement("button");
      head.className = "cat-head";
      const cColor = catColor(c);
      head.innerHTML = `<span class="arr">${collapsed ? "▶" : "▼"}</span>
        <span class="cat-dot" style="background:${cColor}"></span>${esc(c)}
        <span class="cnt">${items.length} 个项目</span>`;
      head.onclick = () => {
        if (collapsedCats.has(c)) collapsedCats.delete(c); else collapsedCats.add(c);
        renderProjGrid();
      };
      sec.appendChild(head);
      if (!collapsed) {
        const row = document.createElement("div");
        row.className = "spine-row";
        items.forEach((p) => row.appendChild(spineCard(p, sec)));
        sec.appendChild(row);
        const bar = document.createElement("div");
        bar.className = "spine-actions hidden";
        sec.appendChild(bar);
      }
      grid.appendChild(sec);
    });
  }

  /* ---- 版块一：极坐标堆叠图（参考独立 HTML 原型） ---- */
  const POLAR = { cv: null, ctx: null, segments: [], cats: [], cx: 0, cy: 0, maxR: 0, innerR: 0,
    thickness: 0, animProgress: 1, hovered: -1, raf: 0, W: 0, H: 0, dpr: 1, hotId: null,
    mode: "overview", pieCat: null };

  function polarTip() {
    let t = $("#polarTip");
    if (!t) { t = document.createElement("div"); t.id = "polarTip"; t.className = "polar-tip"; document.body.appendChild(t); }
    return t;
  }
  function hexToHsl(hex) {
    hex = hex.replace("#", "");
    const r = parseInt(hex.substr(0, 2), 16) / 255, g = parseInt(hex.substr(2, 2), 16) / 255, b = parseInt(hex.substr(4, 2), 16) / 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0; const l = (max + min) / 2;
    if (max !== min) {
      const d = max - min; s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) h = (g - b) / d + (g < b ? 6 : 0); else if (max === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h /= 6;
    }
    return { h: h * 360, s: s * 100 };
  }
  function shadeTime(hex, t) { // 早=浅 晚=深
    const { h, s } = hexToHsl(hex);
    const l = 82 - 37 * Math.max(0, Math.min(1, t));
    return `hsl(${h.toFixed(0)} ${s.toFixed(0)}% ${l.toFixed(0)}%)`;
  }
  function createdNum(p) { if (!p.created_at) return 0; const d = new Date(p.created_at); return isNaN(d) ? 0 : d.getTime(); }
  function fmtDate(ts) { const d = new Date(ts); const p2 = (n) => String(n).padStart(2, "0"); return `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`; }

  function polarSize() {
    const cv = POLAR.cv; if (!cv) return;
    const rect = cv.parentElement.getBoundingClientRect();
    if (rect.width < 10) return; // 面板隐藏时不重算
    POLAR.dpr = window.devicePixelRatio || 1;
    POLAR.W = rect.width; POLAR.H = Math.max(440, cv.clientHeight || 480);
    cv.width = POLAR.W * POLAR.dpr; cv.height = POLAR.H * POLAR.dpr;
    POLAR.ctx = cv.getContext("2d");
    POLAR.ctx.setTransform(POLAR.dpr, 0, 0, POLAR.dpr, 0, 0);
    POLAR.cx = POLAR.W / 2; POLAR.cy = POLAR.H / 2;
    POLAR.maxR = Math.min(POLAR.W, POLAR.H) / 2 - 58;
    POLAR.innerR = Math.min(56, POLAR.maxR * 0.3);
  }

  function polarBuild() {
    POLAR.segments = []; POLAR.cats = [];
    if (!POLAR.cv) POLAR.cv = $("#polarChart");
    if (!POLAR.cv) return;
    polarSize();
    const cats = (window.APP.categories || []).map((c) => ({ name: c, projects: PROJECTS.filter((p) => p.category === c) }))
      .filter((c) => c.projects.length);
    PROJECTS.forEach((p) => { if (!cats.some((c) => c.name === p.category)) cats.push({ name: p.category, projects: [p] }); });
    const total = PROJECTS.length;
    if (!total) return;
    const gap = cats.length > 1 ? 2.2 : 0;
    const available = 360 - gap * cats.length;
    let minT = Infinity, maxT = -Infinity;
    cats.forEach((c) => c.projects.forEach((p) => { const t = createdNum(p); if (t < minT) minT = t; if (t > maxT) maxT = t; }));
    const maxCount = Math.max(...cats.map((c) => c.projects.length));
    POLAR.thickness = (POLAR.maxR - POLAR.innerR) / maxCount;
    let angle = 0;
    cats.forEach((cat, ci) => {
      const color = catColor(cat.name);
      const projs = cat.projects.slice().sort((a, b) => createdNum(a) - createdNum(b));
      const span = (projs.length / total) * available;
      const a0 = angle, a1 = angle + span;
      POLAR.cats.push({ name: cat.name, a0, a1, mid: (a0 + a1) / 2, count: projs.length, color });
      projs.forEach((p, pi) => {
        const t = maxT > minT ? (createdNum(p) - minT) / (maxT - minT) : 0;
        POLAR.segments.push({ pid: p.id, name: p.name, cat: cat.name, created: p.created_at ? fmtDate(createdNum(p)) : "—",
          a0, a1, r0: POLAR.innerR + pi * POLAR.thickness, r1: POLAR.innerR + (pi + 1) * POLAR.thickness,
          color: shadeTime(color, t), order: pi + 1, ci });
      });
      angle = a1 + gap;
    });
  }

  function polarSeg(s, p, hot) {
    const ctx = POLAR.ctx;
    const r0e = POLAR.innerR + (s.r0 - POLAR.innerR) * p;
    const r1e = POLAR.innerR + (s.r1 - POLAR.innerR) * p;
    const a0 = (s.a0 - 90) * Math.PI / 180, a1 = (s.a1 - 90) * Math.PI / 180;
    const ai = 0.45 * Math.PI / 180;
    ctx.save();
    ctx.globalAlpha = Math.min(1, p * 2.8);
    ctx.beginPath();
    ctx.arc(POLAR.cx, POLAR.cy, r1e, a0 + ai, a1 - ai, false);
    ctx.arc(POLAR.cx, POLAR.cy, r0e, a1 - ai, a0 + ai, true);
    ctx.closePath();
    ctx.fillStyle = s.color; ctx.fill();
    ctx.lineWidth = 1; ctx.strokeStyle = "rgba(255,255,255,0.9)"; ctx.stroke();
    if (hot) { ctx.lineWidth = 2.5; ctx.strokeStyle = "#0f172a"; ctx.stroke(); }
    ctx.restore();
  }

  /* ---- 入场动画时间轴 ----
     0 ~ CENTER_T：中心「总项目」圆弹出；
     之后：一道顺时针扫过的「光束」从内向外展开，逐个揭示每个项目扇区（同一分类内由内圈到外圈依次出现），最后分类标签依次淡入。 */
  const POLAR_CENTER_T = 0.18;
  const RING_STEP = 10; // 同一分类内，相邻项目环的揭示间隔（度）
  const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);
  const easeOutBack = (t) => { const c = 1.70158; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); };

  function polarSweep() {
    if (POLAR.animProgress <= POLAR_CENTER_T) return 0;
    return ((POLAR.animProgress - POLAR_CENTER_T) / (1 - POLAR_CENTER_T)) * 360;
  }

  function polarCenterP() {
    return Math.max(0, Math.min(1, POLAR.animProgress / POLAR_CENTER_T));
  }

  // 单个项目扇区的揭示进度：扫过角度到达该环阈值后，由内向外弹开
  function polarSegP(s) {
    const sweep = polarSweep();
    const threshold = s.a0 + (s.order - 1) * RING_STEP;
    if (sweep < threshold) return 0;
    return Math.min(1, (sweep - threshold) / 28);
  }

  // 分类标签的揭示进度：扫过该分类约 40% 扇面后标签淡入
  function polarCatP(ci) {
    const c = POLAR.cats[ci];
    if (!c) return 0;
    const sweep = polarSweep();
    const threshold = c.a0 + (c.a1 - c.a0) * 0.4;
    if (sweep < threshold) return 0;
    return Math.min(1, (sweep - threshold) / 30);
  }

  function polarDraw() {
    if (POLAR.mode === "pie") { pieDraw(); return; }
    const ctx = POLAR.ctx; if (!ctx) return;
    ctx.clearRect(0, 0, POLAR.W, POLAR.H);

    // 逐个揭示每个项目扇区：按顺时针扫描，同一分类内由内环到外环依次弹开
    POLAR.segments.forEach((s) => {
      const sp = polarSegP(s);
      if (sp <= 0) return;
      const p = easeOutBack(Math.min(1, sp));
      const hot = POLAR.hovered >= 0 ? POLAR.segments[POLAR.hovered] === s : (POLAR.hotId && s.pid === POLAR.hotId);
      if (!hot) polarSeg(s, p, !!POLAR.hotId && s.pid === POLAR.hotId);
    });
    if (POLAR.hovered >= 0) {
      const hs = POLAR.segments[POLAR.hovered];
      const hsp = polarSegP(hs);
      if (hsp > 0) polarSeg(hs, easeOutBack(Math.min(1, hsp)), true);
    }

    // 中心总数（先弹出：带回弹的缩放 + 淡入）
    const cen = polarCenterP();
    if (cen > 0) {
      const scale = cen >= 1 ? 1 : easeOutBack(cen);
      ctx.save();
      ctx.globalAlpha = Math.min(1, cen * 1.6);
      ctx.beginPath(); ctx.arc(POLAR.cx, POLAR.cy, Math.max(0.1, (POLAR.innerR - 1) * scale), 0, Math.PI * 2);
      ctx.fillStyle = "#fff"; ctx.fill();
      ctx.lineWidth = 1; ctx.strokeStyle = "#e2e8f0"; ctx.stroke();
      ctx.fillStyle = "#0f172a"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.font = "700 26px 'PingFang SC','Microsoft YaHei',sans-serif";
      ctx.fillText(String(PROJECTS.length), POLAR.cx, POLAR.cy - 6);
      ctx.font = "500 12px 'PingFang SC','Microsoft YaHei',sans-serif"; ctx.fillStyle = "#64748b";
      ctx.fillText("个项目", POLAR.cx, POLAR.cy + 16);
      ctx.restore();
    }

    // 外圈分类标签（扫过该分类后淡入）
    ctx.font = "600 12.5px 'PingFang SC','Microsoft YaHei',sans-serif";
    ctx.textBaseline = "middle";
    POLAR.cats.forEach((c, ci) => {
      const lp = polarCatP(ci);
      if (lp <= 0) return;
      const ang = (c.mid - 90) * Math.PI / 180;
      const r = POLAR.maxR + 12;
      const x = POLAR.cx + r * Math.cos(ang), y = POLAR.cy + r * Math.sin(ang);
      ctx.save();
      ctx.globalAlpha = easeOutCubic(lp);
      ctx.fillStyle = c.color;
      ctx.textAlign = Math.cos(ang) >= 0 ? "left" : "right";
      ctx.fillText(`${c.name} · ${c.count}`, x, y);
      ctx.restore();
    });
  }

  function polarAnimate(dur) {
    cancelAnimationFrame(POLAR.raf);
    // 时长：中心弹出 + 分类数 + 每个项目逐个揭示都需要时间
    const total = dur || (680 + POLAR.cats.length * 220 + POLAR.segments.length * 45);
    const start = performance.now();
    const step = (now) => {
      let t = (now - start) / total; if (t > 1) t = 1;
      POLAR.animProgress = t;
      polarDraw();
      if (t < 1) POLAR.raf = requestAnimationFrame(step);
    };
    POLAR.raf = requestAnimationFrame(step);
  }

  function polarHit(e) {
    const rect = POLAR.cv.getBoundingClientRect();
    const mx = e.clientX - rect.left, my = e.clientY - rect.top;
    const dx = mx - POLAR.cx, dy = my - POLAR.cy;
    const dist = Math.hypot(dx, dy);
    let ang = Math.atan2(dx, -dy) * 180 / Math.PI; if (ang < 0) ang += 360;
    for (let i = 0; i < POLAR.segments.length; i++) {
      const s = POLAR.segments[i];
      if (dist >= s.r0 - 1 && dist <= s.r1 + 1 && ang >= s.a0 && ang <= s.a1) return { seg: s, index: i, center: dist < POLAR.innerR };
    }
    return { seg: null, index: -1, center: dist < POLAR.innerR };
  }

  function renderPolar(animateIt) {
    POLAR.mode = "overview"; POLAR.pieCat = null;
    if (!POLAR.cv) POLAR.cv = $("#polarChart");
    if (!POLAR.cv) return;
    polarBuild();
    if (animateIt) polarAnimate(); else { POLAR.animProgress = 1; polarDraw(); }
  }

  // 统一的图表渲染入口：根据当前选中的分类决定总览极坐标图 or 单分类扇形图
  function renderP1Chart(animateIt) {
    const back = $("#p1PieBack");
    if (p1Cat === "全部") {
      if (back) back.style.display = "none";
      const t = $("#p1ChartTitle"); if (t) t.textContent = "项目分布 · 极坐标堆叠图";
      const hi = $("#p1ChartHint"); if (hi) hi.textContent = "角度=项目数量 · 由内向外按建立时间堆叠 · 点击扇区/分类下钻查看";
      renderPolar(animateIt);
    } else {
      if (back) back.style.display = "";
      const t = $("#p1ChartTitle"); if (t) t.textContent = "「" + p1Cat + "」· 扇形图";
      const hi = $("#p1ChartHint"); if (hi) hi.textContent = "圆心=该分类项目总数 · 扇区=具体项目 · 点击圆心返回总览 · 点击扇区查看项目列表";
      renderPie(p1Cat, animateIt);
    }
  }

  /* ---- 版块一：单分类扇形图（下钻） ----
     圆心 = 该分类项目总数；每个具体项目占一个扇区（按建立时间排序，角度均分）；
     入场：中心圆先弹出，随后一道光束顺时针扫过，逐扇区揭示。 */
  function pieBuild(cat) {
    POLAR.mode = "pie"; POLAR.pieCat = cat;
    POLAR.segments = []; POLAR.cats = [];
    if (!POLAR.cv) POLAR.cv = $("#polarChart");
    if (!POLAR.cv) return;
    polarSize();
    const color = catColor(cat);
    const projs = PROJECTS.filter((p) => p.category === cat)
      .slice().sort((a, b) => createdNum(a) - createdNum(b));
    const n = projs.length;
    if (!n) {
      POLAR.cats = [{ name: cat, a0: 0, a1: 360, mid: 180, count: 0, color }];
      return;
    }
    const gap = n > 1 ? 1.4 : 0;
    const available = 360 - gap * n;
    let angle = 0;
    projs.forEach((p, i) => {
      const span = available / n;
      const a0 = angle, a1 = angle + span;
      POLAR.segments.push({ pid: p.id, name: p.name, cat, created: p.created_at ? fmtDate(createdNum(p)) : "—",
        a0, a1, r0: POLAR.innerR, r1: POLAR.maxR, color: p.color || color, order: i + 1, hours: p.expected_hours || 0 });
      angle = a1 + gap;
    });
    POLAR.cats = [{ name: cat, a0: 0, a1: 360, mid: 180, count: n, color }];
  }

  function pieDraw() {
    const ctx = POLAR.ctx; if (!ctx) return;
    ctx.clearRect(0, 0, POLAR.W, POLAR.H);
    const sweep = POLAR.animProgress * 360;
    const animating = POLAR.animProgress < 1;

    // 逐扇区揭示
    POLAR.segments.forEach((s) => {
      let end = s.a1;
      if (animating) end = Math.min(s.a1, Math.max(s.a0, sweep - 3));
      if (end <= s.a0) return;
      const a0 = (s.a0 - 90) * Math.PI / 180, a1 = (end - 90) * Math.PI / 180;
      const hot = POLAR.hovered >= 0 ? POLAR.segments[POLAR.hovered] === s : (POLAR.hotId && s.pid === POLAR.hotId);
      ctx.save();
      ctx.globalAlpha = animating ? Math.min(1, (end - s.a0) / Math.max(2, s.a1 - s.a0) * 1.4) : 1;
      ctx.beginPath();
      ctx.arc(POLAR.cx, POLAR.cy, s.r1, a0, a1, false);
      ctx.arc(POLAR.cx, POLAR.cy, s.r0, a1, a0, true);
      ctx.closePath();
      ctx.fillStyle = s.color; ctx.fill();
      ctx.lineWidth = 1; ctx.strokeStyle = "rgba(255,255,255,0.9)"; ctx.stroke();
      if (hot) { ctx.lineWidth = 2.5; ctx.strokeStyle = "#0f172a"; ctx.stroke(); }
      ctx.restore();
    });

    // 中心圆：总数 + 分类名
    const cen = animating ? POLAR.animProgress : 1;
    const scale = cen >= 1 ? 1 : easeOutBack(cen);
    ctx.save();
    ctx.globalAlpha = Math.min(1, cen * 1.6);
    ctx.beginPath(); ctx.arc(POLAR.cx, POLAR.cy, Math.max(0.1, (POLAR.innerR - 1) * scale), 0, Math.PI * 2);
    ctx.fillStyle = "#fff"; ctx.fill();
    ctx.lineWidth = 1; ctx.strokeStyle = "#e2e8f0"; ctx.stroke();
    ctx.fillStyle = "#0f172a"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.font = "700 24px 'PingFang SC','Microsoft YaHei',sans-serif";
    ctx.fillText(String(POLAR.cats[0] ? POLAR.cats[0].count : 0), POLAR.cx, POLAR.cy - 6);
    ctx.font = "500 12px 'PingFang SC','Microsoft YaHei',sans-serif"; ctx.fillStyle = "#64748b";
    ctx.fillText("个项目", POLAR.cx, POLAR.cy + 14);
    ctx.fillStyle = catColor(POLAR.pieCat || "");
    ctx.font = "600 12px 'PingFang SC','Microsoft YaHei',sans-serif";
    ctx.fillText(POLAR.pieCat || "", POLAR.cx, POLAR.cy + 30);
    ctx.restore();
  }

  function renderPie(cat, animateIt) {
    POLAR.mode = "pie"; POLAR.pieCat = cat;
    if (!POLAR.cv) POLAR.cv = $("#polarChart");
    if (!POLAR.cv) return;
    pieBuild(cat);
    if (!POLAR.segments.length) { POLAR.animProgress = 1; polarDraw(); return; }
    if (animateIt) polarAnimate(); else { POLAR.animProgress = 1; polarDraw(); }
  }

  function setP1View(v) {
    const stage = $("#p1Stage");
    if (!stage) return;
    stage.classList.toggle("show-list", v === "list");
    if (v === "chart") requestAnimationFrame(() => renderP1Chart(true)); // 返回图表时重播入场动画（总览或扇形图）
  }

  function bindPolar() {
    const cv = $("#polarChart");
    if (!cv) return;
    POLAR.cv = cv;
    const tip = polarTip();
    cv.addEventListener("mousemove", (e) => {
      if (POLAR.cv.parentElement.getBoundingClientRect().width < 10) return;
      const h = polarHit(e);
      if (h.index !== POLAR.hovered) { POLAR.hovered = h.index; polarDraw(); }
      if (h.seg) {
        if (POLAR.mode === "pie") {
          tip.innerHTML = `<b>${esc(h.seg.name)}</b><br><span class="k">分类：</span>${esc(h.seg.cat)}<br><span class="k">预估：</span>${h.seg.hours}h<br><span class="k">建立：</span>${h.seg.created}`;
        } else {
          tip.innerHTML = `<b>${esc(h.seg.name)}</b><br><span class="k">分类：</span>${esc(h.seg.cat)}<br><span class="k">建立：</span>${h.seg.created}<br><span class="k">时间序：</span>第 ${h.seg.order} 个`;
        }
        tip.classList.add("on");
        tip.style.left = Math.min(e.clientX + 14, window.innerWidth - 240) + "px";
        tip.style.top = (e.clientY + 14) + "px";
      } else tip.classList.remove("on");
    });
    cv.addEventListener("mouseleave", () => { POLAR.hovered = -1; polarDraw(); tip.classList.remove("on"); });
    // 总览：点击扇区 → 下钻该分类扇形图；点击圆心 → 已是总览（无操作）
    // 扇形图：点击圆心 → 返回总览；点击扇区 → 进入该分类项目列表
    cv.addEventListener("click", (e) => {
      const h = polarHit(e);
      if (POLAR.mode === "pie") {
        if (h.center) selectCategory("全部");
        else if (h.seg) { p1Cat = POLAR.pieCat; buildChips(); renderProjGrid(); setP1View("list"); }
      } else {
        if (h.seg) selectCategory(h.seg.cat);
        else if (h.center) { /* 已在总览 */ }
      }
    });
    const back = $("#backToChart");
    if (back) back.onclick = () => setP1View("chart");
    const pieBack = $("#p1PieBack");
    if (pieBack) pieBack.onclick = () => selectCategory("全部");
    let rt;
    window.addEventListener("resize", () => { clearTimeout(rt); rt = setTimeout(() => { polarSize(); polarDraw(); }, 150); });
  }

  // 新建项目保存后：从保存按钮飞入图表对应扇区（按项目分类下钻到对应视图）
  function flyToPolar(p, fromX, fromY) {
    p1Cat = p.category;
    setP1View("chart");
    renderP1Chart(false); // 按最终形态绘制，飞入落点据此计算
    const seg = POLAR.segments.find((s) => s.pid === p.id);
    if (!seg) { renderP1Chart(true); return; }
    requestAnimationFrame(() => {
      cancelAnimationFrame(POLAR.raf); POLAR.animProgress = 1; // 飞入落点按最终形态计算
      polarSize(); polarDraw();
      const rect = POLAR.cv.getBoundingClientRect();
      const midA = ((seg.a0 + seg.a1) / 2 - 90) * Math.PI / 180;
      const midR = (seg.r0 + seg.r1) / 2 * POLAR.animProgress;
      const tx = rect.left + POLAR.cx + midR * Math.cos(midA);
      const ty = rect.top + POLAR.cy + midR * Math.sin(midA);
      const chip = document.createElement("div");
      chip.className = "fly-chip";
      chip.style.background = p.color || catColor(p.category);
      chip.textContent = p.name;
      chip.style.left = fromX + "px"; chip.style.top = fromY + "px";
      document.body.appendChild(chip);
      const dx = tx - fromX, dy = ty - fromY;
      const anim = chip.animate([
        { transform: "translate(-50%,-50%) scale(1)", opacity: 1 },
        { transform: `translate(calc(-50% + ${dx * 0.55}px), calc(-50% + ${dy * 0.55 - 110}px)) scale(.92)`, opacity: 1, offset: 0.55 },
        { transform: `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px)) scale(.35)`, opacity: 0.25 },
      ], { duration: 900, easing: "cubic-bezier(.3,.7,.4,1)" });
      anim.onfinish = () => {
        chip.remove();
        POLAR.hotId = p.id; polarDraw();
        setTimeout(() => { POLAR.hotId = null; polarDraw(); }, 1800);
      };
    });
  }

  function renderRefineGrid() {
    // 版块二：项目分类板块（附属项目名称，竖排色卡）+ 细化板块（流程图）
    const wrap = $("#refineCats");
    if (!PROJECTS.length) {
      wrap.innerHTML = '<div class="empty">还没有项目，请先到「新建项目」创建。</div>';
      return;
    }
    const order = window.APP.categories || [];
    const groups = {};
    PROJECTS.forEach((p) => { (groups[p.category] = groups[p.category] || []).push(p); });
    const cats = Object.keys(groups).sort((a, b) => {
      const ia = order.indexOf(a), ib = order.indexOf(b);
      return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
    });
    wrap.innerHTML = "";
    cats.forEach((c) => {
      const items = groups[c];
      const collapsed = refineCollapsed.has(c);
      const sec = document.createElement("div");
      sec.className = "cat-group";
      const cColor = catColor(c);
      sec.innerHTML = `
        <button class="cat-head"><span class="arr">${collapsed ? "▶" : "▼"}</span>
          <span class="cat-dot" style="background:${cColor}"></span>${esc(c)}
          <span class="cnt">${items.length} 个项目</span></button>`;
      sec.querySelector(".cat-head").onclick = () => {
        if (refineCollapsed.has(c)) refineCollapsed.delete(c); else refineCollapsed.add(c);
        renderRefineGrid();
      };
      if (!collapsed) {
        const row = document.createElement("div");
        row.className = "spine-row";
        items.forEach((p) => {
          const card = document.createElement("button");
          card.className = "spine-card";
          card.style.background = p.color || cColor;
          if (FLOW.proj && FLOW.proj.id === p.id) card.style.outline = "3px solid #1d4ed8";
          card.textContent = p.name;
          card.title = "点击进入细化流程图";
          card.onclick = () => flowOpen(p);
          row.appendChild(card);
        });
        sec.appendChild(row);
      }
      wrap.appendChild(sec);
    });
  }

  /* ---- 细化板块：可编辑流程图 ---- */
  // steps 为「详细信息」步骤树的工作副本，与流程图内容节点（process/io）双向同步
  const FLOW = { proj: null, nodes: [], edges: [], steps: [], sel: null, multi: new Set(), dirty: false, saveTimer: null, __clickTimer: null, __skipClick: false, __dbl: { id: null, t: 0 } };
  window.__FLOW = FLOW; // 调试/测试用
  let refineCollapsed = new Set();
  const FC_TITLES = { start: "开始", process: "过程", decision: "判断", io: "输入/输出", end: "结束" };
  const FC_SIZES = { start: [96, 40], end: [96, 40], process: [120, 44], io: [130, 44], decision: [130, 78] };
  // 节点实际尺寸：插入图片且未隐藏时，加宽并增加图片区高度（连线/对齐/命中检测都以此为准）
  const FC_IMG_H = 96;
  function nodeWH(n) {
    let [w, h] = FC_SIZES[n.type];
    if (n.img && !n.imgHidden) { w = Math.max(w, 160); h += FC_IMG_H; }
    return [w, h];
  }

  function flowOpen(p) {
    FLOW.proj = p;
    FLOW.steps = normSteps(p.steps);
    let f = p.flow;
    if (!f || !Array.isArray(f.nodes) || !f.nodes.length) {
      // 首次进入：按详细信息步骤树生成（开始 → 顶层步骤，父步骤 → 子步骤，与层级一致）
      FLOW.nodes = [{ id: "n1", type: "start", text: "开始", x: 460, y: 40 }];
      FLOW.edges = [];
      let py = 150;
      const walkGen = (list, parentNodeId, depth) => {
        (list || []).forEach((s) => {
          const id = uid();
          const ntype = nodeTypeOf(s.kind);
          FLOW.nodes.push({ id, type: ntype, text: s.name, x: 440 + depth * 230, y: py, stepId: s.id });
          FLOW.edges.push({ id: uid(), from: parentNodeId, to: id, label: "" });
          py += 110;
          walkGen(s.children, id, depth + 1);
        });
      };
      walkGen(FLOW.steps, "n1", 0);
      // 无步骤时只保留「开始」节点，不默认生成游离「过程」节点，
      // 避免 reconcileFlow 把它变成幽灵步骤污染详细信息
    } else {
      FLOW.nodes = f.nodes.map((n) => ({ ...n }));
      FLOW.edges = (f.edges || []).map((e) => ({ ...e }));
      // 旧版本把步骤树串成一条链保存过 → 自动重建为树形连线
      if (legacyChainFix()) flowTouch();
    }
    FLOW.sel = null;
    FLOW.multi.clear();
    if (reconcileFlow()) flowTouch(); // 打开旧数据时对齐产生变化 → 自动保存
    $("#refineBoard").classList.remove("hidden");
    $("#fcTitle").textContent = "细化 · " + p.name;
    $("#fcTitle").style.color = p.color || "#334155";
    $("#fcHint").classList.remove("hidden");
    renderRefineGrid(); // 高亮当前项目
    flowRender();
    $("#refineBoard").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function flowData() { return { nodes: FLOW.nodes, edges: FLOW.edges }; }

  /* ---- 步骤树 ↔ 流程节点 双向同步 ---- */
  // 步骤节点：与详细信息步骤一一对应（过程/输入输出/判断/结束；只有「开始」是纯流程起点，不进详细信息）
  function isContentNode(n) { return n.type === "process" || n.type === "io" || n.type === "decision" || n.type === "end"; }
  // 节点类型 → 步骤 kind
  function stepKindOf(n) { return n.type === "decision" ? "decision" : n.type === "end" ? "end" : undefined; }
  // 步骤 kind → 节点类型
  function nodeTypeOf(kind) { return kind === "decision" ? "decision" : kind === "end" ? "end" : "process"; }

  function flattenSteps(list, out) {
    (list || []).forEach((s) => { out.push(s); flattenSteps(s.children, out); });
    return out;
  }

  function findStepById(id) { return flattenSteps(FLOW.steps, []).find((s) => s.id === id) || null; }

  // 找某步骤的父步骤（顶层步骤无父级 → null）
  function findParentStep(list, id) {
    for (const s of list || []) {
      if ((s.children || []).some((c) => c.id === id)) return s;
      const r = findParentStep(s.children, id);
      if (r) return r;
    }
    return null;
  }

  // 旧版本自动生成的「DFS 链式」连线检测：连线恰好等于 开始→步骤1→步骤2→…（DFS 顺序两两相连）
  // 且步骤树存在嵌套时，重建为树形连线（开始→各顶层步骤，父→子）。用户手动画过线则不匹配，不会误伤。
  function legacyChainFix() {
    const flat = flattenSteps(FLOW.steps, []);
    if (flat.length < 2) return false;
    if (!flat.some((s) => (s.children || []).length)) return false; // 无嵌套就无所谓层级
    const start = FLOW.nodes.find((n) => n.type === "start");
    if (!start) return false;
    const byStep = new Map();
    FLOW.nodes.forEach((n) => { if (isContentNode(n) && n.stepId) byStep.set(n.stepId, n); });
    if (flat.some((s) => !byStep.has(s.id))) return false; // 步骤未全部对齐节点，不自动动
    const want = new Set();
    want.add(start.id + ">" + byStep.get(flat[0].id).id);
    for (let i = 0; i < flat.length - 1; i++) want.add(byStep.get(flat[i].id).id + ">" + byStep.get(flat[i + 1].id).id);
    const have = FLOW.edges.map((e) => e.from + ">" + e.to);
    if (have.length !== want.size || !have.every((k) => want.has(k))) return false;
    rebuildTreeEdges(byStep, start.id);
    return true;
  }

  // 按步骤树重建连线：开始 → 各顶层步骤，父步骤 → 子步骤
  function rebuildTreeEdges(byStep, startId) {
    FLOW.edges = [];
    const walk = (list, pid) => (list || []).forEach((s) => {
      const n = byStep.get(s.id);
      if (!n) return;
      FLOW.edges.push({ id: uid(), from: pid, to: n.id, label: "" });
      walk(s.children, n.id);
    });
    walk(FLOW.steps, startId);
  }

  function removeStepById(id) {
    // 删除步骤本身，但其子步骤提升到被删步骤的位置（子步骤在流程图上还有自己的节点）
    const rec = (list) => {
      const i = list.findIndex((s) => s.id === id);
      if (i >= 0) { list.splice(i, 1, ...(list[i].children || [])); return true; }
      return list.some((s) => rec(s.children || []));
    };
    return rec(FLOW.steps);
  }

  // 为新节点找空白落点（避免盖住已有节点导致端口无法拖拽）
  function freeSpot(w, h, px, py) {
    const canvas = $("#fcCanvas");
    let x = px != null ? px : canvas.scrollLeft + 80;
    let y = py != null ? py : canvas.scrollTop + 90;
    const clash = () => FLOW.nodes.some((n) => {
      const [nw, nh] = nodeWH(n);
      return Math.abs(n.x - x) < nw + w + 16 && Math.abs(n.y - y) < nh + h + 16;
    });
    let guard = 0;
    while (clash() && guard++ < 80) {
      x += w + 70;
      if (x > canvas.scrollLeft + canvas.clientWidth + 600) { x = canvas.scrollLeft + 80; y += h + 54; }
    }
    return [Math.round(Math.max(0, x)), Math.round(Math.max(0, y))];
  }

  // 双向对齐核心。source: "wizard"=详细信息刚保存（以步骤为准删多余节点）
  // 规则：按 stepId 关联，旧数据按名称匹配；缺节点补节点（自动接链），缺步骤补步骤；名称以已改动方为准后统一为步骤名
  function reconcileFlow(source) {
    let changed = false;
    const steps = flattenSteps(FLOW.steps, []);
    // 详细信息刚保存：已删除的步骤，其对应节点（含连线）一并移除
    if (source === "wizard") {
      const dead = FLOW.nodes.filter((n) => isContentNode(n) && n.stepId && !steps.some((s) => s.id === n.stepId));
      if (dead.length) {
        changed = true;
        const ids = new Set(dead.map((n) => n.id));
        FLOW.nodes = FLOW.nodes.filter((n) => !ids.has(n.id));
        FLOW.edges = FLOW.edges.filter((e) => !ids.has(e.from) && !ids.has(e.to));
      }
    }
    const contentNodes = FLOW.nodes.filter(isContentNode);
    const byStep = new Map();
    const usedNodes = new Set();
    contentNodes.forEach((n) => {
      if (n.stepId && steps.some((s) => s.id === n.stepId)) { byStep.set(n.stepId, n); usedNodes.add(n.id); }
    });
    // 名称匹配（兼容旧的无 stepId 流程数据）
    steps.forEach((s) => {
      if (byStep.has(s.id)) return;
      const m = contentNodes.find((n) => !usedNodes.has(n.id) && (n.text || "") === s.name);
      if (m) { changed = true; m.stepId = s.id; usedNodes.add(m.id); byStep.set(s.id, m); }
    });
    // 缺节点的步骤 → 新建节点（类型随步骤 kind）；优先挂到父步骤节点下（层级一致），无父节点时接在最后一个内容节点之后
    steps.forEach((s) => {
      if (byStep.has(s.id)) return;
      changed = true;
      const ntype = nodeTypeOf(s.kind);
      const [w, h] = nodeWH({ type: ntype });
      const ps = findParentStep(FLOW.steps, s.id);
      const pn = ps ? byStep.get(ps.id) : null;
      const chain = FLOW.nodes.filter((m) => isContentNode(m) && m.type !== "end");
      const last = pn || chain[chain.length - 1];
      const [x, y] = freeSpot(w, h, last ? last.x + 60 : undefined, last ? last.y + nodeWH(last)[1] + 56 : undefined);
      const id = uid();
      FLOW.nodes.push({ id, type: ntype, text: s.name, x, y, stepId: s.id });
      if (last) FLOW.edges.push({ id: uid(), from: last.id, to: id, label: "" });
      byStep.set(s.id, FLOW.nodes[FLOW.nodes.length - 1]);
    });
    // 缺步骤的内容节点 → 新建步骤（顶层追加，保留流程图上已有的文字与类型）
    FLOW.nodes.filter(isContentNode).forEach((n) => {
      if (n.stepId && findStepById(n.stepId)) return;
      changed = true;
      const s = { id: uid(), name: n.text || "未命名步骤", hours: "", children: [] };
      const k = stepKindOf(n);
      if (k) s.kind = k;
      n.stepId = s.id;
      FLOW.steps.push(s);
    });
    // 名称统一：节点文字 = 步骤名（流程图改名的场景已在编辑时同步回步骤）
    FLOW.nodes.filter(isContentNode).forEach((n) => {
      const s = findStepById(n.stepId);
      if (s && n.text !== s.name) { changed = true; n.text = s.name; }
    });
    // 层级修复（含旧数据）：从某步骤节点拉出多条分支的，被拉的顶层步骤应收拢为它的子项。
    // 只动「当前在顶层」的步骤，不碰用户在详细信息里已手动调整过的层级；单链顺序（1进1出）不受影响。
    const outCnt = {};
    FLOW.edges.forEach((e) => { outCnt[e.from] = (outCnt[e.from] || 0) + 1; });
    const nodeById = new Map(FLOW.nodes.map((m) => [m.id, m]));
    FLOW.edges.forEach((e) => {
      const a = nodeById.get(e.from), b = nodeById.get(e.to);
      if (!a || !b || (outCnt[e.from] || 0) < 2) return;
      if (!isContentNode(a) || !isContentNode(b) || !a.stepId || !b.stepId) return;
      const ps = findStepById(a.stepId), cs = findStepById(b.stepId);
      if (!ps || !cs || ps === cs) return;
      if (!FLOW.steps.some((s) => s.id === cs.id)) return; // 已有父级，不动
      ps.children = ps.children || [];
      if (!ps.children.some((s) => s.id === cs.id)) {
        FLOW.steps = FLOW.steps.filter((s) => s.id !== cs.id);
        ps.children.push(cs);
        changed = true;
      }
    });
    return changed;
  }

  // 详细信息（向导）保存后调用：刷新流程图并持久化新增节点
  function flowAfterWizardSave(proj) {
    if (!FLOW.proj || FLOW.proj.id !== proj.id) return;
    FLOW.proj = proj;
    FLOW.steps = normSteps(proj.steps);
    reconcileFlow("wizard");
    flowTouch();
    flowSave();
    flowRender();
  }

  function flowTouch() {
    FLOW.dirty = true;
    clearTimeout(FLOW.saveTimer);
    FLOW.saveTimer = setTimeout(flowSave, 900);
  }

  async function flowSave() {
    if (!FLOW.proj || !FLOW.dirty) return;
    try {
      // flow 与 steps 一起提交：流程图与详细信息永远保持一致
      const updated = await api("PUT", "/api/projects/" + FLOW.proj.id, { flow: flowData(), steps: FLOW.steps });
      FLOW.proj.flow = updated.flow; FLOW.proj.steps = updated.steps; FLOW.dirty = false;
      const cache = PROJECTS.find((p) => p.id === FLOW.proj.id);
      if (cache) { cache.flow = updated.flow; cache.steps = updated.steps; }
      const s = $("#fcSaved"); s.classList.add("on");
      setTimeout(() => s.classList.remove("on"), 1200);
    } catch (e) { toast("流程图保存失败：" + e.message, false); }
  }

  // 仅同步选中态（.selected 与对齐条）而不重建节点 DOM，
  // 避免「单击 → 延迟重绘」销毁节点元素、破坏双击目标或正在编辑的输入框
  function flowSyncSelection() {
    const selSet = new Set(FLOW.multi);
    if (FLOW.sel) selSet.add(FLOW.sel);
    FLOW.nodes.forEach((m) => { if (m._el) m._el.classList.toggle("selected", selSet.has(m.id)); });
    flowAlignBarSync();
  }

  function flowRender() {
    const canvas = $("#fcCanvas"), svg = $("#fcSvg");
    canvas.querySelectorAll(".fc-node,.fc-elabel").forEach((el) => el.remove());
    // 画布按节点范围自适应（避免出现多余滚动条）
    const mx = Math.max(canvas.clientWidth, ...FLOW.nodes.map((n) => n.x + nodeWH(n)[0] + 160));
    const my = Math.max(canvas.clientHeight, ...FLOW.nodes.map((n) => n.y + nodeWH(n)[1] + 120));
    svg.setAttribute("width", Math.round(mx)); svg.setAttribute("height", Math.round(my));
    // 连线（SVG 在节点下层，中心连线端点被节点自体遮住）
    svg.innerHTML = '<defs><marker id="fcArrow" markerWidth="9" markerHeight="8" refX="7.5" refY="4" orient="auto"><polygon class="fc-arrow" points="0 0, 9 4, 0 8"/></marker></defs>';
    FLOW.edges.forEach((e) => flowDrawEdge(e));
    // 节点
    FLOW.nodes.forEach((n) => flowDrawNode(n));
    flowAlignBarSync();
  }

  function nodeC(n) { const [w, h] = nodeWH(n); return [n.x + w / 2, n.y + h / 2]; }

  // 直线与目标节点包围盒的交点参数（从中心向外）
  function rectExit(cx, cy, dx, dy, w, h) {
    const sx = dx === 0 ? Infinity : (w / 2) / Math.abs(dx);
    const sy = dy === 0 ? Infinity : (h / 2) / Math.abs(dy);
    return Math.min(sx, sy);
  }

  function flowDrawEdge(e) {
    const svg = $("#fcSvg");
    const a = FLOW.nodes.find((n) => n.id === e.from), b = FLOW.nodes.find((n) => n.id === e.to);
    if (!a || !b) return;
    const [ax, ay] = nodeC(a), [bx, by] = nodeC(b);
    const dx = bx - ax, dy = by - ay;
    const L = Math.hypot(dx, dy) || 1;
    const t1 = rectExit(ax, ay, dx / L, dy / L, ...nodeWH(a)) + 2;
    const t2 = rectExit(bx, by, -dx / L, -dy / L, ...nodeWH(b)) + 8;
    const x1 = ax + (dx / L) * t1, y1 = ay + (dy / L) * t1;
    const x2 = ax + (dx / L) * (L - t2), y2 = ay + (dy / L) * (L - t2);
    const hot = FLOW.sel === e.id ? " hot" : "";
    const p = document.createElementNS("http://www.w3.org/2000/svg", "path");
    p.setAttribute("class", "fc-edge" + hot);
    p.setAttribute("d", `M ${x1} ${y1} L ${x2} ${y2}`);
    p.setAttribute("marker-end", "url(#fcArrow)");
    p.dataset.eid = e.id;
    svg.appendChild(p);
    p.onclick = (ev) => { ev.stopPropagation(); FLOW.sel = e.id; flowRender(); };
    p.ondblclick = (ev) => { ev.stopPropagation(); flowEditLabel(e); };
    // 标签（HTML 层，方便双击编辑）
    if (e.label) {
      const lab = document.createElement("div");
      lab.className = "fc-elabel";
      lab.textContent = e.label;
      lab.style.left = (x1 + x2) / 2 + "px";
      lab.style.top = (y1 + y2) / 2 + "px";
      lab.ondblclick = (ev) => { ev.stopPropagation(); flowEditLabel(e); };
      $("#fcCanvas").appendChild(lab);
    }
  }

  function flowEditLabel(e) {
    const val = prompt("连线标签（如：是 / 否，留空删除）：", e.label || "");
    if (val === null) return;
    e.label = val.trim();
    flowTouch(); flowRender();
  }

  /* ---- 节点图片：插入 / 隐藏 / 替换 / 删除 ---- */
  // 有图时打开管理弹窗；无图时直接打开文件选择
  function flowImgMenu(n) {
    if (!n.img) { flowPickImage(n); return; }
    openModal(`
      <h3>节点图片 · ${esc(n.text || FC_TITLES[n.type])}</h3>
      <div class="fc-img-preview">${n.imgHidden
        ? '<p class="muted">🚫 当前图片已隐藏（节点恢复普通尺寸）</p>'
        : `<img src="${esc(n.img)}" alt="节点图片">`}</div>
      <div class="modal-actions fc-img-actions">
        <button class="btn-ghost" id="imToggle">${n.imgHidden ? "👁 显示图片" : "🚫 隐藏图片"}</button>
        <button class="btn-ghost" id="imReplace">替换图片</button>
        <button class="btn-ghost danger" id="imDel">删除图片</button>
        <button class="btn-primary" id="imClose">完成</button>
      </div>`);
    $("#imToggle").onclick = () => {
      n.imgHidden = !n.imgHidden;
      closeModal(); flowTouch(); flowRender();
      toast(n.imgHidden ? "图片已隐藏" : "图片已显示");
    };
    $("#imReplace").onclick = () => { closeModal(); flowPickImage(n); };
    $("#imDel").onclick = () => {
      n.img = ""; n.imgHidden = false;
      closeModal(); flowTouch(); flowRender();
      toast("已删除图片");
    };
    $("#imClose").onclick = () => closeModal();
  }

  // 选择本地图片并上传到服务器，成功后挂到节点上（img=图片URL，imgHidden=是否隐藏）
  function flowPickImage(n) {
    const inp = document.createElement("input");
    inp.type = "file";
    inp.accept = "image/*";
    inp.onchange = async () => {
      const file = inp.files && inp.files[0];
      if (!file) return;
      if (file.size > 8 * 1024 * 1024) { toast("图片不能超过 8MB", false); return; }
      try {
        const fd = new FormData();
        fd.append("file", file);
        const res = await fetch(BASE + "/api/upload", { method: "POST", body: fd });
        const data = await res.json().catch(() => null);
        if (!res.ok) throw new Error((data && data.error) || ("上传失败 " + res.status));
        n.img = data.url;
        n.imgHidden = false;
        flowTouch(); flowRender();
        toast("图片已插入", "done");
      } catch (e) { toast("图片上传失败：" + e.message, false); }
    };
    inp.click();
  }

  function flowDrawNode(n) {
    const [w, h] = nodeWH(n);
    const el = document.createElement("div");
    n._el = el; // 供连线拖拽时高亮目标节点
    el.className = "fc-node t-" + n.type + ((FLOW.sel === n.id || FLOW.multi.has(n.id)) ? " selected" : "");
    if (n.img && !n.imgHidden) el.classList.add("has-img");
    el.style.left = n.x + "px"; el.style.top = n.y + "px";
    el.style.width = w + "px"; el.style.height = h + "px";
    if (n.type === "decision") el.innerHTML = '<div class="fc-shape"></div>';
    const txt = document.createElement("span");
    txt.textContent = n.text || FC_TITLES[n.type];
    el.appendChild(txt);
    // 节点图片：插入后显示在文字下方（覆盖填充），可通过 🖼 菜单隐藏/替换/删除
    if (n.img && !n.imgHidden) {
      const im = document.createElement("img");
      im.className = "fc-img";
      im.src = n.img;
      im.draggable = false;
      im.alt = "";
      im.ondblclick = (ev) => ev.stopPropagation(); // 图片上双击不触发改文字
      el.appendChild(im);
    }
    // 图片按钮（选中节点时出现）：无图=插入图片，有图=打开 隐藏/替换/删除 菜单
    const imgBtn = document.createElement("div");
    imgBtn.className = "fc-imgbtn" + (n.img && n.imgHidden ? " off" : "");
    imgBtn.textContent = "🖼";
    imgBtn.title = n.img ? (n.imgHidden ? "图片已隐藏，点击管理" : "图片：隐藏 / 替换 / 删除") : "插入图片";
    imgBtn.onmousedown = (ev) => ev.stopPropagation(); // 避免触发节点拖动
    imgBtn.onclick = (ev) => { ev.stopPropagation(); flowImgMenu(n); };
    el.appendChild(imgBtn);
    const del = document.createElement("div");
    del.className = "fc-del"; del.textContent = "×";
    del.onclick = (ev) => { ev.stopPropagation(); flowDelNode(n.id); };
    el.appendChild(del);
    // 「结束」只能被连接，不能拉出新步骤 → 不渲染端口
    let port = null;
    if (n.type !== "end") {
      port = document.createElement("div");
      port.className = "fc-port";
      el.appendChild(port);
    }
    const canvas = $("#fcCanvas");
    canvas.appendChild(el);

    // 拖动节点（框选/多选后整体拖动）
    el.addEventListener("mousedown", (ev) => {
      if (ev.target === port) return;
      ev.stopPropagation();
      if (ev.ctrlKey || ev.metaKey || ev.shiftKey) {
        // Ctrl/Shift + 点击：加入/移出多选
        if (FLOW.multi.has(n.id)) FLOW.multi.delete(n.id); else FLOW.multi.add(n.id);
        FLOW.sel = n.id;
        FLOW.__skipClick = true; // 抑制随后的 click 把多选重置掉
        flowRender();
        return;
      }
      if (!FLOW.multi.has(n.id)) FLOW.multi.clear();
      FLOW.sel = n.id;
      el.classList.add("dragging");
      // 不整体重排（会打断拖拽），仅同步各节点选中态
      const selSet = new Set(FLOW.multi); selSet.add(n.id);
      FLOW.nodes.forEach((m) => { if (m._el) m._el.classList.toggle("selected", selSet.has(m.id)); });
      flowRenderEdgesOnly();
      const sx = ev.clientX, sy = ev.clientY;
      const moving = flowSelNodes().map((m) => ({ n: m, ox: m.x, oy: m.y }));
      let moved = false;
      const move = (mv) => {
        const dx = mv.clientX - sx, dy = mv.clientY - sy;
        if (!moved && Math.abs(dx) + Math.abs(dy) > 3) moved = true;
        moving.forEach(({ n: m, ox, oy }) => {
          m.x = Math.max(0, Math.round(ox + dx));
          m.y = Math.max(0, Math.round(oy + dy));
          if (m._el) { m._el.style.left = m.x + "px"; m._el.style.top = m.y + "px"; }
        });
        flowRenderEdgesOnly();
      };
      const up = () => {
        document.removeEventListener("mousemove", move);
        document.removeEventListener("mouseup", up);
        el.classList.remove("dragging");
        if (moved) { FLOW.__skipClick = true; flowTouch(); flowRender(); }
      };
      document.addEventListener("mousemove", move);
      document.addEventListener("mouseup", up);
    });
    // 进入文字编辑模式
    const startFlowEdit = () => {
      const input = document.createElement("input");
      input.value = n.text || "";
      input.style.cssText = "width:92%;font:inherit;text-align:center;border:none;outline:none;background:transparent;color:inherit;font-weight:600";
      txt.replaceWith(input);
      const commit = () => {
        if (input.dataset.done) return;
        input.dataset.done = "1";
        document.removeEventListener("mousedown", onOutside, true);
        n.text = input.value.trim() || FC_TITLES[n.type];
        // 内容节点改名 → 同步到详细信息步骤树
        if (isContentNode(n) && n.stepId) {
          const s = findStepById(n.stepId);
          if (s) s.name = n.text;
        }
        flowTouch(); flowRender();
      };
      // 兜底：点击输入框以外任何地方也提交（无焦点环境下 blur 不会触发）
      const onOutside = (de) => { if (!input.contains(de.target)) commit(); };
      document.addEventListener("mousedown", onOutside, true);
      input.addEventListener("blur", commit);
      input.addEventListener("keydown", (ke) => {
        if (ke.key === "Enter") { ke.preventDefault(); input.blur(); }
        ke.stopPropagation();
      });
      // 防止在输入框内按下鼠标触发节点拖动
      input.addEventListener("mousedown", (me) => me.stopPropagation());
      input.addEventListener("dblclick", (de) => de.stopPropagation());
      input.focus(); input.select();
    };

    // 单击：仅同步选中态（绝不重建节点 DOM，避免破坏双击目标与编辑输入框）。
    // 同节点 400ms 内再次单击视为「双击」→ 进入文字编辑；手动检测不依赖原生
    // dblclick，可兼容各种双击节奏，也不会因 DOM 重建而丢失双击目标。
    el.onclick = (ev) => {
      ev.stopPropagation();
      if (FLOW.__skipClick) { FLOW.__skipClick = false; return; }
      // 正在编辑本节点（已有 input）时，单击交给输入框自身处理，避免再次触发编辑
      if (el.querySelector("input")) { ev.stopPropagation(); return; }
      const now = Date.now();
      if (FLOW.__dbl.id === n.id && now - FLOW.__dbl.t < 400) {
        FLOW.__dbl = { id: null, t: 0 };
        if (!el.querySelector("input")) startFlowEdit();
        return;
      }
      FLOW.__dbl = { id: n.id, t: now };
      if (FLOW.sel === n.id && FLOW.multi.has(n.id)) return;
      if (FLOW.multi.size && !FLOW.multi.has(n.id)) FLOW.multi.clear();
      FLOW.sel = n.id;
      clearTimeout(FLOW.__clickTimer);
      FLOW.__clickTimer = setTimeout(() => flowSyncSelection(), 60);
    };
    imgBtn.ondblclick = (ev) => ev.stopPropagation();
    del.ondblclick = (ev) => ev.stopPropagation();

    // 从端口拖出连线（任意节点都可拖出 / 拖入，方向不限；结束节点无端口）
    if (port) port.addEventListener("mousedown", (ev) => {
      ev.stopPropagation(); ev.preventDefault();
      const ghost = document.createElementNS("http://www.w3.org/2000/svg", "path");
      ghost.setAttribute("class", "fc-edge");
      ghost.setAttribute("stroke-dasharray", "5,4");
      $("#fcSvg").appendChild(ghost);
      const [ax, ay] = nodeC(n);
      let hintEl = null;
      const clearHint = () => { if (hintEl) { hintEl.classList.remove("fc-link-hint"); hintEl = null; } };
      // 画布内容坐标（需加上滚动偏移，否则滚动后目标检测错位）
      const pt = (cv) => {
        const r = $("#fcCanvas").getBoundingClientRect();
        return [cv.clientX - r.left + $("#fcCanvas").scrollLeft, cv.clientY - r.top + $("#fcCanvas").scrollTop];
      };
      const hitNode = (mx, my) => FLOW.nodes.find((t) => {
        if (t.id === n.id) return false;
        const [tw, th] = nodeWH(t);
        return mx >= t.x && mx <= t.x + tw && my >= t.y && my <= t.y + th;
      });
      const move = (mv) => {
        const [mx, my] = pt(mv);
        ghost.setAttribute("d", `M ${ax} ${ay} L ${mx} ${my}`);
        const t = hitNode(mx, my);
        if (hintEl !== (t && t._el)) { clearHint(); if (t && t._el) { t._el.classList.add("fc-link-hint"); hintEl = t._el; } }
      };
      const up = (uv) => {
        document.removeEventListener("mousemove", move);
        document.removeEventListener("mouseup", up);
        ghost.remove(); clearHint();
        const [mx, my] = pt(uv);
        const target = hitNode(mx, my);
        if (target) {
          if (!FLOW.edges.some((e) => e.from === n.id && e.to === target.id)) {
            FLOW.edges.push({ id: uid(), from: n.id, to: target.id, label: "" });
            FLOW.sel = null;
            flowTouch(); flowRender();
          }
        } else {
          // 拉出生成新步骤：详细信息里作为「被拉节点」的子项（开始节点拉出的才是顶层步骤）
          const [x, y] = freeSpot(FC_SIZES.process[0], FC_SIZES.process[1], mx - 60, my - 22); // 新步骤尚未带图，用基础尺寸
          const parentStep = (n.type !== "start" && n.stepId) ? findStepById(n.stepId) : null;
          const s = { id: uid(), name: "新步骤", hours: "", children: [] };
          if (parentStep) {
            parentStep.children = parentStep.children || [];
            parentStep.children.push(s);
          } else {
            FLOW.steps.push(s);
          }
          const id2 = uid();
          FLOW.nodes.push({ id: id2, type: "process", text: "新步骤", x, y, stepId: s.id });
          FLOW.edges.push({ id: uid(), from: n.id, to: id2, label: "" });
          FLOW.sel = id2;
          flowTouch(); flowRender();
          toast(parentStep ? `已作为「${parentStep.name}」的子步骤` : "已添加顶层步骤");
        }
      };
      document.addEventListener("mousemove", move);
      document.addEventListener("mouseup", up);
    });
  }

  // 仅重画连线层（拖动时用，避免重建节点打断拖拽）
  function flowRenderEdgesOnly() {
    const svg = $("#fcSvg");
    svg.querySelectorAll("path.fc-edge").forEach((p) => p.remove());
    $("#fcCanvas").querySelectorAll(".fc-elabel").forEach((l) => l.remove());
    FLOW.edges.forEach((e) => flowDrawEdge(e));
  }

  // 当前选中的节点（多选集合 ∪ 单选主节点）
  function flowSelNodes() {
    const ids = new Set(FLOW.multi);
    if (FLOW.sel) ids.add(FLOW.sel);
    return FLOW.nodes.filter((n) => ids.has(n.id));
  }

  // 对齐工具条显隐：选中 ≥2 个节点时出现
  function flowAlignBarSync() {
    const bar = $("#fcAlignBar");
    if (bar) bar.classList.toggle("hidden", flowSelNodes().length < 2);
  }

  // 对齐/等距：对选中的多个节点批量调整位置
  function flowAlign(mode) {
    const ns = flowSelNodes();
    if (ns.length < 2) { toast("请先框选或 Ctrl+点击选择至少两个节点", false); return; }
    const W = (n) => nodeWH(n)[0], H = (n) => nodeWH(n)[1];
    const minX = Math.min(...ns.map((n) => n.x));
    const maxX = Math.max(...ns.map((n) => n.x + W(n)));
    const minY = Math.min(...ns.map((n) => n.y));
    const maxY = Math.max(...ns.map((n) => n.y + H(n)));
    const cxAvg = ns.reduce((s, n) => s + n.x + W(n) / 2, 0) / ns.length;
    const cyAvg = ns.reduce((s, n) => s + n.y + H(n) / 2, 0) / ns.length;
    if (mode === "left") ns.forEach((n) => (n.x = minX));
    else if (mode === "right") ns.forEach((n) => (n.x = maxX - W(n)));
    else if (mode === "hcenter") ns.forEach((n) => (n.x = cxAvg - W(n) / 2));
    else if (mode === "top") ns.forEach((n) => (n.y = minY));
    else if (mode === "bottom") ns.forEach((n) => (n.y = maxY - H(n)));
    else if (mode === "vcenter") ns.forEach((n) => (n.y = cyAvg - H(n) / 2));
    else if (mode === "distx" || mode === "disty") {
      const byC = (n) => (mode === "distx" ? n.x + W(n) / 2 : n.y + H(n) / 2);
      const set = (n, c) => { if (mode === "distx") n.x = c - W(n) / 2; else n.y = c - H(n) / 2; };
      const arr = [...ns].sort((a, b) => byC(a) - byC(b));
      const c0 = byC(arr[0]), c1 = byC(arr[arr.length - 1]);
      const step = arr.length > 1 ? (c1 - c0) / (arr.length - 1) : 0;
      arr.forEach((n, i) => set(n, c0 + i * step));
    }
    flowTouch(); flowRender();
  }

  function flowDelNode(id) {
    const n = FLOW.nodes.find((x) => x.id === id);
    // 内容节点删除 → 详细信息里对应步骤一并删除
    if (n && isContentNode(n) && n.stepId) removeStepById(n.stepId);
    FLOW.nodes = FLOW.nodes.filter((n) => n.id !== id);
    FLOW.edges = FLOW.edges.filter((e) => e.from !== id && e.to !== id);
    FLOW.sel = null;
    flowTouch(); flowRender();
  }

  function flowAddNode(type) {
    if (!FLOW.proj) return;
    const [w, h] = nodeWH({ type });
    // 空白落点，避免新节点盖住旧节点端口（导致旧节点拖不出连线）
    const [x, y] = freeSpot(w, h);
    const node = { id: uid(), type, text: FC_TITLES[type], x, y };
    if (type === "end") {
      // 结束：同步进详细信息，但需选择所属层级，避免层级混乱；取消则放弃创建
      FLOW.nodes.push(node);
      FLOW.sel = node.id;
      flowRender();
      const s = { id: uid(), name: "结束", hours: "", children: [], kind: "end" };
      chooseStepLevel(null, (parentId) => {
        if (parentId) {
          const p = findStepById(parentId);
          if (p) { p.children = p.children || []; p.children.push(s); }
          else FLOW.steps.push(s);
        } else {
          FLOW.steps.push(s);
        }
        node.stepId = s.id;
        flowTouch(); flowRender();
        toast(parentId ? "「结束」已加入所选层级" : "「结束」已加入顶层");
      }, () => {
        FLOW.nodes = FLOW.nodes.filter((m) => m.id !== node.id);
        FLOW.sel = null;
        flowRender();
      });
      return;
    }
    if (isContentNode(node)) {
      // 过程/输入输出/判断节点与详细信息步骤双向同步（判断带 kind 标记）
      const s = { id: uid(), name: type === "decision" ? "判断" : "新步骤", hours: "", children: [] };
      const k = stepKindOf(node);
      if (k) s.kind = k;
      FLOW.steps.push(s);
      node.stepId = s.id;
      node.text = s.name;
    }
    FLOW.nodes.push(node);
    FLOW.sel = node.id;
    flowTouch(); flowRender();
  }

  // 把某步骤（连同其子树）移动到指定父步骤下（parentId 为空 = 顶层）
  function moveStepToParent(stepId, parentId) {
    let removed = null;
    const detach = (list) => {
      const i = list.findIndex((s) => s.id === stepId);
      if (i >= 0) { removed = list.splice(i, 1)[0]; return true; }
      return list.some((s) => detach(s.children || []));
    };
    detach(FLOW.steps);
    if (!removed) return false;
    if (parentId) {
      const p = findStepById(parentId);
      if (p) { p.children = p.children || []; p.children.push(removed); return true; }
    }
    FLOW.steps.push(removed);
    return true;
  }

  // 选择层级弹窗：在详细信息步骤树中选一个归属位置（顶层 / 某步骤之下）
  // defaultId: 预选的步骤；排除 kind=end 的步骤作为父级（结束下面不应再挂层级）
  function chooseStepLevel(defaultId, onOk, onCancel) {
    const rows = ['<label class="lv-row"><input type="radio" name="lv" value=""' + (!defaultId ? " checked" : "") + '><span>顶层（与主步骤平级）</span></label>'];
    const walk = (nodes, depth) => (nodes || []).forEach((s) => {
      if (s.kind !== "end") {
        rows.push(`<label class="lv-row" style="padding-left:${14 + depth * 22}px"><input type="radio" name="lv" value="${s.id}"${s.id === defaultId ? " checked" : ""}><span>${esc(s.name)}${s.kind === "decision" ? " <em>（判断）</em>" : ""}</span></label>`);
      }
      walk(s.children, depth + 1);
    });
    walk(FLOW.steps, 0);
    openModal(`
      <h3>选择「结束」所属层级</h3>
      <p class="muted small">「结束」会同步进「详细信息」的步骤树，请选择它挂在哪个层级之下，避免层级混乱。</p>
      <div class="lv-list">${rows.join("")}</div>
      <div class="modal-actions">
        <button class="btn-ghost" id="lvCancel">取消</button>
        <button class="btn-primary" id="lvOk">确定</button>
      </div>`);
    $("#lvOk").onclick = () => {
      const v = (document.querySelector('input[name="lv"]:checked') || {}).value || "";
      closeModal();
      onOk(v || null);
    };
    $("#lvCancel").onclick = () => { closeModal(); if (onCancel) onCancel(); };
  }

  // 键盘：Delete 删除选中节点（含框选的多个）
  document.addEventListener("keydown", (ev) => {
    if (!FLOW.proj || $("#refineBoard").classList.contains("hidden")) return;
    if (ev.key !== "Delete" && ev.key !== "Backspace") return;
    const tag = document.activeElement && document.activeElement.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA") return;
    const ids = new Set(FLOW.multi);
    if (FLOW.sel) ids.add(FLOW.sel);
    if (!ids.size) return;
    [...ids].forEach((id) => flowDelNode(id));
  });

  function treeTextHTML(nodes, depth) {
    let out = "";
    nodes.forEach((n) => {
      const kind = n.kind === "decision" ? '<span class="tk-ind">判断</span>' : n.kind === "end" ? '<span class="tk-ind">结束</span>' : "";
      out += `<div class="tline" style="padding-left:${depth * 18}px">${depth ? "└ " : ""}${kind}${esc(n.name || "（未命名）")}${n.hours ? ` <span class="th">⏱${n.hours}h</span>` : ""}</div>`;
      out += treeTextHTML(n.children || [], depth + 1);
    });
    return out;
  }

  /* ================= 层级选择器：分类 → 项目 → 步骤（可折叠 + 搜索） =================
   * 替代原生平铺 select。值与旧格式一致："p<id>" = 整个项目，"s<pid>:<sid>" = 某步骤，
   * 并同步写入隐藏的 #planProjSel，resolveSel / onCellClick 等读取处无需改动。
   */
  const TS_OPEN = { inst: null }; // 全局同时只展开一个下拉
  let TS_SEQ = 0;

  function tsValueLabel(v) {
    const { proj, stepNode } = resolveSel(v);
    if (!proj) return "";
    if (stepNode && stepNode.name) return `${proj.name} · ${stepNode.name}${stepNode.hours ? "（" + stepNode.hours + "h）" : ""}`;
    return `${proj.name}（整个项目）`;
  }

  // 分类分组：按用户分类顺序，仅保留有项目的分类；未知分类追加在后
  function tsGroups() {
    const cats = [], seen = new Set();
    (window.APP.categories || []).forEach((c) => { if (!seen.has(c)) { cats.push(c); seen.add(c); } });
    PROJECTS.forEach((p) => { const c = p.category || "其他"; if (!seen.has(c)) { cats.push(c); seen.add(c); } });
    return cats
      .map((c) => ({ cat: c, projs: PROJECTS.filter((p) => (p.category || "其他") === c) }))
      .filter((g) => g.projs.length > 0);
  }

  // 项目下全部步骤（含子级，扁平）
  function tsFlattenSteps(nodes, out) {
    (nodes || []).forEach((n) => { out.push(n); tsFlattenSteps(n.children || [], out); });
    return out;
  }

  function createTreeSelect(mount, opts = {}) {
    const state = {
      value: opts.value || "", open: false, q: "",
      collapsed: new Set(),  // 被折叠的分类名（默认全折叠）
      openProj: new Set(),   // 展开了步骤列表的项目（"p<id>"）
      openStep: new Set(),   // 展开了子步骤的父步骤（"s<pid>:<sid>"，默认全折叠）
    };
    tsGroups().forEach((g) => state.collapsed.add(g.cat));

    const root = document.createElement("div");
    root.className = "ts";
    root.innerHTML = `
      <button type="button" class="ts-trigger">
        <span class="ts-label">选择项目 / 步骤…</span><span class="ts-arrow">▾</span>
      </button>
      <div class="ts-pop hidden">
        <div class="ts-search-wrap"><input class="ts-search" type="text" placeholder="搜索项目 / 步骤…"></div>
        <div class="ts-list"></div>
      </div>`;
    mount.appendChild(root);
    if (mount.__ts) mount.__ts.destroy();
    const labelEl = root.querySelector(".ts-label");
    const pop = root.querySelector(".ts-pop");
    const searchEl = root.querySelector(".ts-search");
    const listEl = root.querySelector(".ts-list");

    function syncLabel() {
      const t = tsValueLabel(state.value);
      labelEl.textContent = t || "选择项目 / 步骤…";
      root.classList.toggle("has-val", !!t);
    }
    syncLabel();

    // 递归渲染步骤树：父步骤也可折叠/展开，子级缩进 + 虚线边线（与流程图层级一致）
    function stepRows(p, nodes, q, catHit, projMatch) {
      let h = "";
      (nodes || []).forEach((n) => {
        const kids = n.children || [];
        const selfHit = !q || n.name.toLowerCase().includes(q);
        const kidHit = !q || (function anyHit(ns) {
          return (ns || []).some((k) => k.name.toLowerCase().includes(q) || anyHit(k.children));
        })(kids);
        if (!catHit && !projMatch && !selfHit && !kidHit) return;
        const expanded = !!q || state.openStep.has("s" + p.id + ":" + n.id);
        h += `<div class="ts-srow${state.value === "s" + p.id + ":" + n.id ? " selected" : ""}">
          ${kids.length ? `<button type="button" class="ts-sw" data-act="tws" data-pid="${p.id}" data-sid="${esc(n.id)}" title="展开/收起子步骤">${expanded ? "▼" : "▶"}</button>` : `<span class="ts-sw none"></span>`}
          <button type="button" class="ts-sn" data-act="pick" data-val="s${p.id}:${esc(n.id)}" title="选择该步骤">${esc(n.name)}${n.hours ? `<span class="ts-sub">${n.hours}h</span>` : ""}</button>
        </div>`;
        if (expanded && kids.length) {
          h += `<div class="ts-steps">${stepRows(p, kids, q, catHit, projMatch)}</div>`;
        }
      });
      return h;
    }

    function rowProj(p, q, catHit) {
      const steps = p.steps || [];
      const projMatch = !q || p.name.toLowerCase().includes(q);
      const showSteps = steps.length > 0 && (!!q || state.openProj.has("p" + p.id));
      let h = `<div class="ts-proj${state.value === "p" + p.id ? " selected" : ""}">
        ${steps.length ? `<button type="button" class="ts-tw" data-act="tw" data-pid="${p.id}" title="展开/收起步骤">${showSteps ? "▼" : "▶"}</button>` : `<span class="ts-tw none"></span>`}
        <button type="button" class="ts-pn" data-act="pick" data-val="p${p.id}" title="选择整个项目">${esc(p.name)}<span class="ts-sub">整个项目 · 总预估${p.expected_hours}h</span></button>
      </div>`;
      if (showSteps) {
        h += `<div class="ts-steps">${stepRows(p, steps, q, catHit, projMatch)}</div>`;
      }
      return h;
    }

    // 找某步骤在树中的路径（含自身），用于打开浮层时自动展开其祖先链
    function tsFindPath(nodes, sid, path) {
      for (const n of (nodes || [])) {
        if (String(n.id) === String(sid)) { path.push(n); return true; }
        if (tsFindPath(n.children || [], sid, path)) { path.push(n); return true; }
      }
      return false;
    }

    function renderList() {
      const q = state.q.trim().toLowerCase();
      let html = "";
      tsGroups().forEach((g) => {
        const catHit = !q || g.cat.toLowerCase().includes(q);
        const projs = q && !catHit
          ? g.projs.filter((p) => p.name.toLowerCase().includes(q) || tsFlattenSteps(p.steps, []).some((n) => n.name.toLowerCase().includes(q)))
          : g.projs;
        if (!projs.length) return;
        const expanded = !!q || !state.collapsed.has(g.cat);
        html += `<div class="ts-cat${expanded ? "" : " collapsed"}">
          <button type="button" class="ts-cat-head" data-act="cat" data-cat="${esc(g.cat)}">
            <span class="ts-arr">${expanded ? "▼" : "▶"}</span><span class="ts-cat-name">${esc(g.cat)}</span><span class="ts-cnt">${g.projs.length}</span>
          </button>
          <div class="ts-cat-body"${expanded ? "" : " hidden"}>`;
        projs.forEach((p) => { html += rowProj(p, q, catHit); });
        html += `</div></div>`;
      });
      listEl.innerHTML = html || `<div class="ts-empty">没有匹配的项目 / 步骤</div>`;
    }

    function selectVal(v) {
      state.value = v;
      const src = $("#planProjSel");
      if (src) src.value = v;
      syncLabel();
      if (opts.onChange) opts.onChange(v);
      closePop();
    }

    function openPop() {
      if (state.open) return;
      if (TS_OPEN.inst && TS_OPEN.inst !== api) TS_OPEN.inst.close();
      state.open = true;
      TS_OPEN.inst = api;
      // 当前选中项所在的分类/项目/父步骤自动展开，便于看到所选
      if (state.value) {
        const r = resolveSel(state.value);
        if (r.proj) {
          state.collapsed.delete(r.proj.category || "其他");
          state.openProj.add("p" + r.proj.id);
          if (r.stepNode) {
            const path = [];
            tsFindPath(r.proj.steps, r.stepNode.id, path);
            path.forEach((n) => state.openStep.add("s" + r.proj.id + ":" + n.id));
          }
        }
      }
      root.classList.add("open");
      pop.classList.remove("hidden");
      // 智能翻转：下方空间不足时向上展开，避免浮层超出屏幕
      pop.style.top = ""; pop.style.bottom = "";
      const rect = root.getBoundingClientRect();
      if (rect.bottom + 400 > window.innerHeight && rect.top > 420) {
        pop.style.top = "auto";
        pop.style.bottom = "calc(100% + 6px)";
      }
      renderList();
      setTimeout(() => searchEl.focus(), 0);
    }
    function closePop() {
      if (!state.open) return;
      state.open = false;
      if (TS_OPEN.inst === api) TS_OPEN.inst = null;
      state.q = ""; searchEl.value = "";
      root.classList.remove("open");
      pop.classList.add("hidden");
    }

    root.querySelector(".ts-trigger").addEventListener("click", (ev) => {
      ev.stopPropagation();
      state.open ? closePop() : openPop();
    });
    searchEl.addEventListener("input", () => { state.q = searchEl.value; renderList(); });
    searchEl.addEventListener("click", (ev) => ev.stopPropagation());
    listEl.addEventListener("click", (ev) => {
      const btn = ev.target.closest("[data-act]");
      if (!btn) return;
      ev.stopPropagation();
      const act = btn.dataset.act;
      if (act === "cat") {
        const c = btn.dataset.cat;
        state.collapsed.has(c) ? state.collapsed.delete(c) : state.collapsed.add(c);
        renderList();
      } else if (act === "tw") {
        const k = "p" + btn.dataset.pid;
        state.openProj.has(k) ? state.openProj.delete(k) : state.openProj.add(k);
        renderList();
      } else if (act === "tws") {
        const k = "s" + btn.dataset.pid + ":" + btn.dataset.sid;
        state.openStep.has(k) ? state.openStep.delete(k) : state.openStep.add(k);
        renderList();
      } else if (act === "pick") {
        selectVal(btn.dataset.val);
      }
    });
    const onDocDown = (ev) => { if (state.open && !root.contains(ev.target)) closePop(); };
    const onDocKey = (ev) => { if (ev.key === "Escape" && state.open) { ev.stopPropagation(); closePop(); } };
    document.addEventListener("mousedown", onDocDown);
    document.addEventListener("keydown", onDocKey);

    var api = {
      getValue: () => state.value,
      setValue: (v) => {
        state.value = v || "";
        const src = $("#planProjSel");
        if (src) src.value = state.value;
        syncLabel();
      },
      refresh: () => { syncLabel(); if (state.open) renderList(); },
      open: openPop,
      close: closePop,
      destroy: () => {
        closePop();
        document.removeEventListener("mousedown", onDocDown);
        document.removeEventListener("keydown", onDocKey);
        if (mount.__ts === api) mount.__ts = null;
        root.remove();
      },
    };
    mount.__ts = api;
    return api;
  }

  let planTs = null;
  function renderPlanSel() {
    const mount = $("#planProjTs");
    if (!mount) return;
    if (planTs) { planTs.destroy(); planTs = null; }
    planTs = createTreeSelect(mount, {});
    // 同步隐藏原生 select：保留旧 value 语义与 options（供 resolveSel / onCellClick 使用）
    const sel = $("#planProjSel");
    if (sel) {
      const cur = sel.value;
      sel.innerHTML = "";
      PROJECTS.forEach((p) => {
        const o = document.createElement("option");
        o.value = "p" + p.id; o.textContent = `${p.name}（整个项目 · 总预估${p.expected_hours}h）`;
        sel.appendChild(o);
        const walk = (nodes, depth) => {
          (nodes || []).forEach((n) => {
            const so = document.createElement("option");
            so.value = "s" + p.id + ":" + n.id;
            so.textContent = "　".repeat(depth) + "└ " + n.name + (n.hours ? "（" + n.hours + "h）" : "");
            sel.appendChild(so);
            walk(n.children || [], depth + 1);
          });
        };
        walk(p.steps, 0);
      });
      sel.value = [...sel.options].some((o) => o.value === cur) ? cur : "";
    }
  }

  /* ---- 新建/编辑项目弹窗 ---- */
  // 扩充预设色板（24 色），多项目/多分支也不易撞色
  const PRESET_COLORS = [
    "#3b82f6", "#ef4444", "#10b981", "#f59e0b", "#8b5cf6", "#ec4899",
    "#06b6d4", "#84cc16", "#f97316", "#14b8a6", "#6366f1", "#d946ef",
    "#0ea5e9", "#22c55e", "#eab308", "#a855f7", "#fb7185", "#4ade80",
    "#38bdf8", "#c084fc", "#facc15", "#2dd4bf", "#f43f5e", "#818cf8",
  ];
  // 固定安排的醒目预设色（替代原来的浅灰）
  const FIXED_PRESET = ["#64748b", "#7c3aed", "#0d9488", "#b45309", "#be185d", "#4338ca", "#0e7490", "#4d7c0f"];

  function showNewProjectModal(proj) {
    const isEdit = !!(proj && proj.id); // 只有带有效 id 才算编辑，防止 event 对象误入
    const p = proj || { name: "", category: "其他", description: "", color: "#3b82f6" };
    openModal(`
      <h3>${isEdit ? "编辑项目" : "新建项目"}</h3>
      <p class="muted small">版块一：为想做的事命名并做初步分类。</p>
      <div class="field"><label>项目名称 *</label><input id="npName" value="${esc(p.name)}" placeholder="例如：写完季度报告"></div>
      <div class="row2">
        <div class="field"><label>初步分类</label>
          <select id="npCat">${window.APP.categories.map((c) => `<option ${c === p.category ? "selected" : ""}>${c}</option>`).join("")}</select>
        </div>
        <div class="field"><label>标签颜色</label>
          <div class="color-row">
            <input type="color" id="npColor" value="${esc(p.color || "#3b82f6")}">
            <div class="swatches">${PRESET_COLORS.map((c) => `<button type="button" class="swatch${c === p.color ? " on" : ""}" data-c="${c}" style="background:${c}"></button>`).join("")}</div>
          </div>
        </div>
      </div>
      <div class="field"><label>描述（可选）</label><textarea id="npDesc" rows="3" placeholder="简单记录想法…">${esc(p.description || "")}</textarea></div>
      <div class="modal-actions">
        <button class="btn-ghost" onclick="window.__close()">取消</button>
        <button class="btn-primary" id="npSave">${isEdit ? "保存" : "创建"}</button>
      </div>`);
    $$(".swatch").forEach((b) => {
      b.onclick = () => {
        $("#npColor").value = b.dataset.c;
        $$(".swatch").forEach((x) => x.classList.remove("on"));
        b.classList.add("on");
      };
    });
    $("#npColor").oninput = () => $$(".swatch").forEach((x) => x.classList.remove("on"));
    $("#npSave").onclick = async () => {
      const name = $("#npName").value.trim();
      if (!name) { toast("请填写项目名称", false); return; }
      const payload = {
        name, category: $("#npCat").value, description: $("#npDesc").value.trim(),
        color: $("#npColor").value,
      };
      // 始终以真实 id 为准，杜绝因 event 对象误入而 PUT 到 /api/projects/undefined
      const editId = (proj && proj.id) || null;
      const btn = $("#npSave");
      const from = btn ? btn.getBoundingClientRect() : null;
      try {
        let created = null;
        if (editId) await api("PUT", "/api/projects/" + editId, payload);
        else created = await api("POST", "/api/projects", payload);
        closeModal(); toast(editId ? "已保存" : "已创建");
        await loadProjects();
        // 新建项目：从保存按钮位置飞入极坐标图对应扇区
        if (created && created.id) flyToPolar(created, from ? from.left + from.width / 2 : window.innerWidth / 2, from ? from.top + from.height / 2 : window.innerHeight / 2);
      } catch (e) { toast(e.message, false); }
    };
  }

  /* ---- 版块二：细化向导（开始 - 下一步 - 下一步 - 结束）---- */
  function openWizard(proj) {
    let step = 0;
    let draft = {
      expected_hours: proj.expected_hours || 1,
      location: proj.location || "",
      people: proj.people || "",
      funds: proj.funds || 0,
      steps: normSteps(proj.steps), // 步骤树（兼容旧字符串数组）
    };
    const stepsMeta = [
      { key: "base", label: "开始" },
      { key: "steps", label: "细化" },
      { key: "done", label: "结束" },
    ];

    // 步骤树缩进展示文本（确认页/卡片用）
    function treeText(nodes, depth) {
      let out = "";
      nodes.forEach((n) => {
        const kind = n.kind === "decision" ? '<span class="tk-ind">判断</span>' : n.kind === "end" ? '<span class="tk-ind">结束</span>' : "";
        out += `<div class="tline" style="padding-left:${depth * 18}px">${depth ? "└ " : ""}${kind}${esc(n.name || "（未命名）")}${n.hours ? ` <span class="th">⏱${n.hours}h</span>` : ""}</div>`;
        out += treeText(n.children || [], depth + 1);
      });
      return out;
    }

    // 步骤树编辑器（折叠状态按节点 id 记忆，仅本次向导内有效）
    const treeCollapsed = new Set();
    function renderTreeEditor() {
      const box = $("#wTree");
      if (!box) return;
      if (!draft.steps.length) { box.innerHTML = '<div class="muted small">尚未添加步骤。可添加平级步骤，或为某步骤添加子分支。</div>'; return; }
      box.innerHTML = "";
      const walk = (nodes, depth, parent, parentSiblings) => {
        nodes.forEach((node, i) => {
          const kids = node.children || [];
          const folded = treeCollapsed.has(node.id);
          const row = document.createElement("div");
          row.className = "tnode";
          row.style.marginLeft = depth * 24 + "px";
          row.innerHTML = `
            <span class="t-branch">${depth ? "└" : "•"}</span>
            ${kids.length ? `<button class="tb tc" data-op="fold" title="${folded ? "展开分支（共 " + kids.length + " 项被隐藏）" : "折叠分支（隐藏子项）"}">${folded ? "▸" + kids.length : "▾"}</button>` : ""}
            ${node.kind === "decision" ? '<span class="tk-ind">判断</span>' : node.kind === "end" ? '<span class="tk-ind">结束</span>' : ""}
            <input class="t-name" value="${esc(node.name)}" placeholder="步骤名称">
            <input class="t-hours" type="number" min="0.5" step="0.5" placeholder="h" value="${node.hours || ""}" title="该步骤预计用时（小时）">
            <button class="tb" data-op="up" title="上移">↑</button>
            <button class="tb" data-op="down" title="下移">↓</button>
            <button class="tb" data-op="out" title="升一级（变为上一级步骤的平级项）" ${parent ? "" : "disabled"}>⇤</button>
            <button class="tb" data-op="in" title="降为子项（挂到上一个步骤下）" ${i > 0 ? "" : "disabled"}>⇥</button>
            <button class="tb" data-op="addc" title="添加子步骤(分支)">＋</button>
            <button class="tb danger" data-op="del" title="删除">✕</button>`;
          row.querySelector(".t-name").oninput = (e) => { node.name = e.target.value; };
          row.querySelector(".t-hours").oninput = (e) => { node.hours = parseFloat(e.target.value) || ""; };
          const foldBtn = row.querySelector('[data-op="fold"]');
          if (foldBtn) foldBtn.onclick = () => {
            if (treeCollapsed.has(node.id)) treeCollapsed.delete(node.id); else treeCollapsed.add(node.id);
            renderTreeEditor();
          };
          row.querySelector('[data-op="up"]').onclick = () => {
            if (i > 0) { nodes.splice(i, 1); nodes.splice(i - 1, 0, node); renderTreeEditor(); }
          };
          row.querySelector('[data-op="down"]').onclick = () => {
            if (i < nodes.length - 1) { nodes.splice(i, 1); nodes.splice(i + 1, 0, node); renderTreeEditor(); }
          };
          row.querySelector('[data-op="out"]').onclick = () => {
            if (!parent || !parentSiblings) return;
            nodes.splice(i, 1);
            const pi = parentSiblings.indexOf(parent);
            parentSiblings.splice(pi + 1, 0, node);
            renderTreeEditor();
          };
          row.querySelector('[data-op="in"]').onclick = () => {
            if (i <= 0) return;
            nodes.splice(i, 1);
            const prev = nodes[i - 1];
            prev.children = prev.children || [];
            prev.children.push(node);
            treeCollapsed.delete(prev.id); // 降级后自动展开其新父级，确保可见
            renderTreeEditor();
          };
          row.querySelector('[data-op="addc"]').onclick = () => {
            node.children = node.children || [];
            node.children.push({ id: uid(), name: "子步骤", hours: "", children: [] });
            treeCollapsed.delete(node.id);
            renderTreeEditor();
          };
          row.querySelector('[data-op="del"]').onclick = () => {
            nodes.splice(i, 1); renderTreeEditor();
          };
          box.appendChild(row);
          if (!folded) walk(kids, depth + 1, node, nodes);
        });
      };
      walk(draft.steps, 0, null, null);
    }

    function render() {
      const stepper = stepsMeta.map((s, i) => {
        const cls = i === step ? "active" : (i < step ? "done" : "");
        return `<div class="step ${cls}"><span class="dot">${i < step ? "✓" : i + 1}</span>${s.label}</div>${i < stepsMeta.length - 1 ? '<div class="step-line"></div>' : ""}`;
      }).join("");

      let body = "";
      if (step === 0) {
        body = `
          <h3>细化：${esc(proj.name)}</h3>
          <p class="muted small">第 1 步 · 基本信息（时间 / 地点 / 人物 / 资金）</p>
          <div class="field"><label>预期总时间（小时）</label><input id="wHours" type="number" min="0.5" step="0.5" value="${draft.expected_hours}"></div>
          <div class="row2">
            <div class="field"><label>地点</label><input id="wLoc" value="${esc(draft.location)}" placeholder="如：公司 / 家里"></div>
            <div class="field"><label>人物</label><input id="wPpl" value="${esc(draft.people)}" placeholder="如：小王 / 团队"></div>
          </div>
          <div class="field"><label>资金（元）</label><input id="wFund" type="number" min="0" step="0.01" value="${draft.funds}"></div>`;
      } else if (step === 1) {
        body = `
          <h3>拆解步骤（可分支）</h3>
          <p class="muted small">第 2 步 · 「＋」添加子分支，「⇤⇥」升降层级，「▾▸」折叠/展开分支，「↑↓」调整顺序；每个步骤可设预计用时，都能单独放入③时间规划。</p>
          <div class="tree-head"><span></span><span>名称</span><span>用时(h)</span><span colspan="4"></span></div>
          <div class="step-list" id="wTree"></div>
          <button class="btn-ghost" id="wAddStep" style="margin-top:10px">+ 添加一步</button>`;
      } else {
        body = `
          <h3>确认</h3>
          <p class="muted small">第 3 步 · 检查无误后结束细化</p>
          <div class="field"><label>预期总时间</label><div class="muted">${draft.expected_hours} 小时</div></div>
          <div class="field"><label>地点 / 人物 / 资金</label><div class="muted">${esc(draft.location || "—")} / ${esc(draft.people || "—")} / ${draft.funds} 元</div></div>
          <div class="field"><label>步骤树</label><div>${draft.steps.length ? treeText(draft.steps, 0) : '<span class="muted">（无步骤）</span>'}</div></div>`;
      }

      openModal(`
        <div class="stepper">${stepper}</div>
        ${body}
        <div class="modal-actions">
          <button class="btn-ghost" id="wPrev">${step === 0 ? "取消" : "上一步"}</button>
          <button class="btn-primary" id="wNext">${step === stepsMeta.length - 1 ? "完成" : "下一步"}</button>
        </div>`);

      if (step === 1) {
        renderTreeEditor();
        $("#wAddStep").onclick = () => { draft.steps.push({ id: uid(), name: "新步骤", hours: "", children: [] }); renderTreeEditor(); };
      }

      $("#wPrev").onclick = () => {
        if (step === 0) { closeModal(); return; }
        step--; render();
      };
      $("#wNext").onclick = async () => {
        if (step === 0) {
          draft.expected_hours = Math.max(0.5, parseFloat($("#wHours").value) || 1);
          draft.location = $("#wLoc").value.trim();
          draft.people = $("#wPpl").value.trim();
          draft.funds = parseFloat($("#wFund").value) || 0;
          step++; render();
        } else if (step === 1) {
          // 步骤已在输入时同步
          step++; render();
        } else {
          try {
            const updated = await api("PUT", "/api/projects/" + proj.id, {
              expected_hours: draft.expected_hours,
              location: draft.location, people: draft.people, funds: draft.funds,
              steps: draft.steps, status: proj.status || "idea",
            });
            Object.assign(proj, updated);
            const cache = PROJECTS.find((p) => p.id === proj.id);
            if (cache) Object.assign(cache, updated);
            closeModal(); toast("细化完成，流程图已同步");
            await loadProjects();
            // 流程图正打开着该项目 → 立即把步骤变化同步到流程图
            flowAfterWizardSave(updated.id ? updated : proj);
          } catch (e) { toast(e.message, false); }
        }
      };
    }
    render();
  }

  /* ============ 版块三：时间网格 ============ */
  let GRID = null;
  // 视图模式：iso=3D 立体（默认） / flat=平面网格
  let gridMode = localStorage.getItem("id_grid_mode") || "iso";

  function applyGridModeUI() {
    const isoWrap = $("#isoWrap"), flatWrap = $("#weekGrid");
    if (!isoWrap || !flatWrap) return;
    isoWrap.classList.toggle("hidden", gridMode !== "iso");
    flatWrap.classList.toggle("hidden", gridMode !== "flat");
    const b1 = $("#modeIso"), b2 = $("#modeFlat");
    if (b1 && b2) {
      b1.classList.toggle("active", gridMode === "iso");
      b2.classList.toggle("active", gridMode === "flat");
    }
  }

  function setGridMode(m) {
    gridMode = m;
    try { localStorage.setItem("id_grid_mode", m); } catch (e) {}
    applyGridModeUI();
    if (!GRID) return;
    if (m === "iso") drawIsoGrid();
    else { stopIsoLoop(); renderFlatBlocks(); }
  }

  // 窗口尺寸变化时重绘 3D 视图
  let _rsT = null;
  window.addEventListener("resize", () => {
    clearTimeout(_rsT);
    _rsT = setTimeout(() => {
      const v3 = $("#view-p3");
      if (gridMode === "iso" && v3 && v3.classList.contains("active")) drawIsoGrid();
    }, 180);
  });

  function renderTimeCol() {
    const tc = $("#timeCol");
    tc.innerHTML = '<div class="tc-head"></div>';
    for (let h = 0; h < 24; h++) {
      const c = document.createElement("div");
      c.className = "tc-cell";
      c.textContent = h + ":00";
      tc.appendChild(c);
    }
  }

  function renderDaysSkeleton() {
    const days = $("#daysCol");
    days.innerHTML = "";
    const names = window.APP.dayNames;
    for (let d = 1; d <= 7; d++) {
      const col = document.createElement("div");
      col.className = "day-col";
      col.dataset.day = d;
      col.innerHTML = `<div class="day-head"><span>${names[d]}</span><span class="free" id="free-${d}"></span></div>
        <div class="day-body" id="body-${d}"></div>`;
      const body = col.querySelector(".day-body");
      for (let h = 0; h < 24; h++) {
        const cell = document.createElement("div");
        cell.className = "hour-cell";
        cell.dataset.hour = h;
        cell.onclick = () => onCellClick(d, h);
        body.appendChild(cell);
      }
      const blocks = document.createElement("div");
      blocks.className = "blocks";
      blocks.id = "blocks-" + d;
      body.appendChild(blocks);
      days.appendChild(col);
    }
  }

  function blockEl(item, kind, day) {
    const el = document.createElement("div");
    el.className = "block " + kind + (item.done ? " done-block" : "");
    const top = item.start_hour * HOUR_H;
    const height = (item.end_hour - item.start_hour) * HOUR_H;
    el.style.top = top + "px";
    el.style.height = Math.max(height - 2, 18) + "px";
    if (kind === "plan") {
      el.style.background = item.color;
      const nameTxt = item.step_name ? `${esc(item.project_name)} · ${esc(item.step_name)}` : esc(item.project_name);
      const ad = item.actual_duration != null ? ` · 实${item.actual_duration}h` : "";
      // 完成与未完成明显区分：完成显示绿色描边+「✓ 已完成」文字
      el.innerHTML = `${nameTxt}<small>${item.duration}h${ad}${item.done ? " · ✓ 已完成" : " · 点击编辑"}</small>`;
      el.title = (item.done ? "✓ 已完成 · " : "") + "点击编辑：" + (item.step_name ? item.project_name + " · " + item.step_name : item.project_name);
      el.onclick = (e) => { e.stopPropagation(); openPlanModal({ editId: item.id }); };
    } else {
      // 固定安排：使用各自分配的颜色（不再统一浅灰）
      el.style.background = item.color || "#64748b";
      el.innerHTML = `${esc(item.title)}`;
      el.title = item.title;
    }
    return el;
  }

  function fixedIntervals(f) {
    if (f.end_hour > f.start_hour) return [[f.start_hour, f.end_hour]];
    return [[f.start_hour, 24], [0, f.end_hour]];
  }

  // 平面网格视图（原 2D 渲染）
  function renderFlatBlocks() {
    for (let d = 1; d <= 7; d++) {
      $$(`#body-${d} .hour-cell`).forEach((c) => c.classList.remove("occupied"));
      $("#blocks-" + d).innerHTML = "";
    }
    // 固定（支持跨午夜）
    GRID.fixed.forEach((f) => {
      fixedIntervals(f).forEach(([s, e]) => {
        for (let h = Math.ceil(s); h < e; h++) {
          const cell = $(`#body-${f.day_of_week} .hour-cell[data-hour="${h}"]`);
          if (cell) cell.classList.add("occupied");
        }
      });
      $("#blocks-" + f.day_of_week).appendChild(blockEl(f, "fixed", f.day_of_week));
    });
    // 规划
    GRID.plan.forEach((p) => {
      for (let h = Math.ceil(p.start_hour); h < p.start_hour + p.duration; h++) {
        const cell = $(`#body-${p.day_of_week} .hour-cell[data-hour="${h}"]`);
        if (cell) cell.classList.add("occupied");
      }
      $("#blocks-" + p.day_of_week).appendChild(blockEl(p, "plan", p.day_of_week));
    });
  }

  /* ---- 3D 等轴测视图（多风格主题）----
     规划块：凸起实体柱，高于固定安排（已完成=实色，未完成=半透明虚体柱）
     固定安排：低矮凸起实体柱（颜色可自定义） */
  const ISO_DAYS = 7, ISO_HOURS = 24;
  const ISO_FIXED_H = 0.5;  // 固定安排：低矮凸起
  const ISO_PLAN_H = 1.15;  // 规划块：凸起更高
  const ISO_WALL_H = 2.4;   // 背景墙高
  let ISOGEO = null, ISOHITS = [];
  let isoStyle = localStorage.getItem("id_iso_style") || "forest";

  function hexRgb(hex) {
    let n = String(hex || "#64748b").replace("#", "");
    if (n.length === 3) n = n.split("").map((c) => c + c).join("");
    return [parseInt(n.slice(0, 2), 16) || 0, parseInt(n.slice(2, 4), 16) || 0, parseInt(n.slice(4, 6), 16) || 0];
  }
  // 十六进制 → HSL（h:0-360, s/l:0-1）
  function rgbHsl(hex) {
    let [r, g, b] = hexRgb(hex).map((v) => v / 255);
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
    let h = 0, s = 0, l = (mx + mn) / 2;
    if (mx !== mn) {
      const d = mx - mn;
      s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
      if (mx === r) h = (g - b) / d + (g < b ? 6 : 0);
      else if (mx === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
    }
    return [h, s, l];
  }
  function hslStr(h, s, l) {
    const f = (n) => {
      const k = (n + h / 30) % 12;
      const a = s * Math.min(l, 1 - l);
      const v = l - a * Math.max(-1, Math.min(k - 3, Math.min(9 - k, 1)));
      return Math.round(v * 255).toString(16).padStart(2, "0");
    };
    return "#" + f(0) + f(8) + f(4);
  }
  const clamp01 = (v) => Math.max(0, Math.min(1, v));
  // 按 HSL 调整颜色：饱和度倍率 + 亮度夹在 [lMin, lMax]，让整版配色和谐
  function toneHsl(hex, satMul, lMin, lMax) {
    const [h, s, l] = rgbHsl(hex);
    return hslStr(h, clamp01(s * satMul), Math.max(lMin, Math.min(lMax, l)));
  }
  // 把颜色往绿色系收拢（参考图1：整片森林都是绿，仅保留少量色相差异用于区分项目）
  function greenify(hex, satMul, lMin, lMax) {
    const [h, s, l] = rgbHsl(hex);
    const delta = ((h - 100 + 540) % 360) - 180; // 与绿色的最近距离
    return hslStr(100 + delta * 0.28, clamp01(s * satMul), Math.max(lMin, Math.min(lMax, l)));
  }

  const ISO_STYLES = {
    // 唯一风格：森林绿意（岸边陆地=固定安排草甸树丛；池塘水面=可规划区莲叶荷花）
    forest: { name: "森林绿意",
      bg: "#8db161", wallL: "#799f52", wallR: "#6e9348", wallLine: "#62833e",
      floor: "#aed4c4", floorToday: "#d2ebe0", floorLine: "#9cc2b2", edge: "#7fa894",
      text: "#2c481c", muted: "#e9f2d7", today: "#fff6de", halo: "rgba(240,248,220,.55)",
      todoText: "#1f3a12",
      entity: "tree", trunk: "#7d5233", shadow: "rgba(40,70,25,.22)",
      pad: "#7fae6d", padDark: "#6a9558", padLight: "#98c284",
      tone: (c) => greenify(c, 0.62, 0.42, 0.60),
      fixedTone: (c) => toneHsl(c, 0.16, 0.52, 0.68),
      // 固定安排整体基座（草甸床）颜色：比地面更深的肥沃绿
      fixedBed: (c) => greenify(c, 0.72, 0.3, 0.42) },
  };
  // 旧风格值兼容：统一迁移到森林绿意
  if (!ISO_STYLES[isoStyle]) isoStyle = "forest";

  function shadeColor(hex, f) {
    let n = String(hex || "#64748b").replace("#", "");
    if (n.length === 3) n = n.split("").map((c) => c + c).join("");
    const r = parseInt(n.slice(0, 2), 16) || 0, g = parseInt(n.slice(2, 4), 16) || 0, b = parseInt(n.slice(4, 6), 16) || 0;
    const cl = (x) => Math.max(0, Math.min(255, Math.round(x)));
    return "#" + [r * f, g * f, b * f].map((x) => cl(x).toString(16).padStart(2, "0")).join("");
  }
  // 向白色混合（t:0-1），用于高光
  function mixWhite(hex, t) {
    let n = String(hex || "#64748b").replace("#", "");
    if (n.length === 3) n = n.split("").map((c) => c + c).join("");
    const cl = (x) => Math.max(0, Math.min(255, Math.round(x)));
    return "#" + [0, 2, 4].map((i) => {
      const v = parseInt(n.slice(i, i + 2), 16) || 0;
      return cl(v + (255 - v) * t).toString(16).padStart(2, "0");
    }).join("");
  }
  function rgbaColor(hex, a) {
    let n = String(hex || "#64748b").replace("#", "");
    if (n.length === 3) n = n.split("").map((c) => c + c).join("");
    return `rgba(${parseInt(n.slice(0, 2), 16) || 0},${parseInt(n.slice(2, 4), 16) || 0},${parseInt(n.slice(4, 6), 16) || 0},${a})`;
  }
  function isoPt(x, y, z) {
    return [ISOGEO.ox + (x - y) * ISOGEO.wx, ISOGEO.oy + (x + y) * ISOGEO.wy - (z || 0) * ISOGEO.wz];
  }
  function ptInPoly(x, y, pts) {
    let inside = false;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      const xi = pts[i][0], yi = pts[i][1], xj = pts[j][0], yj = pts[j][1];
      if (((yi > y) !== (yj > y)) && (x < ((xj - xi) * (y - yi)) / (yj - yi) + xi)) inside = !inside;
    }
    return inside;
  }

  // ---- 动画状态：风吹摆动 + 鼠标局部风 + 悬停显示名称 ----
  let ISOSCENE = null, isoRAF = 0;
  const isoMouse = { x: -9999, y: -9999 };
  let isoHover = null;

  function drawIsoGrid() {
    if (!GRID) return;
    buildIsoScene();
    if (!isoRAF) isoRAF = requestAnimationFrame(isoLoop);
  }
  function stopIsoLoop() {
    if (isoRAF) { cancelAnimationFrame(isoRAF); isoRAF = 0; }
    isoHover = null;
  }
  function isoLoop(ts) {
    isoRAF = requestAnimationFrame(isoLoop);
    if (ISOSCENE) ISOSCENE.frame(ts / 1000);
  }

  function buildIsoScene() {
    if (!GRID) return;
    const wrap = $("#isoWrap"), cv = $("#isoCanvas"), tip = $("#isoTip");
    if (!wrap || !cv) return;
    const ST = ISO_STYLES[isoStyle] || ISO_STYLES.forest;
    wrap.style.background = ST.bg;

    const W = Math.max(wrap.clientWidth - 16, 320);
    const u = Math.max(14, Math.min(36, (W - 120) / ((ISO_DAYS + ISO_HOURS) * 0.866)));
    ISOGEO = { u, wx: u * 0.866, wy: u * 0.5, wz: u * 0.85, ox: ISO_HOURS * u * 0.866 + 62,
               oy: ISO_WALL_H * u * 0.85 + 30 }; // 原点下移，给背景墙和星期标签留出空间
    const Hpx = Math.ceil(ISOGEO.oy + (ISO_DAYS + ISO_HOURS) * ISOGEO.wy + 44);
    const dpr = window.devicePixelRatio || 1;
    cv.width = Math.round(W * dpr); cv.height = Math.round(Hpx * dpr);
    cv.style.width = W + "px"; cv.style.height = Hpx + "px";
    const ctx = cv.getContext("2d");
    // 静态部分（墙/地板/基座/水面轮廓）画进离屏画布，动画帧只重绘会摆动的实体，保证流畅
    const bg = document.createElement("canvas");
    bg.width = cv.width; bg.height = cv.height;
    const bctx = bg.getContext("2d");
    bctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    let pc = bctx; // 当前绘制目标：构建期 = 离屏静态层
    ISOHITS = [];

    const poly = (pts, fill, stroke, dash, lw) => {
      pc.beginPath();
      pts.forEach((p, i) => (i ? pc.lineTo(p[0], p[1]) : pc.moveTo(p[0], p[1])));
      pc.closePath();
      if (fill) { pc.fillStyle = fill; pc.fill(); }
      if (stroke) { pc.strokeStyle = stroke; pc.lineWidth = lw || 1; pc.setLineDash(dash || []); pc.stroke(); pc.setLineDash([]); }
    };
    const label = (txt, x, y, opts) => {
      opts = opts || {};
      pc.font = (opts.bold ? "600 " : "") + (opts.size || 11) + "px system-ui,-apple-system,'Segoe UI',sans-serif";
      pc.textAlign = opts.align || "center";
      pc.textBaseline = "middle";
      if (opts.halo !== false) { pc.lineWidth = 3; pc.strokeStyle = ST.halo; pc.strokeText(txt, x, y); }
      pc.fillStyle = opts.color || ST.text;
      pc.fillText(txt, x, y);
    };
    const names = window.APP.dayNames;
    const today = todayDow();

    // ---- 背景墙（左侧=小时轴，右侧=星期轴，模拟 3D 图表坐标系）----
    poly([isoPt(0, 0, 0), isoPt(0, ISO_HOURS, 0), isoPt(0, ISO_HOURS, ISO_WALL_H), isoPt(0, 0, ISO_WALL_H)], ST.wallL, ST.wallLine);
    poly([isoPt(0, 0, 0), isoPt(ISO_DAYS, 0, 0), isoPt(ISO_DAYS, 0, ISO_WALL_H), isoPt(0, 0, ISO_WALL_H)], ST.wallR, ST.wallLine);
    for (let h = 0; h <= ISO_HOURS; h += 2) {
      const p = isoPt(0, h, ISO_WALL_H);
      label(h + ":00", p[0] - 8, p[1], { align: "right", color: ST.muted, size: 10, halo: false });
      // 墙面水平参考线
      poly([isoPt(0, h, 0), isoPt(0, h, ISO_WALL_H)], null, ST.wallLine);
    }
    for (let d = 1; d <= ISO_DAYS; d++) {
      const p = isoPt(d - 0.5, 0, ISO_WALL_H);
      label(names[d] + (d === today ? " · 今天" : ""), p[0] + (d === 1 ? 16 : 0), p[1] - 10,
        { bold: true, size: 12, color: d === today ? ST.today : ST.text });
    }

    // ---- 地板格子（今日列高亮）----
    for (let d = 1; d <= ISO_DAYS; d++) {
      for (let h = 0; h < ISO_HOURS; h++) {
        const pts = [isoPt(d - 1, h, 0), isoPt(d, h, 0), isoPt(d, h + 1, 0), isoPt(d - 1, h + 1, 0)];
        poly(pts, d === today ? ST.floorToday : ST.floor, ST.floorLine);
        ISOHITS.push({ polys: [pts], meta: { type: "cell", day: d, hour: h } });
      }
    }
    poly([isoPt(0, 0, 0), isoPt(ISO_DAYS, 0, 0), isoPt(ISO_DAYS, ISO_HOURS, 0), isoPt(0, ISO_HOURS, 0)], null, ST.edge, null, 1.4);

    // ---- 形状（按前后顺序绘制）----
    const shapes = [];
    GRID.fixed.forEach((f) => {
      fixedIntervals(f).forEach(([s, e]) => {
        shapes.push({ kind: "fixed", d: f.day_of_week, y0: s, y1: e, color: f.color || "#64748b",
          label: f.title, src: f });
      });
    });
    GRID.plan.forEach((p) => {
      shapes.push({ kind: "plan", d: p.day_of_week, y0: p.start_hour, y1: p.start_hour + p.duration,
        color: p.color || "#3b82f6", done: !!p.done,
        label: (p.step_name ? p.project_name + "·" + p.step_name : p.project_name) + " " + p.duration + "h" + (p.done ? " ✓" : ""),
        src: p });
    });
    shapes.sort((a, b) => (a.d + a.y1) - (b.d + b.y1));

    // ---- 实体绘制：按风格把时间块画成 树 / 莲 / 石头，支持缩放 ----
    const s = Math.max(15, Math.min(42, u * 1.3));
    const drawShadow = (px, py, rx, ry) => {
      ctx.beginPath(); ctx.ellipse(px, py, rx, ry, 0, 0, Math.PI * 2);
      ctx.fillStyle = ST.shadow; ctx.fill();
    };
    // 树：3 种形态（vr: 0=三球丛冠 1=冷杉塔形 2=高椭圆冠），树冠随风摆动 sway
    const drawTree = (px, py, col, sc, sway, vr) => {
      const z = s * (sc || 1);
      const th = z * 0.62, r = z * 0.58;
      const sw = sway || 0;
      drawShadow(px, py + 1, z * 0.5, z * 0.24);
      ctx.beginPath();
      ctx.moveTo(px - z * 0.09, py + 1);
      ctx.lineTo(px + z * 0.09, py + 1);
      ctx.lineTo(px + z * 0.055 + sw * 0.35, py - th);
      ctx.lineTo(px - z * 0.055 + sw * 0.35, py - th);
      ctx.closePath();
      ctx.fillStyle = ST.trunk; ctx.fill();
      const blob = (bx, by, br, f) => { ctx.beginPath(); ctx.arc(bx + sw * 0.85, by, br, 0, Math.PI * 2); ctx.fillStyle = f; ctx.fill(); };
      if (vr === 1) {
        // 冷杉塔形：三层叠冠，越往上越窄、摆动越大
        for (let i = 0; i < 3; i++) {
          const ly = py - th - i * z * 0.2, lw2 = r * (1.1 - i * 0.26), lh = z * 0.32;
          const lx = px + sw * (0.6 + i * 0.2);
          ctx.beginPath();
          ctx.moveTo(lx - lw2, ly);
          ctx.lineTo(lx + lw2, ly);
          ctx.lineTo(lx, ly - lh);
          ctx.closePath();
          ctx.fillStyle = i === 2 ? col : shadeColor(col, 0.8 + i * 0.08);
          ctx.fill();
        }
      } else if (vr === 2) {
        // 高椭圆单冠
        const cx = px + sw * 0.85;
        ctx.beginPath(); ctx.ellipse(cx, py - th - r * 0.45, r * 0.72, r * 0.95, 0, 0, Math.PI * 2);
        ctx.fillStyle = col; ctx.fill();
        ctx.beginPath(); ctx.ellipse(cx - r * 0.2, py - th - r * 0.62, r * 0.3, r * 0.38, 0, 0, Math.PI * 2);
        ctx.fillStyle = mixWhite(col, 0.3); ctx.fill();
      } else {
        // 三球丛冠（默认）
        blob(px - r * 0.5, py - th - r * 0.1, r * 0.68, shadeColor(col, 0.84));
        blob(px + r * 0.5, py - th - r * 0.05, r * 0.66, shadeColor(col, 0.9));
        blob(px, py - th - r * 0.45, r * 0.82, col);
        blob(px - r * 0.22, py - th - r * 0.75, r * 0.3, mixWhite(col, 0.3));
      }
    };
    // 灌木：贴地三球丛（无树干），随风轻摆
    const drawBush = (px, py, col, sc, sway) => {
      const z = s * (sc || 1);
      const sw = (sway || 0) * 0.7;
      drawShadow(px, py + 1, z * 0.52, z * 0.24);
      const blob = (bx, by, br, f) => { ctx.beginPath(); ctx.arc(bx + sw, by, br, 0, Math.PI * 2); ctx.fillStyle = f; ctx.fill(); };
      blob(px - z * 0.3, py - z * 0.12, z * 0.26, shadeColor(col, 0.86));
      blob(px + z * 0.3, py - z * 0.1, z * 0.24, shadeColor(col, 0.92));
      blob(px, py - z * 0.22, z * 0.3, col);
      blob(px - z * 0.08, py - z * 0.34, z * 0.12, mixWhite(col, 0.28));
    };
    // 花：弯曲花茎 + 五瓣 + 黄芯，花头随风摆
    const drawFlower = (px, py, col, sc, sway) => {
      const z = s * (sc || 1);
      const sw = sway || 0;
      const hx = px + sw * 0.9, fy = py - z * 0.62;
      ctx.strokeStyle = "#5d8a46"; ctx.lineWidth = Math.max(1.2, z * 0.06);
      ctx.beginPath(); ctx.moveTo(px, py);
      ctx.quadraticCurveTo(px + sw * 0.3, py - z * 0.3, hx, fy + z * 0.12);
      ctx.stroke();
      for (let i = 0; i < 5; i++) {
        const a = (Math.PI * 2 * i) / 5 - Math.PI / 2;
        ctx.beginPath();
        ctx.ellipse(hx + Math.cos(a) * z * 0.14, fy + Math.sin(a) * z * 0.1, z * 0.1, z * 0.13, a + Math.PI / 2, 0, Math.PI * 2);
        ctx.fillStyle = mixWhite(col, 0.25); ctx.fill();
      }
      ctx.beginPath(); ctx.arc(hx, fy, z * 0.07, 0, Math.PI * 2);
      ctx.fillStyle = "#f0cf6e"; ctx.fill();
    };
    // 草丛：5 片扇形叶片，叶尖随风摆动（草甸基座的密集填充）
    const drawGrass = (px, py, col, sc, sway) => {
      const z = s * (sc || 1);
      const sw = sway || 0;
      ctx.fillStyle = col;
      for (let i = 0; i < 5; i++) {
        const a = (i - 2) * 0.28;
        const h = z * (0.55 + ((i * 7) % 3) * 0.12);
        const lean = sw * (0.5 + ((i * 5) % 3) * 0.22);
        ctx.beginPath();
        ctx.moveTo(px - z * 0.07, py);
        ctx.lineTo(px + Math.sin(a) * h + lean, py - Math.cos(a) * h);
        ctx.lineTo(px + z * 0.07, py);
        ctx.closePath();
        ctx.fill();
      }
    };
    // 莲：叶盘（裂缝角度随形态变化）+ 5~8 瓣小花，叶盘轻漂、花头摆动更大
    const drawLotus = (px, py, col, sc, withFlower, sway, vr) => {
      const z = s * (sc || 1);
      const sw = (sway || 0) * 0.3;
      const rx = z * 0.62, ry = z * 0.38, ly = py - z * 0.1;
      const crackA = (vr || 0) * 1.9 + 0.5;
      drawShadow(px + sw, py + 1, rx * 0.9, ry * 0.7);
      ctx.beginPath(); ctx.ellipse(px + sw, ly, rx, ry, 0, 0, Math.PI * 2);
      ctx.fillStyle = ST.padDark; ctx.fill();
      ctx.beginPath(); ctx.ellipse(px + sw, ly - z * 0.05, rx * 0.9, ry * 0.88, 0, 0, Math.PI * 2);
      ctx.fillStyle = ST.pad; ctx.fill();
      ctx.beginPath(); ctx.moveTo(px + sw, ly - z * 0.05);
      ctx.lineTo(px + sw + Math.cos(crackA) * rx * 0.85, ly - z * 0.05 - ry * 0.35 + Math.sin(crackA) * ry * 0.3);
      ctx.strokeStyle = ST.floor; ctx.lineWidth = 1.2; ctx.stroke();
      if (withFlower === false) return;
      const petals = 5 + ((vr || 0) % 4);
      const fx = px + sw * 2.6, fy = ly - z * 0.34;
      for (let i = 0; i < petals; i++) {
        const a = (Math.PI * 2 * i) / petals + 0.4;
        ctx.beginPath();
        ctx.ellipse(fx + Math.cos(a) * z * 0.13, fy + Math.sin(a) * z * 0.08, z * 0.095, z * 0.16, a + Math.PI / 2, 0, Math.PI * 2);
        ctx.fillStyle = mixWhite(col, 0.3); ctx.fill();
      }
      ctx.beginPath(); ctx.arc(fx, fy, z * 0.065, 0, Math.PI * 2);
      ctx.fillStyle = "#f0cf6e"; ctx.fill();
    };
    // 石头：椭圆两层（刚性，不随风摆）
    const drawRock = (px, py, col, sc) => {
      const z = s * (sc || 1);
      drawShadow(px, py + 1, z * 0.55, z * 0.26);
      ctx.beginPath(); ctx.ellipse(px, py - z * 0.08, z * 0.55, z * 0.34, 0, 0, Math.PI * 2);
      ctx.fillStyle = shadeColor(col, 0.8); ctx.fill();
      ctx.beginPath(); ctx.ellipse(px - z * 0.08, py - z * 0.24, z * 0.34, z * 0.2, 0, 0, Math.PI * 2);
      ctx.fillStyle = mixWhite(col, 0.12); ctx.fill();
    };
    // asLotus=true：可规划区（池塘）的实体 → 莲叶/荷花；false：岸边陆地的树丛/灌木/草/石
    const drawEntity = (type, px, py, col, sc, asLotus, sway, vr) => {
      if (type === "grass") {
        if (asLotus) drawLotus(px, py, col, sc * 0.8, false, sway, vr);
        else drawGrass(px, py, col, sc, sway);
        return;
      }
      if (asLotus) {
        if (type === "tree") drawLotus(px, py, col, sc, true, sway, vr);      // 带花的莲叶
        else if (type === "bush") drawLotus(px, py, col, sc, false, sway, vr); // 纯莲叶
        else if (type === "flower") drawFlower(px, py, col, sc * 0.9, sway); // 挺出水面的荷花
        else drawLotus(px, py, col, sc * 0.9, false, sway, vr);
        return;
      }
      if (type === "tree") drawTree(px, py, col, sc, sway, vr);
      else if (type === "bush") drawBush(px, py, col, sc, sway);
      else if (type === "flower") drawFlower(px, py, col, sc, sway);
      else drawRock(px, py, col, sc);
    };

    // ---- 场景化：固定安排按名称跨天合并为一个整体场景；规划块各自成场景 ----
    const fixedGroups = new Map();
    const scenes = [];
    shapes.forEach((sh) => {
      const cell = { x0: sh.d - 1, x1: sh.d, y0: sh.y0, y1: sh.y1 };
      const base = [isoPt(cell.x0, cell.y0, 0), isoPt(cell.x1, cell.y0, 0), isoPt(cell.x1, cell.y1, 0), isoPt(cell.x0, cell.y1, 0)];
      if (sh.kind === "fixed") {
        if (!fixedGroups.has(sh.label)) {
          fixedGroups.set(sh.label, { kind: "fixed", label: sh.label, color: sh.color, cells: [], polys: [], src: sh.src });
        }
        fixedGroups.get(sh.label).cells.push(cell);
        fixedGroups.get(sh.label).polys.push(base);
      } else {
        scenes.push({ kind: "plan", label: sh.label, color: sh.color, done: !!sh.done, cells: [cell], polys: [base], src: sh.src });
      }
    });
    fixedGroups.forEach((g) => scenes.push(g));

    // 确定性伪随机（同名安排每天长得一样，刷新不变）
    const hashStr = (str) => { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
    const mulberry32 = (a) => () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };

    // 场景实体生成：灌木丛生为主，树木点缀，花草填充，岩石少量；位置带随机微偏移
    function sceneEntities(cells, seed, mainFirst, mainType) {
      const rnd = mulberry32(hashStr(seed));
      const spots = [];
      cells.forEach((c) => {
        const n = Math.max(2, Math.min(16, Math.round((c.y1 - c.y0) * 1.6)));
        for (let i = 0; i < n; i++) {
          const yy = Math.min(c.y1 - 0.12, Math.max(c.y0 + 0.12, c.y0 + 0.12 + (i * (c.y1 - c.y0 - 0.24)) / Math.max(1, n - 1)));
          spots.push(spots.length === 0 && mainFirst ? { x: (c.x0 + c.x1) / 2, y: yy, main: true } : { x: (c.x0 + c.x1) / 2, y: yy, main: false });
        }
      });
      return spots.map((sp) => {
        let type, sc;
        if (sp.main) { type = mainType; sc = 1.15 + rnd() * 0.2; }
        else {
          const r = rnd();
          type = r < 0.36 ? "bush" : r < 0.58 ? "tree" : r < 0.84 ? "flower" : "rock";
          sc = 0.55 + rnd() * 0.5;
        }
        const jx = (rnd() - 0.5) * 0.34, jy = (rnd() - 0.5) * 0.34;
        return { x: sp.x + jx, y: sp.y + jy, depth: sp.x + jx + sp.y + jy, type, sc };
      }).sort((a, b) => a.depth - b.depth);
    }

    // 固定安排整体群落生成：整个区间是一个连续区域（无视格子），密布草丛，
    // 树/灌木/岩石/花按风格随机组合点缀；首元素为主树（参考图1 的丛生草甸）
    function clusterEntities(cells, seed) {
      const rnd = mulberry32(hashStr(seed));
      const ents = [];
      cells.forEach((c, ci) => {
        const w = c.x1 - c.x0, h = c.y1 - c.y0;
        const nMain = Math.max(1, Math.round(w * h * 0.85));
        for (let i = 0; i < nMain; i++) {
          const x = c.x0 + 0.25 + rnd() * (w - 0.5);
          const y = c.y0 + 0.25 + rnd() * (h - 0.5);
          let type, sc;
          if (ci === 0 && i === 0) { type = "tree"; sc = 1.2 + rnd() * 0.18; }
          else {
            const r = rnd();
            type = r < 0.4 ? "tree" : r < 0.66 ? "bush" : r < 0.86 ? "rock" : "flower";
            sc = 0.65 + rnd() * 0.5;
          }
          ents.push({ x, y, depth: x + y, type, sc, v: rnd() });
        }
        const nGrass = Math.round(w * h * 10);
        for (let i = 0; i < nGrass; i++) {
          const x = c.x0 + 0.1 + rnd() * (w - 0.2);
          const y = c.y0 + 0.1 + rnd() * (h - 0.2);
          ents.push({ x, y, depth: x + y, type: "grass", sc: 0.3 + rnd() * 0.2, v: rnd() });
        }
      });
      return ents.sort((a, b) => a.depth - b.depth);
    }

    // 全场景实体统一收集后按深度排序绘制（正确前后遮挡）
    const allEnts = [];
    scenes.forEach((sc) => {
      const isFixed = sc.kind === "fixed";
      sc.col = isFixed ? ST.fixedTone(sc.color) : ST.tone(sc.color);
      if (isFixed) {
        // ---- 整体基座：合并所有格子为一块连续草甸床，只有外轮廓，无内部格线 ----
        const bed = ST.fixedBed ? ST.fixedBed(sc.color) : shadeColor(sc.col, 0.78);
        const keys = new Set(sc.cells.map((c) => c.x0 + "," + c.y0));
        const has = (x, y) => keys.has(x + "," + y);
        const seg = (a, b, col2, lw, off) => {
          const p1 = isoPt(a[0], a[1], 0), p2 = isoPt(b[0], b[1], 0);
          pc.beginPath(); pc.moveTo(p1[0], p1[1] + off); pc.lineTo(p2[0], p2[1] + off);
          pc.strokeStyle = col2; pc.lineWidth = lw; pc.lineCap = "round"; pc.stroke();
        };
        const bounds = [];
        sc.cells.forEach((c) => {
          if (!has(c.x0 - 1, c.y0)) bounds.push([[c.x0, c.y0], [c.x0, c.y1]]);
          if (!has(c.x1, c.y0)) bounds.push([[c.x1, c.y0], [c.x1, c.y1]]);
          if (!has(c.x0, c.y0 - 1)) bounds.push([[c.x0, c.y0], [c.x1, c.y0]]);
          if (!has(c.x0, c.y1)) bounds.push([[c.x0, c.y1], [c.x1, c.y1]]);
        });
        // 底座厚度：先画整体下移的暗色描边，再整体填充盖住格子线，最后描外轮廓
        bounds.forEach(([a, b]) => seg(a, b, shadeColor(bed, 0.55), 4, 3.5));
        sc.cells.forEach((c) => poly([isoPt(c.x0, c.y0, 0), isoPt(c.x1, c.y0, 0), isoPt(c.x1, c.y1, 0), isoPt(c.x0, c.y1, 0)], bed));
        bounds.forEach(([a, b]) => seg(a, b, shadeColor(bed, 0.6), 1.4, 0));
        // 密集随机组合的群落实体（树/灌木=绿色系，石块=中性灰，草丛=基床色系）
        const treeCol = greenify(sc.color, 0.6, 0.36, 0.55);
        const rockCol = toneHsl(sc.color, 0.05, 0.5, 0.62);
        sc.ents = clusterEntities(sc.cells, sc.label + "|" + isoStyle + "|fixed");
        sc.ents.forEach((en) => {
          if (en.type === "grass") en.col = mixWhite(bed, 0.14 + en.v * 0.28);
          else if (en.type === "tree" || en.type === "bush") en.col = mixWhite(treeCol, 0.05 + en.v * 0.2);
          else if (en.type === "rock") en.col = rockCol;
          allEnts.push({ en, sc });
        });
      } else {
        // 池塘区（可自由规划水面）：已完成=实线水面轮廓，未完成=虚线虚体
        if (!sc.done) sc.polys.forEach((b) => poly(b, null, sc.col, [5, 4], 1.3));
        else sc.polys.forEach((b) => poly(b, null, sc.col, null, 1.2));
        sc.ents = sceneEntities(sc.cells, sc.label + "|" + isoStyle + "|plan", true, "tree");
        sc.ents.forEach((en) => { en.lotus = true; allEnts.push({ en, sc }); });
      }
      // 命中区域按单元格注册（meta.sc 用于悬停时定位该场景的名称气泡）
      sc.polys.forEach((b) => {
        ISOHITS.push({ polys: [b], meta: { type: isFixed ? "fixed" : "plan", label: sc.label, src: sc.src, done: sc.done, sc } });
      });
    });

    // 深度排序保证前后遮挡正确，再赋动画参数（相位/摆幅/速度/形态变体，由坐标决定、确定性）
    allEnts.sort((a, b) => a.en.depth - b.en.depth);
    allEnts.forEach(({ en }) => {
      const r1 = Math.abs(Math.sin(en.x * 12.9898 + en.y * 78.233) * 43758.5453) % 1;
      const r2 = Math.abs(Math.sin(en.x * 78.233 + en.y * 12.9898) * 24634.6345) % 1;
      en.phase = r1 * Math.PI * 2;
      en.amp = en.type === "tree" ? 2.2 + r2 * 1.2 : en.type === "grass" ? 2.6 + r2 * 1.4 : en.type === "rock" ? 0 : 1.6 + r2;
      en.spd = 1.1 + r2 * 1.3;
      en.vr = Math.floor(r1 * 997) % 3;
    });

    // 预计算每个场景的名称气泡位置（悬停时才绘制）
    scenes.forEach((sc) => {
      const isFixed = sc.kind === "fixed";
      let sx = 0, sy = 0, tot = 0;
      sc.cells.forEach((c) => { const w = c.y1 - c.y0; sx += ((c.x0 + c.x1) / 2) * w; sy += ((c.y0 + c.y1) / 2) * w; tot += w; });
      const c = isoPt(tot ? sx / tot : 0.5, tot ? sy / tot : 1, 0);
      sc.lt = sc.label.length > 18 ? sc.label.slice(0, 17) + "…" : sc.label;
      const topOff = isFixed ? 0.9 : 1.9;
      sc.lx = c[0];
      sc.ly = c[1] - s * topOff - 4;
    });

    ISOSCENE = { frame: drawIsoFrame };

    // ---- 动画帧：静态背景一次 drawImage，实体带风摆重绘，悬停场景画名称气泡 ----
    function drawIsoFrame(now) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, Hpx);
      ctx.drawImage(bg, 0, 0, W, Hpx);
      // 实体：基础微风 + 鼠标局部风（离鼠标越近摆动越大，如风吹过）
      for (const { en, sc } of allEnts) {
        const c = isoPt(en.x, en.y, 0);
        const dx = c[0] - isoMouse.x, dy = c[1] - isoMouse.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const near = Math.max(0, 1 - dist / 150);
        const gust = Math.sin(now * en.spd + en.phase) * en.amp;
        const mwind = near * near * (Math.sin(now * 4.5 + en.phase * 2.1) * 3.5 + 11);
        const sway = en.amp ? gust + mwind : 0;
        if (sc.kind === "plan" && !sc.done) ctx.globalAlpha = 0.55;
        drawEntity(en.type, c[0], c[1], en.col || sc.col, en.sc, !!en.lotus, sway, en.vr);
        ctx.globalAlpha = 1;
      }
      // 悬停场景：中心上方弹出名称气泡（替代常驻文字标签）
      if (isoHover && isoHover.sc) {
        const sc = isoHover.sc;
        ctx.font = "600 11px system-ui,-apple-system,'Segoe UI',sans-serif";
        const tw = ctx.measureText(sc.lt).width;
        const bw = tw + 16, bh = 19, rr = 7;
        const bx = sc.lx, by = Math.max(12, sc.ly);
        const tcol = sc.kind === "fixed" ? ST.text : (sc.done ? shadeColor(sc.col, 0.5) : ST.todoText);
        ctx.beginPath();
        ctx.moveTo(bx - bw / 2 + rr, by - bh / 2);
        ctx.arcTo(bx + bw / 2, by - bh / 2, bx + bw / 2, by + bh / 2, rr);
        ctx.arcTo(bx + bw / 2, by + bh / 2, bx - bw / 2, by + bh / 2, rr);
        ctx.arcTo(bx - bw / 2, by + bh / 2, bx - bw / 2, by - bh / 2, rr);
        ctx.arcTo(bx - bw / 2, by - bh / 2, bx + bw / 2, by - bh / 2, rr);
        ctx.closePath();
        ctx.fillStyle = "rgba(255,255,250,.94)"; ctx.fill();
        ctx.strokeStyle = tcol; ctx.lineWidth = 1.2; ctx.stroke();
        // 气泡下方小三角指向场景
        ctx.beginPath();
        ctx.moveTo(bx - 5, by + bh / 2 - 1);
        ctx.lineTo(bx + 5, by + bh / 2 - 1);
        ctx.lineTo(bx, by + bh / 2 + 5);
        ctx.closePath();
        ctx.fillStyle = "rgba(255,255,250,.94)"; ctx.fill();
        ctx.fillStyle = tcol; ctx.textAlign = "center"; ctx.textBaseline = "middle";
        ctx.fillText((sc.kind !== "fixed" && sc.done ? "✓ " : "") + sc.lt, bx, by + 0.5);
      }
    }

    // ---- 交互：命中检测 ----
    function isoHitAt(e) {
      const r = cv.getBoundingClientRect();
      const mx = e.clientX - r.left, my = e.clientY - r.top;
      for (let i = ISOHITS.length - 1; i >= 0; i--) {
        for (const pp of ISOHITS[i].polys) {
          if (ptInPoly(mx, my, pp)) return ISOHITS[i].meta;
        }
      }
      return null;
    }
    cv.onclick = (e) => {
      const hit = isoHitAt(e);
      if (!hit) return;
      if (hit.type === "plan") openPlanModal({ editId: hit.src.id });
      else if (hit.type === "cell") onCellClick(hit.day, hit.hour);
      else if (hit.type === "fixed") toast("固定安排：" + hit.label + "（可在「管理固定安排」中修改颜色/时间）");
    };
    cv.onmousemove = (e) => {
      const r = cv.getBoundingClientRect();
      isoMouse.x = e.clientX - r.left; isoMouse.y = e.clientY - r.top;
      const hit = isoHitAt(e);
      cv.style.cursor = hit && hit.type !== "cell" ? "pointer" : "crosshair";
      isoHover = hit && hit.type !== "cell" ? hit : null;
      if (tip) tip.classList.add("hidden");
    };
    cv.onmouseleave = () => {
      isoMouse.x = -9999; isoMouse.y = -9999; isoHover = null;
      if (tip) tip.classList.add("hidden");
    };
  }

  async function renderGrid() {
    updateDateInfo();
    if (!$("#timeCol").childElementCount) renderTimeCol();
    if (!$("#body-1")) renderDaysSkeleton();
    try {
      GRID = await api("GET", "/api/grid");
    } catch (e) { toast(e.message, false); return; }

    // 周一自动重置提示：上周规划已归档，固定安排保留
    if (GRID.reset_count > 0) {
      toast(`新的一周：已自动归档上周规划 ${GRID.reset_count} 条（固定安排保留），点「📜 每周规划」查看历史`, "done");
    }

    // 每天剩余可规划
    for (let d = 1; d <= 7; d++) {
      $("#free-" + d).textContent = "可规划 " + GRID.remaining[d] + "h";
    }
    // 按当前视图模式渲染（3D 立体 / 平面网格）
    applyGridModeUI();
    if (gridMode === "iso") drawIsoGrid();
    else renderFlatBlocks();

    // 汇总卡片
    $("#gridSummary").innerHTML = `
      <div class="sum-card"><div class="num" style="font-size:17px">第 ${GRID.week_num} 周</div><div class="lbl">当前规划周 · ${weekRange(GRID.week)}</div></div>
      <div class="sum-card"><div class="num">${GRID.total_remaining}h</div><div class="lbl">本周剩余可规划总时长</div></div>
      <div class="sum-card"><div class="num">${(7 * 24 - GRID.total_remaining).toFixed(1)}h</div><div class="lbl">已被固定+规划占用</div></div>
      <div class="sum-card"><div class="num">${GRID.plan.length}</div><div class="lbl">已放入项目数</div></div>`;
  }

  // 周一日期字符串 → "09.21 ~ 09.27" 周区间显示
  function weekRange(ws) {
    const mon = new Date(ws + "T00:00:00");
    if (isNaN(mon.getTime())) return ws;
    const sun = new Date(mon.getTime() + 6 * 86400000);
    const pad = (n) => String(n).padStart(2, "0");
    const f = (d) => `${pad(d.getMonth() + 1)}.${pad(d.getDate())}`;
    return `${f(mon)} ~ ${f(sun)}`;
  }

  function onCellClick(day, hour) {
    const v = $("#planProjSel").value || "";
    const r = resolveSel(v);
    if (!r.proj) { toast("请先在右上角选择项目或步骤", false); return; }
    openPlanModal({ day, start: hour, project: r.proj, step: r.stepNode });
  }

  // 把 ISO 时间转为 datetime-local 输入框格式 YYYY-MM-DDTHH:MM
  function fmtLocalDT(iso) {
    if (!iso) return "";
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "";
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  // 按下拉值解析项目/步骤：v 形如 "p<id>" 或 "s<pid>:<sid>"
  function resolveSel(v) {
    let proj = null, stepNode = null;
    if (v && v.startsWith("s")) {
      const rest = v.slice(1);
      const ci = rest.indexOf(":");
      const pid = parseInt(rest.slice(0, ci), 10);
      const sid = rest.slice(ci + 1);
      proj = PROJECTS.find((p) => p.id === pid);
      stepNode = proj ? findStepNode(proj.steps || [], sid) : null;
    } else if (v && v.startsWith("p")) {
      proj = PROJECTS.find((p) => p.id === parseInt(v.slice(1), 10));
    }
    return { proj, stepNode };
  }

  // 放入/编辑规划弹窗：可调节单次预期用时，可记录实际起止、标记完成；
  // 编辑模式下可把这条规划替换为其他项目或其他步骤
  function openPlanModal(opts) {
    const editItem = opts.editId ? (GRID && GRID.plan.find((x) => x.id === opts.editId)) : null;
    const isEdit = !!editItem;

    let state = { proj: null, stepNode: null };
    if (isEdit) {
      state = resolveSel(editItem.step_id ? "s" + editItem.project_id + ":" + editItem.step_id
                                         : "p" + editItem.project_id);
      if (!state.proj) {
        // 项目可能已被删除，用网格数据兜底展示
        state.proj = { id: editItem.project_id, name: editItem.project_name, color: editItem.color,
                       expected_hours: editItem.duration, category: editItem.category, steps: [] };
        state.stepNode = editItem.step_id ? { id: editItem.step_id, name: editItem.step_name || "", hours: "" } : null;
      }
    } else {
      state.proj = opts.project;
      state.stepNode = opts.step || null;
    }
    if (!state.proj) { toast("项目不存在", false); return; }

    const day = isEdit ? editItem.day_of_week : opts.day; // 修复：编辑时 opts.day 为 undefined
    const dayName = (window.APP.dayNames || {})[day] || "—";
    const start = isEdit ? editItem.start_hour : opts.start;
    const free = (GRID && GRID.remaining && GRID.remaining[day] != null) ? GRID.remaining[day] : "";

    function targetName() {
      const p = state.proj, sn = state.stepNode;
      return sn && sn.name ? `${p.name} · ${sn.name}` : (p ? p.name : "");
    }
    function defaultDur() {
      const sn = state.stepNode;
      return sn && sn.hours ? sn.hours : (state.proj ? state.proj.expected_hours : 1);
    }

    function render() {
      const dur = isEdit ? editItem.duration : defaultDur();
      const dhm = hoursToHM(dur);
      let html = `
      <h3>${isEdit ? "编辑规划 · " : "放入规划 · "}<span id="pmTitle">${esc(targetName())}</span></h3>
      <p class="muted small">${isEdit ? "可替换为其他项目/步骤、修改计划安排，或记录实际执行情况" : "可在放入时单独调节本次预期用时（默认取步骤/项目的预估时间，可自由修改）"}</p>
      <div class="field"><label>星期</label><div class="muted">${dayName}</div></div>
      ${isEdit ? `<div class="field"><label>替换为其他项目 / 步骤</label>
        <div id="pmSwapMount" class="ts-mount"></div>
        <div class="muted small" style="margin-top:4px">更换后这条规划将指向新目标，用时默认改为新目标的预估时间</div></div>` : ""}
      <div class="field"><label>开始时间</label><input id="pmStart" type="time" value="${fmtHM(start)}"></div>
      <div class="field"><label>本次预期用时（可精确到分钟）</label>
        <div class="dur-row"><input id="pmDurH" type="number" min="0" max="24" step="1" value="${dhm.h}"><span>小时</span><input id="pmDurM" type="number" min="0" max="55" step="5" value="${dhm.m}"><span>分钟</span></div></div>
      ${!isEdit && free !== "" ? `<div class="muted small">该天剩余可规划：${free} 小时</div>` : ""}`;

      if (isEdit) {
        html += `
      <div class="divider"></div>
      <h4 class="sub">实际执行记录（用于第四板块统计）</h4>
      <div class="field"><label>实际开始</label><input id="pmActStart" type="datetime-local" value="${fmtLocalDT(editItem.actual_start)}"></div>
      <div class="field"><label>实际结束</label><input id="pmActEnd" type="datetime-local" value="${fmtLocalDT(editItem.actual_end)}"></div>
      <label class="check"><input type="checkbox" id="pmDone" ${editItem.done ? "checked" : ""}> 已按时完成（勾选后时间块会变为完成样式并计入看板占比）</label>`;
      }

      html += `
      <div class="modal-actions">
        ${isEdit ? `<button class="btn-danger" id="pmDel">删除</button>` : ""}
        <button class="btn-ghost" onclick="window.__close()">取消</button>
        <button class="btn-primary" id="pmSave">${isEdit ? "保存" : "放入"}</button>
      </div>`;
      openModal(html);

      if (isEdit) {
        const swapMount = $("#pmSwapMount");
        if (swapMount) {
          createTreeSelect(swapMount, {
            value: state.stepNode ? ("s" + state.proj.id + ":" + state.stepNode.id) : ("p" + state.proj.id),
            onChange: (v) => {
              const r = resolveSel(v);
              if (!r.proj) { toast("目标不存在", false); return; }
              state = r;
              $("#pmTitle").textContent = targetName();
              const nd = hoursToHM(defaultDur()); // 用时默认改为新目标的预估
              $("#pmDurH").value = nd.h; $("#pmDurM").value = nd.m;
            },
          });
        }
        $("#pmDel").onclick = async () => {
          if (!confirm("从时间表中移除该规划？")) return;
          try { await api("DELETE", "/api/plan/" + editItem.id); closeModal(); toast("已移除"); renderGrid(); loadProjects(); renderStats(); }
          catch (e) { toast(e.message, false); }
        };
      }

      $("#pmSave").onclick = async () => {
        const sh = timeToHours($("#pmStart").value);
        const dd = (parseFloat($("#pmDurH").value) || 0) + (parseFloat($("#pmDurM").value) || 0) / 60;
        if (isNaN(sh) || dd <= 0 || dd > 24) { toast("请填写有效的时间（用时需大于 0）", false); return; }
        try {
          if (isEdit) {
            const wasDone = editItem.done;
            const payload = {
              project_id: state.proj.id,
              step_id: state.stepNode ? state.stepNode.id : "",
              start_hour: sh, duration: dd,
            };
            const aS = $("#pmActStart").value, aE = $("#pmActEnd").value;
            payload.actual_start = aS ? new Date(aS).toISOString() : null;
            payload.actual_end = aE ? new Date(aE).toISOString() : null;
            payload.done = $("#pmDone").checked;
            await api("PUT", "/api/plan/" + editItem.id, payload);
            closeModal();
            // 完成状态变化时给出明显的文字提示
            if (!wasDone && payload.done) toast("✓ 已标记按时完成！时间块已更新为完成样式", "done");
            else if (wasDone && !payload.done) toast("已取消完成标记，时间块恢复为进行中样式");
            else toast("已保存");
            renderGrid(); loadProjects(); renderStats();
          } else {
            await api("POST", "/api/plan", {
              project_id: state.proj.id, step_id: state.stepNode ? state.stepNode.id : "",
              day_of_week: day, start_hour: sh, duration: dd,
            });
            closeModal(); toast("已放入：" + targetName()); renderGrid(); loadProjects();
          }
        } catch (e) { toast(e.message, false); }
      };
    }
    render();
  }

  function deletePlan(id) {
    if (!confirm("从时间表中移除该规划？")) return;
    api("DELETE", "/api/plan/" + id).then(() => { toast("已移除"); renderGrid(); loadProjects(); })
      .catch((e) => toast(e.message, false));
  }

  /* ============ 版块四：数据看板 ============ */
  function fmtHM(h) {
    const hh = Math.floor(h), mm = Math.round((h - hh) * 60);
    const pad = (n) => String(n).padStart(2, "0");
    return `${pad(hh)}:${pad(Math.min(mm, 59))}`;
  }
  // "HH:MM" → 小时浮点数（如 "13:30" → 13.5）；无效返回 NaN
  function timeToHours(v) {
    if (!v || v.indexOf(":") < 0) return NaN;
    const parts = v.split(":").map(Number);
    const h = parts[0], m = parts[1];
    if (isNaN(h) || isNaN(m) || h < 0 || h > 23 || m < 0 || m > 59) return NaN;
    return h + m / 60;
  }
  // 小时浮点 → {h, m}，分钟取整到 5 分钟
  function hoursToHM(h) {
    let hh = Math.floor(h), mm = Math.round((h - hh) * 60 / 5) * 5;
    if (mm >= 60) { hh += 1; mm = 0; }
    if (hh > 24) { hh = 24; mm = 0; }
    return { h: hh, m: mm };
  }
  function fmtDateTime(iso) {
    if (!iso) return "—";
    const d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    const pad = (n) => String(n).padStart(2, "0");
    return `${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }
  function trunc(s, n) { return (s && s.length > n) ? s.slice(0, n) + "…" : (s || ""); }

  async function renderStats() {
    let stats;
    try { stats = await api("GET", "/api/stats"); }
    catch (e) { toast(e.message, false); return; }

    const s = stats.summary;
    $("#statsSummary").innerHTML = `
      <div class="sum-card"><div class="num">${s.project_count}</div><div class="lbl">项目数</div></div>
      <div class="sum-card"><div class="num">${s.placement_count}</div><div class="lbl">规划次数</div></div>
      <div class="sum-card"><div class="num">${s.planned_total}h</div><div class="lbl">计划总时长</div></div>
      <div class="sum-card"><div class="num">${s.actual_total}h</div><div class="lbl">实际总时长</div></div>
      <div class="sum-card"><div class="num">${s.done_total}</div><div class="lbl">已完成次数</div></div>`;

    const projLabels = stats.projects.map((p) => p.name);
    const projPlanned = stats.projects.map((p) => p.planned_hours);
    const projActual = stats.projects.map((p) => p.actual_hours);
    $("#chartProjects").innerHTML = stats.projects.length
      ? groupedBarSVG({ labels: projLabels, series: [projPlanned, projActual],
          colors: ["#cbd5e1", "#3b82f6"], legend: ["预期", "实际"], unit: "h" })
      : '<p class="muted small">暂无数据，请先在③时间规划中放入项目。</p>';

    const catLabels = stats.categories.map((c) => c.category);
    const catPlanned = stats.categories.map((c) => c.planned_hours);
    const catActual = stats.categories.map((c) => c.actual_hours);
    $("#chartCats").innerHTML = stats.categories.length
      ? groupedBarSVG({ labels: catLabels, series: [catPlanned, catActual],
          colors: ["#cbd5e1", "#10b981"], legend: ["预期", "实际"], unit: "h" })
      : '<p class="muted small">暂无分类数据。</p>';

    renderDoneChart(stats.projects);

    await renderStatsTable();
    await loadWeekly();   // 每周完成情况 + 雷达图
  }

  /* ---- 每周完成情况总览 + 各类别完成雷达图 ---- */
  let WEEKLY = null;

  async function loadWeekly() {
    try { WEEKLY = await api("GET", "/api/weekly"); }
    catch (e) { toast(e.message, false); return; }
    const sel = $("#weekSel");
    if (!sel) return;
    sel.innerHTML = WEEKLY.weeks.map((w) =>
      `<option value="${w.week_start}">第 ${w.week} 周 ${weekRange(w.week_start)}${w.current ? "（本周）" : "（归档）"}</option>`).join("");
    sel.onchange = renderWeekly;
    renderWeekly();
  }

  function renderWeekly() {
    const sel = $("#weekSel");
    if (!sel || !WEEKLY) return;
    const ws = sel.value;
    const w = WEEKLY.weeks.find((x) => x.week_start === ws);
    const box = $("#weeklyOverview");
    if (!w) { box.innerHTML = '<p class="muted small">暂无数据。</p>'; $("#chartRadar").innerHTML = ""; return; }

    // 与所选周相邻的上一周（用于雷达图对比）
    const prev = WEEKLY.weeks.filter((x) => x.week_start < ws).sort((a, b) => b.week_start.localeCompare(a.week_start))[0] || null;

    const unfinished = w.unfinished || [];
    const missHours = unfinished.reduce((a, b) => a + (b.hours || 0), 0);
    box.innerHTML = `
      <div class="wk-sum" style="margin:4px 0 12px">
        <div class="sum-card"><div class="num">${w.planned_hours || 0}h</div><div class="lbl">计划时长</div></div>
        <div class="sum-card"><div class="num">${w.done_hours || 0}h</div><div class="lbl">完成时长</div></div>
        <div class="sum-card"><div class="num">${w.rate || 0}%</div><div class="lbl">完成率</div></div>
        <div class="sum-card"><div class="num">${w.done_count || 0}/${w.items_count || 0}</div><div class="lbl">完成/总次数</div></div>
        <div class="sum-card"><div class="num" style="color:${unfinished.length ? "#dc2626" : "#059669"}">${unfinished.length}</div><div class="lbl">未完成项（${missHours}h）</div></div>
      </div>
      <div class="wk-cat" style="margin-bottom:14px">
        <span class="tag">${w.current ? "本周" : "第" + w.week + "周"}</span>
        <div class="wk-bar" style="flex:1"><div class="wk-fill${(w.rate || 0) >= 80 ? " good" : (w.rate || 0) < 30 ? " bad" : ""}" style="width:${w.rate || 0}%"></div></div>
        <span class="wk-meta">总完成率 ${w.rate || 0}%</span>
      </div>
      ${unfinished.length
        ? `<h4 class="sub" style="color:#dc2626">⚠ 未完成部分（突出显示）</h4>
           <div class="wk-miss">${unfinished.slice(0, 12).map((u) =>
             `<span class="miss-chip">${window.APP.dayNames[u.day] || ""} · ${esc(u.name)} ${u.hours}h</span>`).join("")}
             ${unfinished.length > 12 ? `<span class="muted small">…等共 ${unfinished.length} 项</span>` : ""}</div>`
        : (w.items_count ? '<p class="muted small" style="color:#059669">🎉 该周规划全部按时完成</p>' : '<p class="muted small">该周没有放入的规划。</p>')}`;

    renderRadar(w, prev);
  }

  // 各类别完成率雷达图（纯 SVG）：所选周实线 + 上一周对比虚线
  function renderRadar(w, prev) {
    const box = $("#chartRadar"), legend = $("#radarLegend");
    if (!box) return;
    const cats = [];
    const seen = {};
    // 轴 = 两周类别的并集（按所选周计划时长排序，最多 8 轴）
    (w.by_category || []).forEach((c) => { if (!seen[c.category]) { seen[c.category] = 1; cats.push(c.category); } });
    if (prev) (prev.by_category || []).forEach((c) => { if (!seen[c.category]) { seen[c.category] = 1; cats.push(c.category); } });
    const axes = cats.slice(0, 8);
    if (!axes.length) {
      box.innerHTML = '<p class="muted small">暂无分类数据，请先在③时间规划中放入项目。</p>';
      if (legend) legend.textContent = "";
      return;
    }
    const rateOf = (week, cat) => {
      if (!week) return null;
      const c = (week.by_category || []).find((x) => x.category === cat);
      return c ? Math.max(0, Math.min(100, c.rate || 0)) : 0;
    };
    const W = 680, H = 400, cx = W / 2, cy = H / 2 + 6, R = 142;
    const pt = (i, frac) => {
      const ang = -Math.PI / 2 + (2 * Math.PI * i) / axes.length;
      return [cx + Math.cos(ang) * R * frac, cy + Math.sin(ang) * R * frac];
    };
    const polyPts = (vals) => vals.map((v, i) => pt(i, v / 100).map((n) => n.toFixed(1)).join(",")).join(" ");
    let svg = `<svg viewBox="0 0 ${W} ${H}" width="100%" preserveAspectRatio="xMidYMid meet" role="img">`;
    // 同心网格（六边形风格，同参考图）
    const levels = 4;
    for (let l = levels; l >= 1; l--) {
      const frac = l / levels;
      svg += `<polygon points="${axes.map((_, i) => pt(i, frac).map((n) => n.toFixed(1)).join(",")).join(" ")}"
        fill="${l % 2 ? "#f8fafc" : "#f1f5f9"}" stroke="#e2e8f0" stroke-width="1"/>`;
    }
    // 轴线 + 轴标签（含所选周完成率）
    axes.forEach((cat, i) => {
      const [x, y] = pt(i, 1);
      svg += `<line x1="${cx}" y1="${cy}" x2="${x.toFixed(1)}" y2="${y.toFixed(1)}" stroke="#e2e8f0" stroke-width="1"/>`;
      const [lx, ly] = pt(i, 1.16);
      const anchor = Math.abs(lx - cx) < 12 ? "middle" : (lx > cx ? "start" : "end");
      const va = rateOf(w, cat);
      svg += `<text x="${lx.toFixed(1)}" y="${(ly - 2).toFixed(1)}" text-anchor="${anchor}" font-size="12" font-weight="600" fill="#475569">${esc(cat)}</text>`;
      if (va != null) svg += `<text x="${lx.toFixed(1)}" y="${(ly + 12).toFixed(1)}" text-anchor="${anchor}" font-size="10" fill="#94a3b8">${va}%</text>`;
    });
    // 上一周对比（绿色，参考图双系列）
    if (prev) {
      const pv = axes.map((c) => rateOf(prev, c) || 0);
      svg += `<polygon points="${polyPts(pv)}" fill="rgba(132,204,22,.10)" stroke="#84cc16" stroke-width="2" stroke-dasharray="5 3"/>`;
      pv.forEach((v, i) => {
        const [x, y] = pt(i, v / 100);
        svg += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="3.5" fill="#84cc16"><title>${esc(axes[i])} · 第${prev.week}周 ${v}%</title></circle>`;
      });
    }
    // 所选周（蓝色实线）
    const av = axes.map((c) => rateOf(w, c) || 0);
    svg += `<polygon points="${polyPts(av)}" fill="rgba(37,99,235,.16)" stroke="#2563eb" stroke-width="2.4"/>`;
    av.forEach((v, i) => {
      const [x, y] = pt(i, v / 100);
      svg += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="4" fill="#2563eb"><title>${esc(axes[i])} · 第${w.week}周 ${v}%</title></circle>`;
    });
    svg += "</svg>";
    box.innerHTML = svg;
    if (legend) {
      legend.innerHTML = `<span class="rg-dot" style="background:#2563eb"></span>第 ${w.week} 周${w.current ? "（本周）" : ""}
        ${prev ? `<span class="rg-dot" style="background:#84cc16;margin-left:14px"></span>第 ${prev.week} 周（对比）` : ""} · 数值=该类别完成率`;
    }
  }

  // 各项目完成占比：已标记完成的计划时长 / 总计划时长
  function renderDoneChart(projects) {
    const box = $("#chartDone");
    if (!box) return;
    const list = (projects || []).filter((p) => p.planned_hours > 0);
    if (!list.length) {
      box.innerHTML = '<p class="muted small">暂无数据，请先在③时间规划中放入项目。</p>';
      return;
    }
    box.innerHTML = list.map((p) => {
      const planned = p.planned_hours || 0;
      const done = p.done_hours || 0;
      const pct = planned > 0 ? Math.round((done / planned) * 100) : 0;
      const full = pct >= 100;
      return `<div class="done-row">
        <div class="done-head">
          <span class="dot" style="background:${p.color}"></span>
          <span class="done-name">${esc(p.name)}</span>
          <span class="done-meta">已完成 ${done}h / 计划 ${planned}h · ${p.done}/${p.placements} 次</span>
          <span class="done-pct${full ? " full" : ""}">${pct}%</span>
        </div>
        <div class="done-bar">
          <div class="done-fill" style="width:${pct}%;background:${full ? "#10b981" : p.color}"></div>
        </div>
      </div>`;
    }).join("");
  }

  async function renderStatsTable() {
    let plans = [];
    try { plans = await api("GET", "/api/plan"); } catch (e) { plans = []; }
    if (!plans.length) {
      $("#statsTable").innerHTML = '<p class="muted small">尚无放入的时间规划。</p>';
      return;
    }
    const rows = plans.map((p) => {
      const cColor = catColor(p.category);
      const status = p.done ? "已完成" : "进行中";
      return `<tr>
        <td><span class="dot" style="background:${p.color}"></span>${esc(p.project_name)}</td>
        <td><span class="tag" style="border-color:${cColor};color:${cColor}">${esc(p.category)}</span></td>
        <td>${window.APP.dayNames[p.day_of_week]}</td>
        <td>${fmtHM(p.start_hour)}–${fmtHM(p.end_hour)}</td>
        <td>${p.duration}h</td>
        <td>${fmtDateTime(p.actual_start)}</td>
        <td>${fmtDateTime(p.actual_end)}</td>
        <td>${p.actual_duration != null ? p.actual_duration + "h" : "—"}</td>
        <td><span class="status-dot st-${p.done ? "done" : "planned"}"></span>${status}</td>
      </tr>`;
    }).join("");
    $("#statsTable").innerHTML = `
      <table class="dtab">
        <thead><tr>
          <th>项目</th><th>类别</th><th>星期</th><th>计划起止</th><th>计划用时</th>
          <th>实际开始</th><th>实际结束</th><th>实际用时</th><th>状态</th>
        </tr></thead>
        <tbody>${rows}</tbody>
      </table>`;
  }

  // 通用分组柱状图（纯 SVG，离线可用）
  function groupedBarSVG(opts) {
    const labels = opts.labels || [];
    const series = opts.series || [];
    const nSeries = series.length;
    const colors = opts.colors || ["#cbd5e1", "#3b82f6"];
    const W = 640, padL = 34, padR = 10, padT = 12, padB = 56, plotH = 200;
    const plotW = W - padL - padR;
    const n = Math.max(labels.length, 1);
    const groupW = plotW / n;
    const innerW = groupW * 0.7;
    const barW = innerW / nSeries;
    let maxV = 0;
    series.forEach((arr) => arr.forEach((v) => { if (v > maxV) maxV = v; }));
    maxV = Math.max(maxV, 0.5) * 1.12;
    const H = plotH + padT + padB;
    let svg = `<svg viewBox="0 0 ${W} ${H}" width="100%" preserveAspectRatio="xMidYMid meet" role="img">`;
    const ticks = 4;
    for (let i = 0; i <= ticks; i++) {
      const val = maxV * i / ticks;
      const y = padT + plotH - (val / maxV) * plotH;
      svg += `<line x1="${padL}" y1="${y.toFixed(1)}" x2="${W - padR}" y2="${y.toFixed(1)}" stroke="#e2e8f0" stroke-width="1"/>`;
      svg += `<text x="${padL - 4}" y="${(y + 3).toFixed(1)}" text-anchor="end" font-size="9" fill="#94a3b8">${val.toFixed(1)}</text>`;
    }
    labels.forEach((lab, gi) => {
      const gx = padL + groupW * gi + (groupW - innerW) / 2;
      series.forEach((arr, si) => {
        const v = arr[gi] || 0;
        const bh = (v / maxV) * plotH;
        const x = gx + si * barW;
        const y = padT + plotH - bh;
        svg += `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${Math.max(barW - 1, 1).toFixed(1)}" height="${bh.toFixed(1)}" fill="${colors[si]}" rx="2"><title>${esc(lab)} · ${opts.legend ? opts.legend[si] : ("系列" + (si + 1))}: ${v}${opts.unit || ""}</title></rect>`;
      });
      const lx = padL + groupW * gi + groupW / 2;
      svg += `<text x="${lx.toFixed(1)}" y="${padT + plotH + 14}" text-anchor="middle" font-size="9" fill="#475569">${esc(trunc(lab, 5))}</text>`;
    });
    let lx = padL;
    series.forEach((arr, si) => {
      svg += `<rect x="${lx}" y="${padT + plotH + 30}" width="10" height="10" fill="${colors[si]}" rx="2"/>`;
      const lg = opts.legend ? opts.legend[si] : ("系列" + (si + 1));
      svg += `<text x="${lx + 14}" y="${padT + plotH + 39}" font-size="9" fill="#475569">${esc(lg)}</text>`;
      lx += 14 + lg.length * 11 + 16;
    });
    svg += `</svg>`;
    return svg;
  }

  /* ---- 固定安排管理（大弹窗 + 多选日期）---- */
  async function showFixedManager() {
    let fixed = [];
    try { fixed = await api("GET", "/api/fixed"); } catch (e) { toast(e.message, false); }
    const names = window.APP.dayNames;
    const dayChecks = Object.keys(names)
      .map((d) => `<label class="fday"><input type="checkbox" class="fdayck" value="${d}">${names[d]}</label>`).join("");
    openModal(`
      <h3>管理固定安排</h3>
      <p class="muted small">如睡觉、上班等每周循环的事项，在 3D 视图中显示为低矮凸起柱。星期可多选；点击列表中的「编辑」可修改已有安排。</p>
      <div id="fixedList"></div>
      <div id="fEditing" class="editing-banner hidden">正在编辑：<b id="fEditingName"></b>
        <button type="button" class="btn-ghost" id="fCancel">取消编辑</button></div>
      <div style="margin-top:14px;border-top:1px solid var(--line);padding-top:14px">
        <div class="field"><label>名称</label><input id="fTitle" placeholder="如：睡觉" style="width:100%"></div>
        <div class="field"><label>星期（可多选）</label><div class="fixed-days">${dayChecks}</div></div>
        <div class="field"><label>颜色（默认按名称自动分配醒目颜色）</label>
          <div class="color-row">
            <input type="color" id="fColor" value="#64748b">
            <div class="swatches">${FIXED_PRESET.map((c) => `<button type="button" class="swatch" data-c="${c}" style="background:${c}"></button>`).join("")}</div>
          </div>
        </div>
        <div class="fixed-times">
          <div class="field"><label>开始时间</label><input id="fStart" type="time" value="23:00"></div>
          <div class="field"><label>结束时间（00:00 表示午夜 24 点）</label><input id="fEnd" type="time" value="07:00"></div>
          <button class="btn-primary" id="fAdd" style="align-self:flex-end;margin-bottom:14px">添加（可跨午夜）</button>
        </div>
      </div>
      <div class="modal-actions"><button class="btn-ghost" onclick="window.__close()">关闭</button></div>`, "modal-lg");
    let editing = null; // { ids: [...], title }
    const resetForm = () => {
      editing = null;
      $("#fTitle").value = ""; $("#fStart").value = "23:00"; $("#fEnd").value = "07:00";
      $("#fColor").value = "#64748b";
      $$(".fdayck").forEach((c) => (c.checked = false));
      $("#fAdd").textContent = "添加（可跨午夜）";
      $("#fEditing").classList.add("hidden");
    };
    const editCb = (g) => {
      // 编辑：回填表单，保存后替换该组全部记录
      editing = { ids: g.ids.slice(), title: g.title };
      $("#fTitle").value = g.title;
      $("#fStart").value = fmtHM(g.start); $("#fEnd").value = fmtHM(g.end % 24);
      $("#fColor").value = g.color || "#64748b";
      $$(".fdayck").forEach((c) => (c.checked = g.days.includes(parseInt(c.value, 10))));
      $("#fAdd").textContent = "保存修改";
      $("#fEditingName").textContent = g.title;
      $("#fEditing").classList.remove("hidden");
    };
    renderFixedList(fixed, editCb);
    $$("#modalBox .swatch").forEach((b) => {
      b.onclick = () => { $("#fColor").value = b.dataset.c; };
    });
    $("#fCancel").onclick = resetForm;
    $("#fAdd").onclick = async () => {
      const days = $$(".fdayck").filter((c) => c.checked).map((c) => parseInt(c.value, 10));
      const fsh = timeToHours($("#fStart").value);
      let feh = timeToHours($("#fEnd").value);
      if (isNaN(fsh) || isNaN(feh)) { toast("请填写有效的开始/结束时间", false); return; }
      if (feh === 0) feh = 24; // 结束时间 00:00 视为午夜 24 点
      const payload = {
        title: $("#fTitle").value.trim(),
        days,
        start_hour: fsh,
        end_hour: feh,
        color: $("#fColor").value,
      };
      if (!payload.title) { toast("请填写名称", false); return; }
      if (!days.length) { toast("请至少勾选一个星期", false); return; }
      try {
        const wasEditing = !!editing;
        if (editing) {
          for (const id of editing.ids) await api("DELETE", "/api/fixed/" + id);
        }
        await api("POST", "/api/fixed", payload);
        const list = await api("GET", "/api/fixed");
        resetForm();
        renderFixedList(list, editCb);
        if ($("#view-p3").classList.contains("active")) renderGrid();
        toast(wasEditing ? "已保存修改" : "已添加 " + days.length + " 天");
      } catch (e) { toast(e.message, false); }
    };
  }
  // 相同名称+时间段的合并为一行显示（如「睡觉 周一/周三/周五 23:00-07:00」）；onEdit 为编辑回调
  function renderFixedList(fixed, onEdit) {
    const box = $("#fixedList");
    if (!fixed.length) { box.innerHTML = '<p class="muted small">暂无固定安排。</p>'; return; }
    const groups = {};
    fixed.forEach((f) => {
      const k = f.title + "|" + f.start_hour + "|" + f.end_hour;
      if (!groups[k]) groups[k] = { title: f.title, start: f.start_hour, end: f.end_hour, color: f.color || "#64748b", days: [], ids: [] };
      if (!groups[k].color) groups[k].color = f.color || "#64748b";
      groups[k].days.push(f.day_of_week);
      groups[k].ids.push(f.id);
    });
    const arr = Object.values(groups);
    window.__fixedGroups = arr;
    const names = window.APP.dayNames;
    box.innerHTML = arr.map((g, i) => `
      <div class="fixed-row2">
        <span class="fr-title"><span class="fr-dot" style="background:${g.color || "#64748b"}"></span>${esc(g.title)}</span>
        <span class="fr-days">${g.days.sort((a, b) => a - b).map((d) => names[d]).join(" / ")}</span>
        <span class="fr-time">${fmtHM(g.start)} – ${fmtHM(g.end)}</span>
        <button class="btn-ghost fr-edit" data-gi="${i}">编辑</button>
        <button class="btn-danger" data-ids="${g.ids.join(",")}">删除</button>
      </div>`).join("");
    $$("#fixedList .btn-danger").forEach((b) => {
      b.onclick = async () => {
        const ids = b.dataset.ids.split(",");
        for (const id of ids) await api("DELETE", "/api/fixed/" + id);
        const list = await api("GET", "/api/fixed");
        renderFixedList(list, onEdit);
        if ($("#view-p3").classList.contains("active")) renderGrid();
        toast("已删除");
      };
    });
    if (onEdit) {
      $$("#fixedList .fr-edit").forEach((b) => {
        b.onclick = () => onEdit(window.__fixedGroups[parseInt(b.dataset.gi, 10)]);
      });
    }
  }

  /* ---- 每周规划：历史归档查看 + 手动重置 ---- */
  async function showWeekArchive() {
    let wk;
    try { wk = await api("GET", "/api/weekly"); }
    catch (e) { toast(e.message, false); return; }
    if (!wk.weeks.length) { toast("暂无周规划数据", false); return; }
    const rows = wk.weeks.map((w) => {
      const rate = w.rate || 0;
      const tag = w.current ? '<span class="wk-cur">本周</span>' : '<span class="wk-arch">归档</span>';
      const btn = w.current
        ? `<button class="btn-ghost" data-ws="${w.week_start}">查看详情</button>`
        : `<button class="btn-ghost" data-ws="${w.week_start}">查看详情</button>`;
      return `<div class="wk-row">
        <div class="wk-left">${tag}<span class="wk-name">第 ${w.week} 周</span><span class="wk-range">${weekRange(w.week_start)}</span></div>
        <div class="wk-mid">
          <div class="wk-bar"><div class="wk-fill${rate >= 80 ? " good" : rate < 30 ? " bad" : ""}" style="width:${rate}%"></div></div>
          <span class="wk-meta">计划 ${w.planned_hours}h · 完成 ${w.done_hours}h · ${rate}%</span>
        </div>
        ${btn}
      </div>`;
    }).join("");
    openModal(`
      <h3>📜 每周规划历史</h3>
      <p class="muted small">每周一自动把上周的可自由规划内容归档并重置（固定安排每周循环、不受影响）；点击「重置本周」可手动归档。</p>
      <div class="wk-list">${rows}</div>
      <div class="modal-actions"><button class="btn-ghost" onclick="window.__close()">关闭</button></div>`, "modal-lg");
    $$("#modalBox [data-ws]").forEach((b) => {
      b.onclick = () => showWeekDetail(b.dataset.ws);
    });
  }

  async function showWeekDetail(ws) {
    let d;
    try { d = await api("GET", "/api/weeks/" + ws); }
    catch (e) { toast(e.message, false); return; }
    const s = d.stats || {};
    const names = window.APP.dayNames;
    // 按天分组
    const byDay = {};
    (d.items || []).forEach((it) => {
      (byDay[it.day_of_week] = byDay[it.day_of_week] || []).push(it);
    });
    const dayBlocks = Object.keys(byDay).sort((a, b) => a - b).map((day) => {
      const items = byDay[day].slice().sort((a, b) => a.start_hour - b.start_hour);
      return `<div class="wk-day">
        <div class="wk-day-head">${names[day]}<span class="muted small">${items.length} 项</span></div>
        ${items.map((it) => {
          const nameTxt = it.step_name ? `${esc(it.project_name)} · ${esc(it.step_name)}` : esc(it.project_name);
          const timeTxt = `${fmtHM(it.start_hour)} – ${fmtHM(it.start_hour + (it.duration || 0))}`;
          const actual = it.actual_hours != null ? ` · 实${it.actual_hours}h` : "";
          return `<div class="wk-item${it.done ? " ok" : " miss"}">
            <span class="dot" style="background:${it.color || "#3b82f6"}"></span>
            <span class="wi-name">${nameTxt}</span>
            <span class="wi-time">${timeTxt} · ${it.duration}h${actual}</span>
            <span class="wi-st">${it.done ? "✓ 已完成" : "未完成"}</span>
          </div>`;
        }).join("")}
      </div>`;
    }).join("");
    const catBars = (s.by_category || []).map((c) => {
      const pct = c.planned > 0 ? Math.round(c.done / c.planned * 100) : 0;
      return `<div class="wk-cat">
        <span class="tag">${esc(c.category)}</span>
        <div class="wk-bar"><div class="wk-fill${pct >= 80 ? " good" : pct < 30 ? " bad" : ""}" style="width:${pct}%"></div></div>
        <span class="wk-meta">${c.done}/${c.planned}h · ${pct}%</span>
      </div>`;
    }).join("");
    openModal(`
      <h3>${d.current ? "本周规划详情" : "第 " + d.week + " 周归档详情"} <span class="muted small">${weekRange(ws)}${d.archived_at ? " · 归档于 " + d.archived_at : ""}</span></h3>
      <div class="wk-sum">
        <div class="sum-card"><div class="num">${s.planned_hours || 0}h</div><div class="lbl">计划时长</div></div>
        <div class="sum-card"><div class="num">${s.done_hours || 0}h</div><div class="lbl">完成时长</div></div>
        <div class="sum-card"><div class="num">${s.rate || 0}%</div><div class="lbl">完成率</div></div>
        <div class="sum-card"><div class="num">${s.done_count || 0}/${s.items_count || 0}</div><div class="lbl">完成次数</div></div>
      </div>
      ${catBars ? `<h4 class="sub">各类别完成情况</h4><div class="wk-cats">${catBars}</div>` : ""}
      ${s.unfinished && s.unfinished.length ? `<h4 class="sub">⚠ 未完成 ${s.unfinished.length} 项（共 ${s.unfinished.reduce((a, b) => a + (b.hours || 0), 0)}h）</h4>
        <div class="wk-miss">${s.unfinished.map((u) => `<span class="miss-chip">${names[u.day] || ""} · ${esc(u.name)} ${u.hours}h</span>`).join("")}</div>` : '<p class="muted small">🎉 本周规划全部按时完成</p>'}
      <h4 class="sub">按天明细</h4>
      ${dayBlocks || '<p class="muted small">该周没有放入的规划。</p>'}
      <div class="modal-actions"><button class="btn-ghost" onclick="window.__close()">关闭</button></div>`, "modal-lg");
  }

  async function resetWeekConfirm() {
    openModal(`
      <h3>🔄 重置本周</h3>
      <p class="muted small">把当前可自由规划区的全部内容<strong>归档到本周历史</strong>后清空，重新开始规划。固定安排（睡觉/上班等每周循环）不受影响。此操作可用于一周中途重新规划。</p>
      <div class="modal-actions">
        <button class="btn-ghost" onclick="window.__close()">取消</button>
        <button class="btn-primary" id="doWeekReset">确认归档并重置</button>
      </div>`);
    $("#doWeekReset").onclick = async () => {
      try {
        const r = await api("POST", "/api/week/reset");
        closeModal();
        toast(r.archived > 0 ? `已归档 ${r.archived} 条规划，可规划区已清空` : "可规划区已是空的", "done");
        renderGrid();
      } catch (e) { toast(e.message, false); }
    };
  }

  /* ---- 工具 ---- */
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
  window.__close = closeModal;

  /* ============ 启动 ============ */
  document.addEventListener("DOMContentLoaded", async () => {
    if ($("#loginForm")) { initAuth(); return; }
    if ($("#view-p1")) {
      try {
        const me = await api("GET", "/api/me");
        window.__me = me.user.username;
      } catch (e) { location.href = "/login"; return; }
      initDashboard();
    }
  });
})();
